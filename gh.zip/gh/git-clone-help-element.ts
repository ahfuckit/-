import {controller, target, targets} from '@github/catalyst'

@controller('git-clone-help')
class GitCloneHelpElement extends HTMLElement {
  @target declare helpField: HTMLInputElement
  @targets declare helpTexts: HTMLElement[]
  @targets declare cloneURLButtons: HTMLElement[]

  updateURL(event: Event) {
    const switcher = event.currentTarget as HTMLElement

    const url = switcher.getAttribute('data-url') || ''

    this.helpField.value = url

    if (switcher.matches('.js-git-protocol-clone-url')) {
      for (const el of this.helpTexts) {
        el.textContent = url
      }
    }

    for (const button of this.cloneURLButtons) {
      button.classList.remove('selected')
    }
    switcher.classList.add('selected')
  }
}
