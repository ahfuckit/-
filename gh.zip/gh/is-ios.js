"use strict";
var isIpadOS = require("./is-ipados");
module.exports = function isIos(ua, checkIpadOS, document) {
    if (checkIpadOS === void 0) { checkIpadOS = true; }
    ua = ua || window.navigator.userAgent;
    var iOsTest = /iPhone|iPod|iPad/i.test(ua);
    return checkIpadOS ? iOsTest || isIpadOS(ua, document) : iOsTest;
};
