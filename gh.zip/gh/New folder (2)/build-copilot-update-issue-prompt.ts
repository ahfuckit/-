export interface BuildCopilotUpdateIssuePromptParams {
  ownerLogin: string
  repoName: string
  issueNumber: string
  commentBody: string
}

/**
 * Builds the prompt for updating an issue based on comment feedback.
 */
export function buildCopilotUpdateIssuePrompt({
  ownerLogin,
  repoName,
  issueNumber,
  commentBody,
}: BuildCopilotUpdateIssuePromptParams): string {
  return `Using the following feedback, update the issue body in @${ownerLogin}/${repoName}/issues/${issueNumber} and also make sure to include a diff of your changes in your response.

<feedback>
${commentBody}
</feedback>`
}
