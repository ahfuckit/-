import {ContentView} from '@github-ui/pacer/ContentView'
import {Blankslate} from '@primer/react/experimental'
import styles from './AgentsBlankslate.module.css'
import type {MemberRequestEntities} from '../../types/agent-tasks-app-payload'
import {AccessDisabledBanner, AccessRequestBanner, UpgradeBanner} from './AgentsBlankslateBanner'

export interface AgentsBlankslateProps {
  hasCEorCBAccess?: boolean
  memberRequestEntities?: MemberRequestEntities
  location?: 'agents_blankslate' | 'repo_agents_blankslate'
}

export function AgentsBlankslate({
  hasCEorCBAccess,
  memberRequestEntities,
  location = 'agents_blankslate',
}: AgentsBlankslateProps) {
  const requestableOrgs = memberRequestEntities?.orgs?.requestable || []
  const adminableOrgs = memberRequestEntities?.orgs?.adminable || []
  const hasOrgs = requestableOrgs.length + adminableOrgs.length > 0
  const showMemberRequests = Boolean(memberRequestEntities && (hasOrgs || memberRequestEntities.enterprise))

  return (
    <>
      <ContentView.Container width="large">
        <Blankslate size="medium" className={styles.blankslate}>
          <Blankslate.Heading>
            Copilot Coding Agent handles routine tasks so you can focus on core work
          </Blankslate.Heading>
          <Blankslate.Description>
            Save time by offloading testing, dependency upgrades, migrations and maintenance to agents. Create pull
            requests from Copilot Chat, CLI, IDEs or assign an Issue to Copilot to get started.
          </Blankslate.Description>
          <Blankslate.SecondaryAction href="https://docs.github.com/en/copilot/concepts/agents/coding-agent/about-coding-agent">
            View Copilot Coding Agent capabilities
          </Blankslate.SecondaryAction>
          {hasCEorCBAccess === true &&
            (showMemberRequests && memberRequestEntities ? (
              <AccessRequestBanner
                enterprise={memberRequestEntities.enterprise}
                requestableOrgs={requestableOrgs}
                adminableOrgs={adminableOrgs}
              />
            ) : (
              <AccessDisabledBanner />
            ))}
          {hasCEorCBAccess === false && <UpgradeBanner location={location} />}
        </Blankslate>
      </ContentView.Container>
    </>
  )
}
