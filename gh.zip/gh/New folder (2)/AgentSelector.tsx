import {ActionMenu, ActionList, Button, LinkButton} from '@primer/react'
import {CopilotIcon, PlusIcon, TriangleDownIcon, FileCheckIcon} from '@primer/octicons-react'
import {useSubAgents} from '../../hooks/useSubAgents'
import {useTopLevelAgents} from '../../hooks/useTopLevelAgents'
import {AgentListItems} from './AgentListItems'
import {renderAgentSelectorMenuTrigger} from './AgentSelectorMenuTrigger'

import styles from './AgentSelector.module.css'
import type {DropdownRepository} from '../../hooks/useCopilotRepoFetching'
import {useEffect, useMemo} from 'react'
import type {SelectedAgent} from '../../types/session'
import {isCopilotCodingAgent} from '../../utils/agent-helpers'

type AgentSelectorProps = {
  repo: DropdownRepository
  branch: string
  selectedAgent: SelectedAgent
  onSelectAgent: (agent: SelectedAgent) => void
  iconOnly?: boolean
  insideDialog?: boolean
  disabled?: boolean
  buttonProps?: React.ComponentProps<typeof Button>
}

export function AgentSelector({
  repo,
  branch,
  selectedAgent,
  onSelectAgent,
  iconOnly = true,
  disabled = false,
  buttonProps,
  insideDialog = false,
}: AgentSelectorProps) {
  const {data: customAgents = [], isLoading: isLoadingCustomAgents} = useSubAgents({repo})
  const {data: topLevelAgents = [], isLoading: isLoadingTopLevel} = useTopLevelAgents(repo.nameWithOwner)

  const isLoading = repo.isEmpty || !branch || isLoadingCustomAgents || isLoadingTopLevel
  const agents = useMemo(() => [...topLevelAgents, ...customAgents], [topLevelAgents, customAgents])

  useEffect(() => {
    if (isLoading || agents.length === 0 || !selectedAgent?.typeName) return

    const agentExists =
      selectedAgent.typeName === 'topLevel'
        ? agents.some(a => 'id' in a && a.id === selectedAgent.topLevelAgentId)
        : agents.some(a => 'name' in a && a.name === selectedAgent.subAgentSlug)

    if (!agentExists) {
      onSelectAgent({})
    }
  }, [isLoading, agents, selectedAgent, onSelectAgent])

  // Default to "Copilot" if no agent is selected
  const isEmptyAgent = (agent: SelectedAgent) => !agent?.typeName
  const effectiveSelectedAgent = isEmptyAgent(selectedAgent) ? 'Copilot' : selectedAgent

  const agentType =
    typeof effectiveSelectedAgent === 'string'
      ? effectiveSelectedAgent === 'Copilot'
        ? 'topLevel'
        : 'customSubAgent'
      : effectiveSelectedAgent.typeName
  const selectedAgentObj = agents.find(agent => {
    if (typeof effectiveSelectedAgent === 'string') {
      return agent.display_name === effectiveSelectedAgent
    }
    if (agentType === 'topLevel') {
      return 'id' in agent && agent.id === effectiveSelectedAgent.topLevelAgentId
    }
    if (agentType === 'customSubAgent') {
      return 'name' in agent && agent.name === effectiveSelectedAgent.subAgentSlug
    }
  })

  const selectedAgentName = (() => {
    if (typeof effectiveSelectedAgent === 'string') {
      return effectiveSelectedAgent
    }
    if (!selectedAgentObj) {
      return undefined
    }
    return selectedAgentObj.display_name || ('name' in selectedAgentObj ? selectedAgentObj.name : undefined)
  })()

  const newFileUrl = useMemo(() => {
    const params = new URLSearchParams({
      filename: '.github/agents/my-agent.agent.md',
      value:
        '---\n# Fill in the fields below to create a basic custom agent for your repository.\n# The Copilot CLI can be used for local testing: https://gh.io/customagents/cli\n# To make this agent available, merge this file into the default repository branch.\n# For format details, see: https://gh.io/customagents/config\n\nname:\ndescription:\n---\n\n# My Agent\n\nDescribe what your agent does here...',
    })
    return `/${repo.owner}/${repo.nameOnly}/new/${branch}?${params.toString()}`
  }, [repo, branch])

  const isCopilotSelected = (() => {
    if (isEmptyAgent(selectedAgent)) {
      return true
    }
    if (selectedAgent.typeName === 'topLevel' && selectedAgentObj && 'slug' in selectedAgentObj) {
      return isCopilotCodingAgent(selectedAgentObj.slug)
    }
    return false
  })()
  const triggerLabel = selectedAgentName || 'None'
  const ariaLabel = selectedAgentName
    ? `${agentType === 'topLevel' ? 'Agent' : 'Custom agent'}: ${selectedAgentName}`
    : `Select an agent`

  return (
    <ActionMenu>
      <ActionMenu.Anchor>
        {iconOnly ? (
          renderAgentSelectorMenuTrigger({
            isLoading,
            isCopilotSelected,
            selectedAgentObj,
            agentType,
            ariaLabel,
            disabled,
            variant: buttonProps?.variant,
            className: buttonProps?.className,
          })
        ) : (
          <Button
            leadingVisual={selectedAgentName ? FileCheckIcon : CopilotIcon}
            trailingAction={TriangleDownIcon}
            aria-label={ariaLabel}
            className={styles.anchor}
            data-selected={Boolean(selectedAgentObj)}
            disabled={disabled || isLoading}
            {...buttonProps}
          >
            {triggerLabel}
          </Button>
        )}
      </ActionMenu.Anchor>
      {/* eslint-disable-next-line primer-react/no-system-props */}
      <ActionMenu.Overlay width="auto" overflow="auto" displayInViewport={insideDialog}>
        {agents.length === 0 ? (
          <EmptyState newFileUrl={newFileUrl} />
        ) : (
          <ActionList>
            <AgentListItems
              topLevelAgents={topLevelAgents}
              customAgents={customAgents}
              selectedAgent={selectedAgent}
              onSelectAgent={onSelectAgent}
            />
            <ActionList.Divider />
            <ActionList.Group selectionVariant={false}>
              <ActionList.LinkItem href={newFileUrl} target="_blank">
                <ActionList.LeadingVisual>
                  <PlusIcon />
                </ActionList.LeadingVisual>
                Create a custom agent
              </ActionList.LinkItem>
            </ActionList.Group>
          </ActionList>
        )}
      </ActionMenu.Overlay>
    </ActionMenu>
  )
}

const EmptyState = ({newFileUrl}: {newFileUrl: string}) => (
  <div className={styles.emptyStateContainer}>
    <h3 className={styles.emptyStateTitle}>This repository has no custom agents</h3>
    <p className={styles.emptyStateDescription}>
      Custom agents are reusable instructions and tools in your repository.
    </p>
    <LinkButton href={newFileUrl}>Create a custom agent</LinkButton>
  </div>
)
