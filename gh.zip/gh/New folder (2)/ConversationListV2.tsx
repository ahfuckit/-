import {sendEvent} from '@github-ui/hydro-analytics'
import {Link} from '@github-ui/react-router'
import {KebabHorizontalIcon} from '@primer/octicons-react'
import {ActionList, ActionMenu, Heading, IconButton} from '@primer/react'
import {SkeletonText} from '@primer/react/experimental'
import {clsx} from 'clsx'
import {useCallback, useId, useMemo, useRef, useState} from 'react'
import {flushSync} from 'react-dom'

import {COPILOT_PATH, threadName} from '../../utils/copilot-chat-helpers'
import type {LoadingStateState} from '../../utils/copilot-chat-reducer'
import type {CopilotChatThread} from '../../utils/copilot-chat-types'
// eslint-disable-next-line no-restricted-imports
import {useChatState} from '../../utils/CopilotChatContext'
import {useChatManager} from '../../utils/CopilotChatManagerContext'
import {type ConversationActionDialogName, ConversationActionDialogs, ConversationActions} from './ConversationActions'
import styles from './ConversationListV2.module.css'

export interface ConversationListItem {
  id: string
  text: string
  leadingVisual?: React.ReactNode
  href?: string
  date: Date
}

interface ConversationListProps {
  selectedItemID?: string | null
  loadingState: LoadingStateState
  onConversationSelect: () => void
  isSidebarCondensed?: boolean
}

function groupItemsByDate(items: ConversationListItem[]) {
  const today = new Date()
  const yesterday = new Date(today)
  yesterday.setDate(today.getDate() - 1)
  const last7Days = new Date(today)
  last7Days.setDate(today.getDate() - 7)
  const last30Days = new Date(today)
  last30Days.setDate(today.getDate() - 30)

  const todayItems: ConversationListItem[] = []
  const yesterdayItems: ConversationListItem[] = []
  const last7DaysItems: ConversationListItem[] = []
  const last30DaysItems: ConversationListItem[] = []

  for (const item of items) {
    if (item.date.toDateString() === today.toDateString()) {
      todayItems.push(item)
    } else if (item.date.toDateString() === yesterday.toDateString()) {
      yesterdayItems.push(item)
    } else if (item.date > last7Days) {
      last7DaysItems.push(item)
    } else if (item.date > last30Days) {
      last30DaysItems.push(item)
    }
  }

  const grouped = {
    Today: todayItems,
    Yesterday: yesterdayItems,
    'Last 7 days': last7DaysItems,
    'Last 30 days': last30DaysItems,
  }

  return grouped
}

export function ConversationList({
  selectedItemID,
  loadingState,
  onConversationSelect,
  isSidebarCondensed,
}: ConversationListProps) {
  const manager = useChatManager()
  const {threads} = useChatState()

  const ungroupedItems = useMemo(() => {
    return manager.sortAndFilterThreads(threads).map(thread => ({
      id: thread.id,
      text: threadName(thread),
      href: `${COPILOT_PATH}/c/${thread.id}`,
      date: new Date(thread.updatedAt),
    }))
  }, [threads, manager])

  const groupedItems = groupItemsByDate(ungroupedItems)
  const isEmpty = ungroupedItems.length === 0
  const isLoading = loadingState === 'loading' || loadingState === 'pending'

  const id = useId()

  return (
    <nav
      aria-labelledby={`${id}-conversations`}
      id={`${id}-conversation-list`}
      tabIndex={-1}
      className={clsx(styles.container, isSidebarCondensed && styles.condensed)}
    >
      {isEmpty && isLoading ? (
        <SkeletonText lines={5} />
      ) : isEmpty ? (
        <EmptyState />
      ) : (
        <div className={styles.section}>
          <h3 id={`${id}-conversations`} className="sr-only">
            Chats
          </h3>
          {Object.entries(groupedItems).map(
            ([group, items]) =>
              items.length > 0 && (
                <div key={group}>
                  <h4 id={`${id}_${group}`} className={styles.title}>
                    {group}
                  </h4>
                  <ul className={styles.list}>
                    {items.map(item => (
                      <ConversationListEntry
                        item={item}
                        key={item.id}
                        selectedItemId={selectedItemID ?? undefined}
                        onSelect={onConversationSelect}
                        threads={threads}
                      />
                    ))}
                  </ul>
                </div>
              ),
          )}
        </div>
      )}
    </nav>
  )
}

interface ConversationListEntryProps {
  item: ConversationListItem
  selectedItemId?: string
  onSelect: () => void
  threads: Map<string, CopilotChatThread>
}

function ConversationListEntry({item, selectedItemId, onSelect, threads}: ConversationListEntryProps) {
  const selected = item.id === selectedItemId
  const [dialog, setDialog] = useState<ConversationActionDialogName | null>(null)
  const [loading, setLoading] = useState(false)
  const startLoading = useCallback(() => setLoading(true), [])
  const finishLoading = useCallback(() => setLoading(false), [])
  const selectedThread = threads.get(selectedItemId!)
  const isSpace = Boolean(selectedThread?.customCopilotID)
  const anchorRef = useRef<HTMLButtonElement>(null)

  const closeDialog = useCallback(() => {
    // eslint-disable-next-line @eslint-react/dom/no-flush-sync
    flushSync(() => setDialog(null))
    anchorRef.current?.focus()
  }, [anchorRef])

  return (
    item.href && (
      <li className={styles.item} key={item.id}>
        <Link
          className={styles.link}
          to={item.href}
          aria-current={selected ? 'page' : undefined}
          onClick={() => {
            onSelect()
            sendEvent('dotcom_chat.activate', {
              target: 'CONVERSATION_SELECT',
              threadId: item.id,
              mode: 'immersive',
            })
          }}
        >
          <span className={styles.text}>{item.text}</span>
        </Link>
        <span className={styles.context}>
          <ActionMenu anchorRef={anchorRef}>
            <ActionMenu.Anchor>
              <IconButton
                loading={loading}
                icon={KebabHorizontalIcon}
                aria-label="Manage chat"
                variant="invisible"
                onClick={() =>
                  sendEvent('dotcom_chat.activate', {
                    target: 'CONVERSATION_CONTEXT_MENU',
                    mode: 'immersive',
                  })
                }
              />
            </ActionMenu.Anchor>
            <ActionMenu.Overlay>
              <ActionList>
                <ConversationActions
                  onOpenDialog={setDialog}
                  isShared={Boolean(threads.get(item.id)?.sharedID)}
                  showShare={!isSpace}
                  threadName={item.text}
                  threadId={item.id}
                />
              </ActionList>
            </ActionMenu.Overlay>
          </ActionMenu>
        </span>
        <ConversationActionDialogs
          visibleDialog={dialog}
          onClose={closeDialog}
          threadName={item.text}
          threadId={item.id}
          selectedThreadId={selectedItemId}
          onStartLoading={startLoading}
          onFinishLoading={finishLoading}
          returnFocusRef={anchorRef}
        />
      </li>
    )
  )
}

function EmptyState() {
  return (
    <div className={styles.empty}>
      <Heading as="h3" className={styles.emptyStateHeading}>
        No chats yet
      </Heading>
      <span className={styles.emptyStateText}>Ask Copilot anything on the right to start your first chat.</span>
    </div>
  )
}
