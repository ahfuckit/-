import {sendEvent} from '@github-ui/hydro-analytics'
import {InlineAutocomplete} from '@github-ui/inline-autocomplete'
import type {SelectSuggestionsEvent, ShowSuggestionsEvent, Trigger} from '@github-ui/inline-autocomplete/types'
import type {DetailedHTMLProps, InputHTMLAttributes, ReactElement} from 'react'
import {useEffect, useState} from 'react'

import type {AvailableCommand} from '../../hooks/use-available-commands'
import type {CopilotChatCommandType} from '../../utils/copilot-chat-types'
import {copilotFeatureFlags} from '../../utils/copilot-feature-flags'
// eslint-disable-next-line no-restricted-imports
import {useChatState} from '../../utils/CopilotChatContext'
import {ReferenceMention} from '../../utils/reference-mention'
import {categoryNames, CategoryValue} from './categories'
import {useAutocompleteAgentsDialogs} from './use-autocomplete-agents-dialogs'
import {type AutocompleteQuery, useAutocompleteSuggestions} from './useAutocompleteSuggestions'

/** Returns a blank query corresponding to the selected category. */
function selectedCategoryQuery(category: CategoryValue): AutocompleteQuery {
  switch (category) {
    case 'repositories':
      return {category: 'repositories', filter: ''}
    case 'agents':
      return {category: 'agents', filter: ''}
    case 'repositories:discussions':
      return {category: 'repositories', filter: '', nextCategory: 'discussions'}
    case 'repositories:issues':
      return {category: 'repositories', filter: '', nextCategory: 'issues'}
    case 'repositories:pulls':
      return {category: 'repositories', filter: '', nextCategory: 'pulls'}
    case 'repositories:files':
      return {category: 'repositories', filter: '', nextCategory: 'files'}
  }
}

// null return ensures we get completeness detection from the typechecker because undefined is not allowed to be returned
function getTitleForQuery(query: AutocompleteQuery): string | null {
  switch (query.category) {
    case 'categories':
    case 'commands':
      return null
    case 'repositories':
      switch (query.nextCategory) {
        case 'discussions':
        case 'issues':
        case 'pulls':
        case 'files':
          return `${categoryNames[query.nextCategory]} ›`
        default:
          return 'Repositories ›'
      }
    case 'agents':
      return categoryNames[query.category]
    case 'discussions':
    case 'issues':
    case 'pulls':
    case 'files':
      return `${categoryNames[query.category]} › ${query.repository} ›`
    case 'sso-orgs':
      return 'Single sign-on'
  }
}

export interface ChatInputAutocompleteProps {
  children: ReactElement<DetailedHTMLProps<InputHTMLAttributes<HTMLTextAreaElement>, HTMLTextAreaElement>>
  onSelectCommand?: (command: CopilotChatCommandType) => void
  onSelectReference: (ReferenceMention: ReferenceMention) => void
  onShowAgentsDialog: (dialog: 'no-agents-available' | 'agents-not-supported') => void
  hideAutocomplete?: boolean
  availableCommands: AvailableCommand[]
  availableModes: Array<{name: string}>
}

export function ChatInputAutocomplete({
  children,
  onSelectCommand,
  onSelectReference,
  onShowAgentsDialog,
  hideAutocomplete,
  availableCommands,
  availableModes,
}: ChatInputAutocompleteProps) {
  const {mode} = useChatState()
  const triggers: Trigger[] = [
    {triggerChar: '@', insertSpaceOnCommit: true, keepTriggerCharOnCommit: false, multiWord: true},
  ]
  if (copilotFeatureFlags.chatInputCommands) {
    triggers.push({triggerChar: '/', insertSpaceOnCommit: true, keepTriggerCharOnCommit: false, multiWord: false})
  }

  const [mounted, setMounted] = useState(() => typeof document !== 'undefined')
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => setMounted(true), [])

  const [query, setQuery] = useState<AutocompleteQuery | null>(null)
  const {suggestions, stale: suggestionsDataStale} = useAutocompleteSuggestions({query, availableCommands})

  useAutocompleteAgentsDialogs({query, onShowAgentsDialog})

  if (!mounted || hideAutocomplete) return <div>{children}</div>

  const onSelectSuggestion = ({suggestion}: SelectSuggestionsEvent) => {
    const suggestionValue = typeof suggestion === 'string' ? suggestion : suggestion.value
    sendEvent('dotcom_chat.activate', {
      target: 'AUTOCOMPLETE_ITEM_SELECTED',
      mode,
      suggestion: suggestionValue,
    })

    const isCommand = typeof suggestion === 'object' && query?.category === 'commands'

    if (isCommand) {
      onSelectCommand?.(suggestion.key as CopilotChatCommandType)
      return
    }

    const mention =
      suggestionValue !== null && query?.category !== 'agents' ? ReferenceMention.parse(suggestionValue) : undefined
    if (mention) onSelectReference(mention)

    // Reopen the menu for multistep queries
    const isMultistepSuggestion = typeof suggestion === 'object' && suggestion.value === null
    if (!isMultistepSuggestion) return

    // Hack that allows us to put the Extensions marketplace link into the menu
    const openLinkMatch = /^open-link:(.+)$/.exec(suggestion.key)
    if (openLinkMatch) {
      setQuery(null)
      window.open(openLinkMatch[1], '_blank')
      return
    }

    switch (query?.category) {
      case 'categories':
        if (CategoryValue.is(suggestion.key)) setQuery(selectedCategoryQuery(suggestion.key))
        break
      case 'repositories':
        if (suggestion.key === 'sso-orgs') setQuery({category: 'sso-orgs', filter: ''})
        else if (query.nextCategory) setQuery({category: query.nextCategory, filter: '', repository: suggestion.key})
        break
    }
  }

  const onShowSuggestions = (event: ShowSuggestionsEvent) => {
    const eventTarget = event.target as HTMLTextAreaElement
    if (event.trigger.triggerChar === '/') {
      if (
        // not in the commands category: only trigger if the caret is at the very start
        // in the commands category: always update the filter
        (query === null && eventTarget.selectionStart === 1 && eventTarget.selectionEnd === 1) ||
        query?.category === 'commands'
      ) {
        setQuery({category: 'commands', filter: event.query})
      }

      return
    }

    setQuery(q =>
      q
        ? {...q, filter: event.query}
        : {
            category: 'categories',
            filter: event.query,
            index: (eventTarget.selectionStart ?? 0) - (event.query.length + event.trigger.triggerChar.length),
          },
    )
  }

  const onHideSuggestions = () => setQuery(null)

  const shouldReplaceText = ({suggestion}: SelectSuggestionsEvent) => {
    // Check if the command key matches any available mode name
    if (
      typeof suggestion === 'object' &&
      query?.category === 'commands' &&
      suggestion.key !== undefined &&
      copilotFeatureFlags.askModeDropdown
    ) {
      const isCommandWithMode = availableModes.some(
        availableMode => availableMode.name.toLowerCase() === suggestion.key!.toLowerCase(),
      )
      // When askModeDropdown is enabled and this command has an associated mode, don't replace text
      // (the mode change will be the action instead)
      if (isCommandWithMode) {
        return false
      }
    }
    return true
  }

  return (
    <>
      <InlineAutocomplete
        fullWidth
        suggestions={suggestions}
        triggers={triggers}
        tabInsertsSuggestions={false}
        onHideSuggestions={onHideSuggestions}
        onShowSuggestions={onShowSuggestions}
        onSelectSuggestion={onSelectSuggestion}
        shouldReplaceText={shouldReplaceText}
        suggestionsPlacement="below"
        title={(query && getTitleForQuery(query)) || undefined}
        asMenu
      >
        {children}
      </InlineAutocomplete>
      {suggestionsDataStale && (
        <span role="status" aria-live="polite" className="sr-only">
          Loading
        </span>
      )}
    </>
  )
}
