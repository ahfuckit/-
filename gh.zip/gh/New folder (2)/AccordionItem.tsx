import {clsx} from 'clsx'
import React, {useCallback, useId} from 'react'

import Styles from './AccordionItem.module.css'

export interface AccordionItemProps {
  heading: React.ReactNode | React.ReactNode[]
  content: React.ReactNode | React.ReactNode[]
  isExpanded: boolean
  onToggle: (state: boolean) => void
  className?: string
  isListItem?: boolean
}

const AccordionItem = ({heading, content, isExpanded, onToggle, className, isListItem}: AccordionItemProps) => {
  const id = useId()
  const TermTag = isListItem ? 'dt' : 'div'
  const DescriptionTag = isListItem ? 'dd' : 'div'

  const handleOnClick = useCallback(() => {
    onToggle(!isExpanded)
  }, [isExpanded, onToggle])

  return (
    <div className={clsx(Styles['AccordionItem'], className)} data-open={isExpanded}>
      <TermTag>
        <div
          className={Styles['AccordionItem__heading']}
          aria-expanded={isExpanded}
          aria-controls={id}
          onClick={handleOnClick}
          role="button"
          tabIndex={0}
          onKeyDown={event => {
            if (event.key === 'Enter' || event.key === ' ') {
              event.preventDefault()
              handleOnClick()
            }
          }}
        >
          {heading}
        </div>
      </TermTag>
      <DescriptionTag {...(!isExpanded && {'aria-hidden': true, inert: true})}>
        <div
          id={id}
          className={clsx(Styles['AccordionItem__content'], isExpanded && Styles['AccordionItem__content--expanded'])}
        >
          <div>{content}</div>
        </div>
      </DescriptionTag>
    </div>
  )
}

export default AccordionItem
