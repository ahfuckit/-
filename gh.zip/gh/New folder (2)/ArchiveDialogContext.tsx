import React, {useCallback, useMemo, useState} from 'react'

interface ArchiveDialogState {
  isOpen: boolean
  taskId?: string
  repoOwner?: string
  repoName?: string
}

type ArchiveStatus = 'idle' | 'success' | 'error'

interface ArchiveDialogContextValue {
  dialogState: ArchiveDialogState
  archiveStatus: ArchiveStatus
  openArchiveDialog: (taskId: string, repoOwner: string, repoName: string) => void
  closeArchiveDialog: () => void
  setArchiveStatus: (status: ArchiveStatus) => void
}

const ArchiveDialogContext = React.createContext<ArchiveDialogContextValue | undefined>(undefined)

interface ArchiveDialogProviderProps {
  children: React.ReactNode
}

export function ArchiveDialogProvider({children}: ArchiveDialogProviderProps) {
  const [dialogState, setDialogState] = useState<ArchiveDialogState>({
    isOpen: false,
  })
  const [archiveStatus, setArchiveStatus] = useState<ArchiveStatus>('idle')

  const openArchiveDialog = useCallback((taskId: string, repoOwner: string, repoName: string) => {
    setDialogState({isOpen: true, taskId, repoOwner, repoName})
  }, [])

  const closeArchiveDialog = useCallback(() => {
    setDialogState({isOpen: false})
  }, [])

  const value = useMemo(
    () => ({dialogState, archiveStatus, openArchiveDialog, closeArchiveDialog, setArchiveStatus}),
    [dialogState, archiveStatus, openArchiveDialog, closeArchiveDialog],
  )

  return <ArchiveDialogContext value={value}>{children}</ArchiveDialogContext>
}

export function useArchiveDialog() {
  const context = React.use(ArchiveDialogContext)
  if (!context) {
    throw new Error('useArchiveDialog must be used within an ArchiveDialogProvider')
  }
  return context
}

/**
 * Optional version of useArchiveDialog that returns undefined if not within a provider.
 * Useful for components that may be rendered in contexts where archiving isn't available.
 */
export function useArchiveDialogOptional() {
  return React.use(ArchiveDialogContext)
}
