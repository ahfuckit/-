import type {RepositoryNWO} from '@github-ui/current-repository'
import {useGetHovercardAttributesForType} from '@github-ui/hovercards/use-get-hovercard-attributes-for-type'
import {commitsByAuthor} from '@github-ui/paths'
import {ProfileReference} from '@github-ui/profile-reference'
import {Link} from '@primer/styled-react'
import type {Author} from '../commit-attribution-types'
import {AuthorTooltip} from './AuthorTooltip'
import {useAuthorSettings} from '../contexts/AuthorSettingsContext'
import {AuthorDisplayName} from './AuthorDisplayName'
import {clsx} from 'clsx'

import styles from './AuthorLink.module.css'

export interface AuthorAvatarProps {
  author: Author | undefined
  repo: RepositoryNWO
  className?: string
}

/**
 * Renders the author of a commit.
 */
export function AuthorLink({author, repo, className}: AuthorAvatarProps) {
  const authorSettings = useAuthorSettings()
  const getHovercardAttributesForType = useGetHovercardAttributesForType()
  const hovercardAttrs = getHovercardAttributesForType('user', {login: author?.login ?? ''})

  if (!author) return null

  return (
    <div data-testid="author-link" className={clsx(styles.authorLinkContainer, className)}>
      {author.login ? (
        <AuthorTooltip author={author} renderTooltip={authorSettings.includeTooltip}>
          <Link
            muted
            href={commitsByAuthor({repo, author: author.login})}
            aria-label={`commits by ${author.login}`}
            {...hovercardAttrs}
            sx={{
              fontWeight: authorSettings.fontWeight,
              color: authorSettings.fontColor,

              '&:hover': {
                color: authorSettings.fontColor,
              },
            }}
            className={styles.authorNameLink}
          >
            <ProfileReference login={author.login} profileName={author.profileName} isAgent={false} />
          </Link>
        </AuthorTooltip>
      ) : (
        <AuthorDisplayName displayName={author.displayName} authorSettings={authorSettings} />
      )}
    </div>
  )
}
