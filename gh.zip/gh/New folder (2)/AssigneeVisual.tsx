import {CopilotAvatar} from '@github-ui/copilot-avatar'
import {GitHubAvatar} from '@github-ui/github-avatar'

export type AssigneeVisualProps = {login: string; id: string; avatarUrl: string; isCopilot: boolean}

export function AssigneeVisual({login, id, avatarUrl, isCopilot}: AssigneeVisualProps) {
  if (isCopilot) {
    return <CopilotAvatar />
  } else {
    return <GitHubAvatar src={avatarUrl} size={20} alt={`@${login}`} key={id} />
  }
}
