import type {CopilotChatCommandType} from './copilot-chat-types'
import {copilotFeatureFlags} from './copilot-feature-flags'

export function extractChatCommandType(
  text: string,
  availableCommandsKeys: CopilotChatCommandType[],
): CopilotChatCommandType | null {
  // Early return if no commands are allowed (undefined or empty array)
  if (availableCommandsKeys.length === 0) {
    return null
  }

  if (!copilotFeatureFlags.chatInputCommands) {
    return null
  }

  const pattern = new RegExp(`^\\/(${availableCommandsKeys.join('|')})(?:\\s|$)`, 'i')

  const match = text.match(pattern)
  if (match && match[1]) {
    // Type assertion is safe here because the regex pattern is built from availableCommandsKeys
    const command = match[1].toLowerCase() as CopilotChatCommandType

    return command
  }

  return null
}

/**
 * Checks if a slash command is incomplete (has no meaningful text after the command).
 * Returns true if the text starts with a slash command but has no additional text after it.
 * This is used to disable the submit button until the user provides the required prompt.
 *
 * @param text - The input text to check
 * @param command - The extracted command type (or null if no command)
 * @returns true if the text is an incomplete slash command, false otherwise
 *
 * @example
 * isIncompleteSlashCommand('/task', 'task') // returns true
 * isIncompleteSlashCommand('/task ', 'task') // returns true
 * isIncompleteSlashCommand('/task  ', 'task') // returns true
 * isIncompleteSlashCommand('/task hi', 'task') // returns false
 * isIncompleteSlashCommand('hi', null) // returns false
 */
export function isIncompleteSlashCommand(text: string, command: CopilotChatCommandType | null): boolean {
  // If no command detected, it's not an incomplete slash command
  if (!command) {
    return false
  }

  // Check if text is just the command with optional whitespace
  // Use a simple check: starts with /<command> and only has whitespace after
  // Use case-insensitive comparison
  const trimmedText = text.trim().toLowerCase()
  return trimmedText === `/${command.toLowerCase()}`
}
