import invariant from 'tiny-invariant'

import anthropicLogoBlack from './assets/anthropic-black.svg'
import anthropicLogoWhite from './assets/anthropic-white.svg'
import microsoftFoundryLogo from './assets/microsoft-foundry.svg'
import openaiLogoBlack from './assets/openai-black.svg'
import openaiLogoWhite from './assets/openai-white.svg'
import xaiLogoBlack from './assets/xai-black.svg'
import xaiLogoWhite from './assets/xai-white.svg'
import googleAIStudioLogoBlack from './assets/google-black.svg'
import googleAIStudioLogoWhite from './assets/google-white.svg'
import awsBedrockLogoBlack from './assets/awsbedrock-black.svg'
import awsBedrockLogoWhite from './assets/awsbedrock-white.svg'
import modelsLogoWhite from './assets/models-white.svg'
import modelsLogoBlack from './assets/models-black.svg'

export type ProviderItem = {
  key: Provider
  name: string
  logo: {
    /** Logo to use for light mode */
    light: string
    /** Logo to use for dark mode. The light mode logo will be used if the dark mode logo is not available */
    dark?: string
  }
}
type AllProviders = (typeof allProvidersList)[number]
export type Provider = AllProviders['key']
export type ProviderSchemaPreprocessorMapping = {
  [k in Provider]?: (payload: Record<string, unknown>) => Record<string, unknown>
}

/**
 * A list of all providers, adding a new provider here does not automatically make it available in the UI.
 * Apps consuming this decide which providers to show, see packages/copilot-byok-settings/hooks/use-providers.ts for example.
 */
export const allProvidersList = [
  {
    key: 'openai',
    name: 'OpenAI',
    logo: {
      light: openaiLogoBlack,
      dark: openaiLogoWhite,
    },
  },
  {
    key: 'azureai',
    name: 'Microsoft Foundry',
    logo: {light: microsoftFoundryLogo, dark: undefined},
  },
  {
    key: 'anthropic',
    name: 'Anthropic',
    logo: {
      light: anthropicLogoBlack,
      dark: anthropicLogoWhite,
    },
  },
  {
    key: 'googleaistudio',
    name: 'Google AI Studio',
    logo: {
      light: googleAIStudioLogoBlack,
      dark: googleAIStudioLogoWhite,
    },
  },
  {
    key: 'xai',
    name: 'xAI',
    logo: {
      light: xaiLogoBlack,
      dark: xaiLogoWhite,
    },
  },
  {
    key: 'awsbedrock',
    name: 'AWS Bedrock',
    logo: {
      light: awsBedrockLogoBlack,
      dark: awsBedrockLogoWhite,
    },
  },
  {
    key: 'openaicompatible',
    name: 'OpenAI Compatible',
    logo: {
      light: modelsLogoBlack,
      dark: modelsLogoWhite,
    },
  },
] as const

export function getProviderFor<P extends Provider>(key: P): Extract<AllProviders, {key: P}> {
  const provider = allProvidersList.find(p => p.key === key)
  invariant(provider, `Provider with key "${key}" not found`)
  return provider as Extract<AllProviders, {key: P}>
}

export function getSampleCustomKeyNameFor<P extends Provider>(key: P) {
  // Replace spaces with underscores so that our sample name is a valid one;
  // see https://github.com/github/github/blob/1f4af8d87ade9a51c1ec014e97a086a291bdaeef/packages/copilot_byok/app/models/copilot_byok/custom_key.rb#L54
  const providerName = getProviderFor(key).name.replaceAll(/\s+/g, '_')
  return `${providerName}_custom_key`
}

/**
 * Is the given model provider one whose API supports loading a list of available models for an API key?
 * @param provider the provider to check
 * @returns true when the provider's API has an endpoint to fetch models enabled by one of its API keys
 */
export function canFetchNewModelsFromProvider(provider: Provider) {
  return (
    provider === 'openai' ||
    provider === 'anthropic' ||
    provider === 'xai' ||
    provider === 'openaicompatible' ||
    provider === 'awsbedrock' ||
    provider === 'googleaistudio'
  )
}

export function providerApiKeyLabel(provider: Provider) {
  if (provider === 'awsbedrock') return 'Secret access key'
  return 'API key'
}

export const fieldsToEncrypt = ['api_key', 'access_key'] as const
