import {TasksListWrapper} from '@github-ui/agent-sessions/components/TaskList'
import {sendEvent} from '@github-ui/hydro-analytics'
import {NewAgentTaskButton} from '@github-ui/new-agent-task-button/NewAgentTaskButton'
import {Button} from '@github-ui/pacer/Button'
import {SidebarListItem} from '@github-ui/pacer/SidebarListItem'
import {SidebarNavigation, SidebarSection} from '@github-ui/pacer/SidebarNavigation'
import {Tooltip} from '@github-ui/pacer/Tooltip'
import {useFeatureFlag} from '@github-ui/react-core/use-feature-flag'
import {useLocation} from '@github-ui/react-router'
import {HistoryIcon, KebabHorizontalIcon, PlusIcon} from '@primer/octicons-react'
import {ActionList, ActionMenu, IconButton} from '@primer/react'
import {useCallback, useMemo, useRef, useState} from 'react'
import {flushSync} from 'react-dom'

import {useNavigateToNewThread} from '../../hooks/use-navigate-to-new-thread'
import {COPILOT_PATH, threadName} from '../../utils/copilot-chat-helpers'
import type {CopilotChatThread} from '../../utils/copilot-chat-types'
import {useChatStateValues} from '../../utils/CopilotChatContext'
import {useChatManager} from '../../utils/CopilotChatManagerContext'
import {
  type ConversationActionDialogName,
  ConversationActionDialogs,
  ConversationActions,
} from '../conversation/ConversationActions'
import styles from './ActivityPanel.module.css'

function ConversationListWrapper({
  handleSidebarClick,
  title,
  trailingAction,
}: {
  handleSidebarClick: () => void
  title?: string
  trailingAction?: React.ReactNode
}) {
  const location = useLocation()
  const isSharedThread = location.pathname.includes('/share/')
  const {threadsLoading, selectedThreadID, threads} = useChatStateValues(
    'threadsLoading',
    'selectedThreadID',
    'threads',
  )
  const manager = useChatManager()

  const conversationItems = useMemo(() => {
    return manager.sortAndFilterThreads(threads).map(thread => ({
      id: thread.id,
      text: threadName(thread),
      href: `${COPILOT_PATH}/c/${thread.id}`,
      date: new Date(thread.updatedAt),
    }))
  }, [threads, manager])

  const isEmpty = conversationItems.length === 0
  const isLoading = threadsLoading.state === 'loading' || threadsLoading.state === 'pending'

  return (
    <SidebarSection title={title} isEmpty={isEmpty} isLoading={isLoading} trailingAction={trailingAction}>
      {conversationItems.map(item => (
        <ConversationListEntry
          key={item.id}
          item={item}
          selectedItemId={isSharedThread ? undefined : (selectedThreadID ?? undefined)}
          onSelect={handleSidebarClick}
          threads={threads}
        />
      ))}
    </SidebarSection>
  )
}

interface ConversationListEntryProps {
  item: {
    id: string
    text: string
    href: string
    date: Date
  }
  selectedItemId?: string
  onSelect: () => void
  threads: Map<string, CopilotChatThread>
}

function ConversationListEntry({item, selectedItemId, onSelect, threads}: ConversationListEntryProps) {
  const selected = item.id === selectedItemId
  const [dialog, setDialog] = useState<ConversationActionDialogName | null>(null)
  const [loading, setLoading] = useState(false)
  const startLoading = useCallback(() => setLoading(true), [])
  const finishLoading = useCallback(() => setLoading(false), [])
  const selectedThread = threads.get(selectedItemId!)
  const isSpace = Boolean(selectedThread?.customCopilotID)
  const anchorRef = useRef<HTMLButtonElement>(null)

  const closeDialog = useCallback(() => {
    // eslint-disable-next-line @eslint-react/dom/no-flush-sync
    flushSync(() => setDialog(null))
    anchorRef.current?.focus()
  }, [anchorRef])

  const trailingAction = (
    <>
      <ActionMenu anchorRef={anchorRef}>
        <ActionMenu.Anchor>
          <IconButton
            loading={loading}
            icon={KebabHorizontalIcon}
            aria-label="Manage chat"
            variant="invisible"
            onClick={() =>
              sendEvent('dotcom_chat.activate', {
                target: 'CONVERSATION_CONTEXT_MENU',
                mode: 'immersive',
              })
            }
          />
        </ActionMenu.Anchor>
        <ActionMenu.Overlay>
          <ActionList>
            <ConversationActions
              onOpenDialog={setDialog}
              isShared={Boolean(threads.get(item.id)?.sharedID)}
              showShare={!isSpace}
              threadName={item.text}
              threadId={item.id}
            />
          </ActionList>
        </ActionMenu.Overlay>
      </ActionMenu>
      <ConversationActionDialogs
        visibleDialog={dialog}
        onClose={closeDialog}
        threadName={item.text}
        threadId={item.id}
        selectedThreadId={selectedItemId}
        onStartLoading={startLoading}
        onFinishLoading={finishLoading}
        returnFocusRef={anchorRef}
      />
    </>
  )

  return (
    <SidebarListItem
      href={item.href}
      text={item.text}
      isSelected={selected}
      trailingAction={trailingAction}
      onClick={() => {
        onSelect()
        sendEvent('dotcom_chat.activate', {
          target: 'CONVERSATION_SELECT',
          threadId: item.id,
          mode: 'immersive',
        })
      }}
    />
  )
}

export function ActivityPanel({
  handleSidebarClick,
  isCondensed,
  onToggleSidebar,
}: {
  handleSidebarClick: () => void
  isCondensed: boolean
  onToggleSidebar: () => void
}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const navigateToNewThread = useNavigateToNewThread()
  const decoupledModeEnabled = useFeatureFlag('copilot_mission_control_decoupled_mode')

  const expandPanel = useCallback(() => {
    if (isCondensed) {
      onToggleSidebar()
    }
  }, [isCondensed, onToggleSidebar])

  const closeMenu = useCallback(() => setIsMenuOpen(false), [])

  const handleNewChat = useCallback(async () => {
    if (isCondensed) {
      closeMenu()
    } else {
      handleSidebarClick()
    }
    await navigateToNewThread({clearTopic: true, includeThreads: false})

    sendEvent('dotcom_chat.activate', {target: 'SIDEBAR_CONVERSATION_NEW', mode: 'immersive'})
  }, [handleSidebarClick, navigateToNewThread, isCondensed, closeMenu])

  const newAgentTaskButton = (
    <NewAgentTaskButton
      isIconButton
      icon={PlusIcon}
      label="New agent session"
      onOpen={() =>
        sendEvent('agent_sessions.task_view', {
          target: 'CREATE_TASK_FROM_CHAT_BUTTON',
        })
      }
      onClose={expandPanel}
      eventType="activity_panel"
      size="small"
      tooltipDirection="e"
      variant="invisible"
      decoupledModeEnabled={decoupledModeEnabled}
    />
  )

  const getSidebarContent = () => {
    return (
      <SidebarNavigation isCondensed={false} aria-label="Navigation">
        <TasksListWrapper
          showTitle
          trailingAction={newAgentTaskButton}
          onTaskClick={isCondensed ? closeMenu : undefined}
        />
        <ConversationListWrapper
          title="Chats"
          trailingAction={
            <IconButton
              icon={PlusIcon}
              variant="invisible"
              aria-label="New chat"
              size="small"
              tooltipDirection="e"
              onClick={handleNewChat}
            />
          }
          handleSidebarClick={handleSidebarClick}
        />
      </SidebarNavigation>
    )
  }

  return isCondensed ? (
    <div className={styles.compactContainer}>
      <div className={styles.compactAgentsMenu}>
        <ActionMenu open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <ActionMenu.Anchor>
            <Tooltip text="Agent sessions and chats">
              <Button
                aria-label="Agent sessions and chats"
                icon={<HistoryIcon />}
                iconOnly
                size="medium"
                variant="invisible"
              />
            </Tooltip>
          </ActionMenu.Anchor>
          <ActionMenu.Overlay
            width="medium"
            side="outside-right"
            align="start"
            maxHeight="xlarge"
            className={styles.overlay}
          >
            <div>{getSidebarContent()}</div>
          </ActionMenu.Overlay>
        </ActionMenu>
        <div className={styles.largeButton}>{newAgentTaskButton}</div>
      </div>
    </div>
  ) : (
    getSidebarContent()
  )
}
