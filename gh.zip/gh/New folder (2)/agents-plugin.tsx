// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import type {ImmersivePlugin, NavigationItem, PluginComponent} from '@github-ui/copilot-chat/plugin'
import {AgentsViewWrapper} from './components/agents-view/AgentsView'
import {AGENTS_PLUGIN_ID, AGENTS_PATH, AGENTS_PLUGIN_NAME} from './utils/constants'
import {AgentsIcon16} from './components/AgentsIcon'
import {AgentIcon} from '@primer/octicons-react'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {copilotLocalStorage} from '@github-ui/copilot-chat/utils/copilot-local-storage'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {COPILOT_PATH} from '@github-ui/copilot-chat/utils/copilot-chat-helpers'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import type {CopilotChatState} from '@github-ui/copilot-chat/utils/copilot-chat-reducer'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {ModeSupportName} from '@github-ui/copilot-chat/utils/copilot-chat-types'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {copilotFeatureFlags} from '@github-ui/copilot-chat/utils/copilot-feature-flags'
import {isFeatureEnabled} from '@github-ui/feature-flags'
import type {useNavigate} from '@github-ui/use-navigate'
import {submitTask} from './utils/submit-task'
import type {MutableRefObject} from 'react'
import type {HandleUserSubmit} from './types/user-submit'
import {SlashCommandModelPicker} from './components/slash-command-model-picker/SlashCommandModelPicker'
import type {SelectedAgent} from './types/session'

const AGENTS_REGEX = /\/copilot\/agents/
export const COPILOT_AGENTS_PATH = `${COPILOT_PATH}/agents`

export class AgentsPlugin implements ImmersivePlugin {
  id = AGENTS_PLUGIN_ID

  displayName = AGENTS_PLUGIN_NAME

  constructor(
    createTaskFromInput: boolean = false,
    handleUserSubmitRef?: MutableRefObject<HandleUserSubmit>,
    agentsEnabled: boolean = false,
  ) {
    this.createTaskFromInput = createTaskFromInput
    this.handleUserSubmitRef = handleUserSubmitRef
    this.agentsEnabled = agentsEnabled
  }

  createTaskFromInput: boolean

  handleUserSubmitRef: MutableRefObject<HandleUserSubmit> | undefined

  agentsEnabled: boolean

  skipSyncRouteToThread = true

  components: PluginComponent[] = [
    {
      id: 'agents-view',
      Component: AgentsViewWrapper,
      routes: [AGENTS_REGEX],
    },
  ]

  slashCommand = {
    key: 'task',
    name: 'Task',
    description: 'Give Copilot coding agent a background task',
    icon: AgentIcon,
    order: 1,
    enabled: () => this.agentsEnabled,
    disabledAction: (navigate: ReturnType<typeof useNavigate>) => {
      navigate(COPILOT_AGENTS_PATH, {preventTurbo: true})
    },
    execute: async (params: string, chatState: CopilotChatState, navigate: ReturnType<typeof useNavigate>) => {
      // If this is an existing chat thread, we want to send a chat message instead of navigating to the agents page.
      if (
        this.agentsEnabled &&
        chatState.selectedThreadID &&
        isFeatureEnabled('copilot_immersive_task_within_chat_thread')
      ) {
        return false
      }

      // If agents are enabled and we can create tasks directly, do that
      if (this.agentsEnabled && this.createTaskFromInput && this.handleUserSubmitRef) {
        submitTask(params, this.handleUserSubmitRef)
        return true
      }

      // Otherwise, always navigate to agents page (for disabled agents or when we can't create tasks directly)
      copilotLocalStorage.setTaskEntrypointMessage(params)
      navigate(COPILOT_AGENTS_PATH, {preventTurbo: true})
      return true
    },
    suggestions: [
      'Identify and suggest improvements to slow or inefficient code',
      'Find and refactor duplicated code',
      'Suggest more descriptive variable and function names',
    ],
    mode: {
      name: ModeSupportName.Task,
      icon: AgentIcon,
      placeholder: 'Make a change in your codebase',
      supportsModelSwitching: copilotFeatureFlags.codingAgentModelSelection,
      supportsReferenceAttachments: isFeatureEnabled('copilot_agent_image_upload'),
      supportedReferenceTypes: isFeatureEnabled('copilot_agent_image_upload') ? (['image'] as const) : undefined,
      supportsAttachmentsMenu: isFeatureEnabled('copilot_agent_image_upload') ? false : undefined,
    },
    customModelPicker: ({selectedAgent}: {selectedAgent?: SelectedAgent}) => (
      <SlashCommandModelPicker selectedAgent={selectedAgent} />
    ),
  }

  navigationItems: NavigationItem[] = [
    {
      id: AGENTS_PLUGIN_ID,
      displayName: 'Agents',
      href: AGENTS_PATH,
      icon: AgentsIcon16,
    },
  ]
}
