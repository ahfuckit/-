import {CodeMirrorDiff} from '@github-ui/code-mirror/CodeMirrorDiff'
import {MarkdownRenderer} from '@github-ui/copilot-markdown'
import {Button, Heading} from '@primer/react'
import {clsx} from 'clsx'
import {useEffect, useId, useState} from 'react'

import type {
  CopilotAgentConfirmation,
  CopilotClientConfirmation,
  CopilotClientConfirmationState,
  CreateOrUpdateFileConfirmationData,
  PushFilesConfirmationData,
  ToolCallConfirmation,
} from '../utils/copilot-chat-types'
// eslint-disable-next-line no-restricted-imports
import {useChatState} from '../utils/CopilotChatContext'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import styles from './Confirmation.module.css'

export interface ConfirmationProps {
  confirmation: CopilotAgentConfirmation
  handleConfirmation: (
    clientConfirmation: CopilotClientConfirmation,
    confirmationTitle: string,
    onSubmit?: (accepted: boolean) => void,
  ) => void
  isLatestMessage?: boolean
}

function isCreateOrUpdateFileConfirmationData(data: string): boolean {
  try {
    const parsed = JSON.parse(data)
    return (
      typeof parsed === 'object' &&
      parsed !== null &&
      typeof parsed.content === 'string' &&
      typeof parsed.path === 'string' &&
      typeof parsed.repo === 'string' &&
      typeof parsed.owner === 'string' &&
      typeof parsed.message === 'string' &&
      (parsed.sha === undefined || typeof parsed.sha === 'string') &&
      (parsed.branch === undefined || typeof parsed.branch === 'string')
    )
  } catch {
    return false
  }
}

function isPushFilesConfirmationData(data: string): boolean {
  try {
    const parsed = JSON.parse(data)
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    return (
      typeof parsed === 'object' &&
      parsed !== null &&
      Array.isArray(parsed.files) &&
      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
      parsed.files.every(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (file: any) =>
          typeof file === 'object' &&
          file !== null &&
          typeof file.path === 'string' &&
          typeof file.content === 'string',
      ) &&
      (parsed.branch === undefined || typeof parsed.branch === 'string') &&
      (parsed.message === undefined || typeof parsed.message === 'string') &&
      (parsed.owner === undefined || typeof parsed.owner === 'string') &&
      (parsed.repo === undefined || typeof parsed.repo === 'string')
    )
  } catch {
    return false
  }
}

function ConfirmationInner({
  confirmation,
  actionTaken,
  isWaitingOnCopilot,
  handleUserAction,
}: {
  confirmation: CopilotAgentConfirmation
  actionTaken: boolean
  isWaitingOnCopilot: boolean
  handleUserAction: (action: CopilotClientConfirmationState) => void
}) {
  return (
    <div className={clsx('border rounded-2', styles.ConfirmationContainer)}>
      <Heading as="h3" className={styles.confirmationTitle}>
        {confirmation.title}
      </Heading>
      {confirmation.message.split('\n').map(message => (
        <p key={message} className={styles.confirmationMessage}>
          {message}
        </p>
      ))}
      {!actionTaken && (
        <div className={styles.actionButtonsContainer}>
          <Button disabled={isWaitingOnCopilot} variant="primary" onClick={() => handleUserAction('accepted')}>
            Allow
          </Button>
          <Button disabled={isWaitingOnCopilot} onClick={() => handleUserAction('dismissed')}>
            Dismiss
          </Button>
        </div>
      )}
    </div>
  )
}

export function Confirmation({confirmation, handleConfirmation, isLatestMessage}: ConfirmationProps) {
  const state = useChatState()
  const confirmationConfirmation = JSON.stringify(Object.values(confirmation.confirmation).sort())
  const clientConfirmationExists = state.allClientConfirmations?.includes(confirmationConfirmation)
  const {isWaitingOnCopilot, currentUserLogin} = state
  const [actionTaken, setActionTaken] = useState(Boolean(clientConfirmationExists && !isLatestMessage))
  const handleUserAction = (action: CopilotClientConfirmationState) => {
    setActionTaken(true)
    handleConfirmation(
      {state: action, userLogin: currentUserLogin, confirmation: confirmation.confirmation},
      confirmation.title,
      confirmation.onSubmit,
    )
  }
  const manager = useChatManager()
  const confirmationId = useId()
  const toolCall = confirmation.confirmation as ToolCallConfirmation

  // Try parsing as CreateOrUpdateFileConfirmationData
  if (isCreateOrUpdateFileConfirmationData(toolCall.arguments)) {
    const confirmationData = JSON.parse(toolCall.arguments) as CreateOrUpdateFileConfirmationData
    if (confirmationData.sha) {
      // We have original content to compare against
      return (
        <UpdateFileWithDiff
          confirmationData={confirmationData}
          manager={manager}
          confirmation={confirmation}
          actionTaken={actionTaken}
          isWaitingOnCopilot={isWaitingOnCopilot}
          handleUserAction={handleUserAction}
          confirmationId={confirmationId}
        />
      )
    } else {
      // Single file without diff
      return (
        <CodeConfirmationInner
          files={[{path: confirmationData.path, content: confirmationData.content}]}
          confirmation={confirmation}
          actionTaken={actionTaken}
          isWaitingOnCopilot={isWaitingOnCopilot}
          handleUserAction={handleUserAction}
        />
      )
    }
  }

  // Try parsing as PushFilesConfirmationData
  if (isPushFilesConfirmationData(toolCall.arguments)) {
    const confirmationData = JSON.parse(toolCall.arguments) as PushFilesConfirmationData
    return (
      <CodeConfirmationInner
        files={confirmationData.files || []}
        confirmation={confirmation}
        actionTaken={actionTaken}
        isWaitingOnCopilot={isWaitingOnCopilot}
        handleUserAction={handleUserAction}
      />
    )
  }

  // Otherwise, use generic confirmation message
  return (
    <ConfirmationInner
      confirmation={confirmation}
      actionTaken={actionTaken}
      isWaitingOnCopilot={isWaitingOnCopilot}
      handleUserAction={handleUserAction}
    />
  )
}

function CodeConfirmationInner({
  files,
  confirmation,
  actionTaken,
  isWaitingOnCopilot,
  handleUserAction,
}: {
  files: Array<{path?: string; content: string}>
  confirmation: CopilotAgentConfirmation
  actionTaken: boolean
  isWaitingOnCopilot: boolean
  handleUserAction: (action: CopilotClientConfirmationState) => void
}) {
  return (
    <div className={clsx('border rounded-2', styles.ConfirmationContainer)}>
      <Heading as="h3" className={styles.confirmationTitle}>
        {'Make these code changes?'}
      </Heading>
      {files.map((file, index) => {
        const language = file.path ? file.path.split('.').pop() || 'text' : 'text'
        const markdown = `\`\`\`${language}\n${file.content}\n\`\`\``
        return (
          <div key={file.path || index} className={styles.codeMargin}>
            <p className={styles.pathText}>{file.path}</p>
            <MarkdownRenderer markdown={markdown} />
          </div>
        )
      })}
      {confirmation.message.split('\n').map(message => (
        <p key={message} className={styles.confirmationMessage}>
          {message}
        </p>
      ))}
      {!actionTaken && (
        <div className={styles.actionButtonsContainer}>
          <Button disabled={isWaitingOnCopilot} variant="primary" onClick={() => handleUserAction('accepted')}>
            Allow
          </Button>
          <Button disabled={isWaitingOnCopilot} onClick={() => handleUserAction('dismissed')}>
            Dismiss
          </Button>
        </div>
      )}
    </div>
  )
}

function UpdateFileWithDiff({
  confirmationData,
  manager,
  confirmation,
  actionTaken,
  isWaitingOnCopilot,
  handleUserAction,
  confirmationId,
}: {
  confirmationData: CreateOrUpdateFileConfirmationData
  manager: ReturnType<typeof useChatManager>
  confirmation: CopilotAgentConfirmation
  actionTaken: boolean
  isWaitingOnCopilot: boolean
  handleUserAction: (action: CopilotClientConfirmationState) => void
  confirmationId: string
}) {
  const [originalContent, setOriginalContent] = useState<string>('')
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  useEffect(() => {
    async function fetchOriginalContent() {
      try {
        setIsLoading(true)
        const result = await manager.service.fetchFileContentsNwo(
          confirmationData.owner,
          confirmationData.repo,
          confirmationData.path,
          confirmationData.branch,
        )
        if (result.ok && result.payload) {
          setOriginalContent(result.payload.content)
        } else {
          setError('Failed to fetch original file content')
        }
      } catch {
        setError('Error fetching original file content')
      } finally {
        setIsLoading(false)
      }
    }

    void fetchOriginalContent()
  }, [confirmationData, manager.service])

  if (isLoading) {
    return (
      <div className={clsx('border rounded-2', styles.ConfirmationContainer)}>
        <Heading as="h3" className={styles.confirmationTitle}>
          Loading file diff...
        </Heading>
      </div>
    )
  }

  // If we fail to fetch the original file content, fall back to displaying the full file
  if (error) {
    return (
      <CodeConfirmationInner
        files={[{path: confirmationData.path, content: confirmationData.content}]}
        confirmation={confirmation}
        actionTaken={actionTaken}
        isWaitingOnCopilot={isWaitingOnCopilot}
        handleUserAction={handleUserAction}
      />
    )
  }
  return (
    <div id={confirmationId} className={clsx('border rounded-2', styles.ConfirmationContainer)}>
      <Heading as="h3" className={styles.confirmationTitle}>
        {'Make these code changes?'}
      </Heading>
      <div className={styles.codeMargin}>
        <p className={styles.pathText}>{confirmationData.path}</p>
        <CodeMirrorDiff
          fileName={confirmationData.path}
          left={originalContent}
          right={confirmationData.content}
          leftLabelledBy={''}
          rightLabelledBy={''}
          unifiedLabelledBy={confirmationId}
          spacing={{
            indentUnit: 2,
            indentWithTabs: false,
            lineWrapping: true,
          }}
          view="unified"
        />
      </div>
      {confirmation.message.split('\n').map(message => (
        <p key={message} className={styles.confirmationMessage}>
          {message}
        </p>
      ))}
      {!actionTaken && (
        <div className={styles.actionButtonsContainer}>
          <Button disabled={isWaitingOnCopilot} variant="primary" onClick={() => handleUserAction('accepted')}>
            Allow
          </Button>
          <Button disabled={isWaitingOnCopilot} onClick={() => handleUserAction('dismissed')}>
            Dismiss
          </Button>
        </div>
      )}
    </div>
  )
}
