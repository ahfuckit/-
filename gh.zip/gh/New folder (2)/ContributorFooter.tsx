import {InfoIcon} from '@primer/octicons-react'
import {Link} from '@primer/react'
import type {BetterSystemStyleObject} from '@primer/styled-react'
import {Box} from '@primer/styled-react'
import {Octicon} from '@primer/react/deprecated'

import {Fragment, useMemo} from 'react'
import {isEnterprise} from '@github-ui/runtime-environment'
import {clsx} from 'clsx'
import styles from './ContributorFooter.module.css'

export type ContributorFooterProps = {
  contributingFileUrl?: string
  securityPolicyUrl?: string
  codeOfConductFileUrl?: string
  supportFileUrl?: string
  sx?: BetterSystemStyleObject
  className?: string
}

export function ContributorFooter(props: ContributorFooterProps) {
  const {contributingFileUrl, securityPolicyUrl, codeOfConductFileUrl, supportFileUrl} = props

  if (isEnterprise() || (!contributingFileUrl && !securityPolicyUrl && !codeOfConductFileUrl && !supportFileUrl))
    return null

  return <ContributorFooterContent {...props} />
}

function ContributorFooterContent({
  contributingFileUrl,
  securityPolicyUrl,
  codeOfConductFileUrl,
  supportFileUrl,
  sx,
  className,
}: ContributorFooterProps) {
  const links = useMemo(() => {
    const existingLinks = []

    if (contributingFileUrl) {
      existingLinks.push(
        <Link inline href={contributingFileUrl}>
          contributing guidelines
        </Link>,
      )
    }

    if (securityPolicyUrl) {
      existingLinks.push(
        <Link inline href={securityPolicyUrl}>
          security policy
        </Link>,
      )
    }

    if (codeOfConductFileUrl) {
      existingLinks.push(
        <Link inline href={codeOfConductFileUrl}>
          code of conduct
        </Link>,
      )
    }
    if (supportFileUrl) {
      existingLinks.push(
        <Link inline href={supportFileUrl}>
          Support
        </Link>,
      )
    }

    if (existingLinks.length === 1) return <>{existingLinks[0]}</>

    const allLinksExceptLast = existingLinks.slice(0, -1)
    const lastLink = existingLinks[existingLinks.length - 1]
    return (
      <>
        {allLinksExceptLast.map((link, i) => (
          // eslint-disable-next-line @eslint-react/no-array-index-key
          <Fragment key={i}>
            {link}
            <span>{i !== allLinksExceptLast.length - 1 ? ', ' : ' '}</span>
          </Fragment>
        ))}
        <span>and {lastLink}</span>
      </>
    )
  }, [contributingFileUrl, securityPolicyUrl, codeOfConductFileUrl, supportFileUrl])

  return (
    <Box data-testid="contributor-footer" sx={sx} className={clsx(styles.ContributorFooterContainer, className)}>
      <Octicon icon={InfoIcon} />
      <div data-testid="contributor-footer-text">
        {/*
          🚨 Heads up! These spans are like a house of cards - touch them and
          built-in browser translation will wreak havoc on the DOM and react will crash.
          Proceed with extreme caution! 🏗️
        */}
        <span>Remember, contributions to this repository should follow its </span>
        <span>{links}</span>
        <span>.</span>
      </div>
    </Box>
  )
}
