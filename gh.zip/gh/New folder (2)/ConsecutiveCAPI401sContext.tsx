import {createContext, use, useState, useMemo} from 'react'

export const ConsecutiveCAPI401sContext = createContext<ConsecutiveCAPI401sType | undefined>(undefined)

interface ConsecutiveCAPI401sType {
  numberOf401s: number
  increment401s: () => void
  reset401s: () => void
}

export function useConsecutiveCAPI401sContext() {
  const context = use(ConsecutiveCAPI401sContext)
  if (!context) {
    throw new Error('useConsecutiveCAPI401sContext must be used within a ConsecutiveCAPI401sProvider')
  }
  return context
}

interface ConsecutiveCAPI401sProviderProps {
  children: React.ReactNode
}

// Tracks authentication failures in CAPI requests.
export function ConsecutiveCAPI401sProvider({children}: ConsecutiveCAPI401sProviderProps) {
  const [numberOf401s, setNumberOf401s] = useState(0)
  const properties = useMemo(
    () => ({
      numberOf401s,
      increment401s: () => setNumberOf401s(prev => prev + 1),
      reset401s: () => setNumberOf401s(0),
    }),
    [numberOf401s],
  )

  return <ConsecutiveCAPI401sContext value={properties}>{children}</ConsecutiveCAPI401sContext>
}
