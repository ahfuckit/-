import {useState, useEffect} from 'react'
import {ShieldIcon} from '@primer/octicons-react'
import {Button} from '@primer/react'
import {ssrSafeLocation} from '@github-ui/ssr-utils'
import {ownerAvatarPath} from '@github-ui/paths'
import type {CodeInsightsInfo} from '../../../../types/code-insights-metadata'
import {CodeInsightsDialog} from './CodeInsightsDialog'
import styles from './CodeInsights.module.css'

/**
 * Builds the full avatar URL for an owner, matching the logic in GitHubAvatar.
 * GitHubAvatar doubles the display size for high-density screens (size={20} → ?size=40).
 * Keep in sync with the size prop passed to GitHubAvatar in CodeInsightsDialog's RepositoryAvatar.
 */
function buildAvatarUrl(owner: string): string {
  const url = new URL(ownerAvatarPath({owner}), ssrSafeLocation.origin)
  url.searchParams.set('size', String(20 * 2))
  return url.toString()
}

/**
 * Preloads avatar images so they are cached by the browser before the dialog opens.
 * Appends <link rel="prefetch"> elements to <head> and removes them on cleanup.
 */
function usePreloadAvatars(insights: CodeInsightsInfo) {
  const references = insights.publicCodeReferences

  useEffect(() => {
    const owners = new Set<string>()
    for (const ref of references) {
      if (ref.nwo) {
        const [owner] = ref.nwo.split('/')
        if (owner) owners.add(owner)
      }
    }

    const links: HTMLLinkElement[] = []
    for (const owner of owners) {
      const link = document.createElement('link')
      link.rel = 'prefetch'
      link.setAttribute('as', 'image')
      link.href = buildAvatarUrl(owner)
      document.head.appendChild(link)
      links.push(link)
    }

    return () => {
      for (const link of links) {
        link.remove()
      }
    }
  }, [references])
}

/**
 * Small icon in toolHeader that displays when code insights are available for the tool call.
 * Clicking opens the CodeInsightsDialog.
 */
export function CodeInsightsIndicator({insights}: {insights: CodeInsightsInfo}) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const totalCount = insights.publicCodeReferences.length

  // Preload avatar images so the dialog opens instantly
  usePreloadAvatars(insights)

  if (totalCount === 0) {
    return null
  }

  const handleClick = (event: React.MouseEvent) => {
    event.stopPropagation() // Prevent tool header toggle
    setIsDialogOpen(true)
  }

  const indicatorText = `Similar to public code`

  return (
    <div className={styles.indicatorContainer}>
      <Button
        variant="invisible"
        aria-label={indicatorText}
        onClick={handleClick}
        className={styles.indicatorButton}
        leadingVisual={ShieldIcon}
        size="small"
      >
        <span className={styles.indicatorText}>{indicatorText}</span>
      </Button>
      <CodeInsightsDialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)} insights={insights} />
    </div>
  )
}
