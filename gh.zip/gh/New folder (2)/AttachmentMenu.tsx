import {CreateSpaceDialog} from '@github-ui/copilot-spaces/components/CreateSpaceDialog'
import {SpacesSelectNew} from '@github-ui/copilot-spaces/components/SpacesSelectNew'
import {useSpaceSelection} from '@github-ui/copilot-spaces/hooks/use-space-selection'
import {sendEvent} from '@github-ui/hydro-analytics'
import {testIdProps} from '@github-ui/test-id-props'
import type {AnchorSide} from '@primer/behaviors'
import {FileCodeIcon, RepoIcon, UploadIcon} from '@primer/octicons-react'
import {ActionList, ActionMenu} from '@primer/react'
import {memo, type RefObject, useRef, useState} from 'react'

import {getReferenceTypeLabel, useSupportedAttachmentTypes} from '../hooks/use-supported-attachment-types'
import {usePlugins} from '../plugin/ImmersivePluginsProvider'
import {useInsertAgent, type UseInsertAgentProps} from '../utils/agents-helpers'
import type {CopilotChatRepo} from '../utils/copilot-chat-types'
import {copilotFeatureFlags} from '../utils/copilot-feature-flags'
import {CopilotImageAttacher} from '../utils/copilot-image-attacher'
import {CopilotTextAttacher} from '../utils/copilot-text-attacher'
// eslint-disable-next-line no-restricted-imports
import {useChatState, useChatStateValues} from '../utils/CopilotChatContext'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import {AgentMenu} from './AgentMenu'
import {AgentsNotSupportedDialog, NoAgentsAvailableDialog} from './AgentsDialogs'
import type {AttachmentMenuPanelType} from './AttachmentMenuPanelType'
import {CopilotFilePicker} from './CopilotFilePicker'
import {COPILOT_CHAT_MENU_PORTAL_ROOT} from './PortalContainerUtils'
import {RepoReferencesSelectPanel} from './RepoSelectPanel'

export interface AttachmentMenuProps extends UseInsertAgentProps {
  panel: AttachmentMenuPanelType | null
  onPanelChange: React.Dispatch<React.SetStateAction<AttachmentMenuPanelType | null>>
  anchorRef: RefObject<HTMLButtonElement | null>
  initialRepo?: CopilotChatRepo | null
  onRepoSelect?: (repo: CopilotChatRepo | null) => void
  side?: AnchorSide
}

export const AttachmentMenu = memo(
  ({panel, onPanelChange: setPanel, anchorRef, initialRepo, onRepoSelect, ...props}: AttachmentMenuProps) => {
    const {inputRef} = props
    const manager = useChatManager()
    const state = useChatState()
    const plugins = usePlugins()
    const {supportedAttachmentTypes, supportedReferenceTypes} = useSupportedAttachmentTypes()

    // For now, we are focused on building out image support in immersive mode only, and only for supported models.
    const {model} = useChatStateValues('model')
    const previewFeaturesDisabled =
      copilotFeatureFlags.previewFeaturesVisionGate && state.hasCEorCBAccess && !state.optedInToPreviewFeatures
    const imageUploadsEnabled =
      (state.mode === 'immersive' && !!model.capabilities?.supports?.vision && !previewFeaturesDisabled) || false

    const insertAgent = useInsertAgent(props)

    const fileInputRef = useRef<HTMLInputElement>(null)

    const {
      handleSpaceSelect: setPendingSpace,
      clearSpaceSelection,
      activeCopilotSpaceId,
      readOnly,
    } = useSpaceSelection()
    const [showCreateSpaceDialog, setShowCreateSpaceDialog] = useState(false)

    return (
      <div>
        {supportedAttachmentTypes.includes('upload') && (
          <input
            id="image-uploader"
            {...testIdProps('image-uploader')}
            hidden
            ref={fileInputRef}
            type="file"
            accept={[
              imageUploadsEnabled ? CopilotImageAttacher.getAllowedImageFileExtensions(model) : '',
              CopilotTextAttacher.getTextFileExtensions(),
            ].join(',')}
            multiple
            onChange={e => {
              if (!e.target.files) return

              // Split the image files out of the other files so we can handle them separately.
              const [imageFiles, otherFiles] = CopilotImageAttacher.getAllowedFiles([...e.target.files], model)

              // Files that we do not support uploading. We will log each of these later.
              const unsupportedFiles = []

              if (imageUploadsEnabled) {
                const attacher = new CopilotImageAttacher(state, manager)
                void attacher.addImageAttachments(imageFiles, 'menu')
              } else {
                unsupportedFiles.push(...imageFiles)
              }

              for (const file of otherFiles) {
                const attacher = new CopilotTextAttacher(manager)
                void attacher.addAttachment(file)
              }

              for (const file of unsupportedFiles) {
                sendEvent('dotcom_chat.upload_unsupported_file', {name: file.name, type: file.type, size: file.size})
              }

              // We want to make sure this onChange handler is fired every time a selection is made, even if the
              // same file is selected twice in a row.
              e.currentTarget.value = ''
            }}
          />
        )}
        <ActionMenu
          anchorRef={anchorRef}
          open={panel === 'attachment-types'}
          onOpenChange={newOpen =>
            setPanel(currentOpen => {
              // The menu should only be able to close the menu, not the other panel types. Otherwise it will autoclose
              // the dialogs as soon as they open as it tries to close itself.
              if (newOpen && currentOpen === null) return 'attachment-types'
              if (!newOpen && currentOpen === 'attachment-types') return null
              return currentOpen
            })
          }
        >
          <ActionMenu.Overlay
            width="small"
            side={props.side ?? 'outside-bottom'}
            position={state.mode === 'assistive' ? 'relative' : undefined}
            align="start"
            portalContainerName={state.mode === 'assistive' ? COPILOT_CHAT_MENU_PORTAL_ROOT : undefined}
          >
            <ActionList>
              {!copilotFeatureFlags.copilotChatRepositoryPicker &&
                supportedAttachmentTypes.includes('repositories') && (
                  <ActionList.Item
                    onSelect={() => {
                      sendEvent('dotcom_chat.activate', {
                        target: 'ATTACHMENT_MENU_REPOSITORIES',
                        action: 'open',
                        component: 'ATTACHMENT_MENU',
                        mode: state.mode,
                      })
                      setPanel('repositories')
                    }}
                  >
                    <ActionList.LeadingVisual>
                      <RepoIcon />
                    </ActionList.LeadingVisual>
                    Repositories&hellip;
                  </ActionList.Item>
                )}
              <ActionList.Item
                onSelect={() => {
                  sendEvent('dotcom_chat.activate', {target: 'ATTACHMENT_MENU_MULTI_FILE_PICKER', mode: state.mode})
                  setPanel('multi-file-picker')
                }}
              >
                <ActionList.LeadingVisual>
                  <FileCodeIcon />
                </ActionList.LeadingVisual>
                {getReferenceTypeLabel(supportedReferenceTypes)}&hellip;
              </ActionList.Item>

              {supportedAttachmentTypes.includes('copilot-spaces') && (
                <SpacesSelectNew
                  openCreateSpaceDialog={setShowCreateSpaceDialog}
                  setPendingSpace={setPendingSpace}
                  clearSpaceSelection={clearSpaceSelection}
                  activeCopilotSpaceId={activeCopilotSpaceId}
                  readOnly={readOnly}
                />
              )}

              {plugins.map(p => {
                const contribution = p.attachmentMenuContribution
                if (!contribution) return null
                return (
                  <contribution.MenuItemComponent key={p.id} onSelect={() => setPanel(contribution.attachmentType)} />
                )
              })}

              {supportedAttachmentTypes.includes('upload') && (
                <>
                  <ActionList.Divider />
                  <ActionList.Item
                    onSelect={() => {
                      sendEvent('dotcom_chat.activate', {target: 'ATTACHMENT_MENU_IMAGES', mode: state.mode})
                      // ensure panel is closed before file input is open
                      setPanel(null)
                      fileInputRef.current?.click()
                    }}
                  >
                    <ActionList.LeadingVisual>
                      <UploadIcon />
                    </ActionList.LeadingVisual>
                    Upload from computer
                  </ActionList.Item>
                </>
              )}
              {supportedAttachmentTypes.includes('agents') && !copilotFeatureFlags.hideExtensionsInDotcomChat && (
                <>
                  <ActionList.Divider />
                  <AgentMenu
                    onSelectPanel={value => setPanel(value)}
                    // setTimeout required to pull focus after ActionMenu tries to return to anchor
                    onSelectAgent={agent => setTimeout(() => insertAgent(agent.slug))}
                  />
                </>
              )}
            </ActionList>
          </ActionMenu.Overlay>
        </ActionMenu>

        {panel === 'multi-file-picker' && (
          <CopilotFilePicker
            isOpen
            onClose={() => setPanel(null)}
            initialRepo={initialRepo}
            onRepoSelect={onRepoSelect}
          />
        )}

        {!copilotFeatureFlags.copilotChatRepositoryPicker && (
          <RepoReferencesSelectPanel
            open={panel === 'repositories'}
            onOpenChange={val => setPanel(val ? 'repositories' : null)}
            submitReturnFocusRef={inputRef}
            cancelReturnFocusRef={anchorRef}
            onRepoSelect={onRepoSelect}
          />
        )}

        {showCreateSpaceDialog && (
          <CreateSpaceDialog
            closeDialog={() => setShowCreateSpaceDialog(false)}
            onSubmit={() => {
              sendEvent('dotcom_chat.activate', {
                target: 'ATTACHMENT_MENU_COPILOT_SPACES_SPACE_CREATED',
                mode: 'immersive',
              })
            }}
          />
        )}

        {panel === 'no-agents-available' && (
          <NoAgentsAvailableDialog onClose={() => setPanel(null)} returnFocusRef={anchorRef} />
        )}
        {panel === 'agents-not-supported' && (
          <AgentsNotSupportedDialog onClose={() => setPanel(null)} returnFocusRef={anchorRef} />
        )}

        {supportedAttachmentTypes.includes('plugin-attachment-contribution') &&
          plugins.map(p => {
            if (!p.attachmentMenuContribution) return null
            if (p.attachmentMenuContribution.attachmentType !== panel) return null
            return (
              <p.attachmentMenuContribution.PanelComponent
                key={p.id}
                onSubmit={() => {
                  setPanel(null)
                  inputRef.current?.focus()
                }}
                onDismiss={() => {
                  setPanel(null)
                  anchorRef.current?.focus()
                }}
              />
            )
          })}
      </div>
    )
  },
)

AttachmentMenu.displayName = 'AttachmentMenu'
