import {sendEvent} from '@github-ui/hydro-analytics'
import {useQuery, useQueryClient} from '@github-ui/react-query'
import {verifiedFetchJSON} from '@github-ui/verified-fetch'
import {useCallback} from 'react'

import {FREE_QUOTA_TRIGGER, PREMIUM_QUOTA_TRIGGER} from './copilot-chat-helpers'
import {
  type CopilotChatEntitlementQuotas,
  type CopilotChatTrialInfo,
  CopilotLicenseType,
  CopilotPlan,
} from './copilot-chat-types'
import {copilotFeatureFlags} from './copilot-feature-flags'

export type CopilotChatEntitlementResult = {
  licenseType: CopilotLicenseType
  plan?: CopilotPlan
  quotas?: CopilotChatEntitlementQuotas
  trial?: CopilotChatTrialInfo
}

export function useCopilotChatEntitlement(
  initialLicenseType: CopilotLicenseType,
  initialPlan?: CopilotPlan,
  initialQuotas?: CopilotChatEntitlementQuotas,
): [entitlement: CopilotChatEntitlement, reloadQuota: (origin?: string) => void] {
  const client = useQueryClient()

  const invalidateEntitlement = useCallback(
    () => client.invalidateQueries({queryKey: ['copilot-chat', 'entitlement']}),
    [client],
  )

  const {data} = useQuery<CopilotChatEntitlementResult>({
    queryKey: ['copilot-chat', 'entitlement'],
    queryFn: async () => {
      const response = await verifiedFetchJSON('/github-copilot/chat/entitlement')

      if (!response.ok) {
        throw new Error(`Failed to retrieve Copilot chat entitlement (${response.status} on ${response.url})`)
      }

      return (await response.json()) as CopilotChatEntitlementResult
    },
    enabled:
      initialLicenseType === CopilotLicenseType.LicensedLimited ||
      (initialLicenseType === CopilotLicenseType.LicensedFull && copilotFeatureFlags.premiumRequestQuotasEnabled),
    placeholderData: {
      licenseType: initialLicenseType,
      plan: initialPlan,
      quotas: initialQuotas,
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  })

  const license = data?.licenseType ?? initialLicenseType
  const plan = data?.plan ?? initialPlan
  const quotas = data?.quotas ?? initialQuotas

  const remainingChatPercentage = quotas?.remaining.chatPercentage
  const remainingPremiumPercentage = quotas?.remaining.premiumInteractionsPercentage

  const reloadQuota = useCallback(
    (origin?: string) => {
      if (
        initialLicenseType === CopilotLicenseType.LicensedLimited ||
        (initialLicenseType === CopilotLicenseType.LicensedFull && copilotFeatureFlags.premiumRequestQuotasEnabled)
      ) {
        if (
          (copilotFeatureFlags.reduceChatQuotaChecks &&
            license === CopilotLicenseType.LicensedLimited &&
            remainingChatPercentage !== undefined &&
            remainingChatPercentage > FREE_QUOTA_TRIGGER) ||
          (license === CopilotLicenseType.LicensedFull &&
            remainingPremiumPercentage !== undefined &&
            remainingPremiumPercentage > PREMIUM_QUOTA_TRIGGER)
        ) {
          // skip invalidating entitlement if the remaining chat/premium quota is above the trigger threshold
          return
        }
        void invalidateEntitlement()
        sendEvent('dotcom_chat.activate', {target: 'ENTITLEMENTS_RELOAD', origin})
      }
    },
    [initialLicenseType, invalidateEntitlement, license, remainingChatPercentage, remainingPremiumPercentage],
  )

  return [new CopilotChatEntitlement(license, plan, data?.quotas, data?.trial), reloadQuota]
}

export class CopilotChatEntitlement {
  licenseType: CopilotLicenseType
  plan?: CopilotPlan
  quotas?: CopilotChatEntitlementQuotas
  trial?: CopilotChatTrialInfo

  constructor(
    licenseType: CopilotLicenseType,
    plan?: CopilotPlan,
    quotas?: CopilotChatEntitlementQuotas,
    trial?: CopilotChatTrialInfo,
  ) {
    this.licenseType = licenseType
    this.plan = plan
    this.quotas = quotas
    this.trial = trial
  }

  isLicensed(): boolean {
    return this.licenseType && this.licenseType !== CopilotLicenseType.Unlicensed
  }

  canPurchaseAdditionalQuota(): boolean {
    // whether the plan allows for purchasing additional quota
    // 1. not available for limited (free) users
    // 2. available for pro and pro plus users
    // 3. available for business and enterprise users - but only admins can do that

    // TODO implement checking whether user is an admin for business plan to upgrade to enterprise
    // this is unavailable while we don't really know which of potentially multiple copilot licensed orgs the user is an admin of
    return (
      this.licenseType !== CopilotLicenseType.LicensedLimited &&
      copilotFeatureFlags.premiumRequestQuotasEnabled &&
      (this.plan === CopilotPlan.IndividualPro || this.plan === CopilotPlan.IndividualProPlus)
    )
  }

  canUpgradePlan(): boolean {
    // whether there is a higher plan available for upgrade and the user can make that upgrade
    // 1. limited (free) users don't have an upgrade path, they can only purchase a full plan
    // 2. pro users can upgrade to pro plus
    // 3. business users can upgrade to enterprise - but only admins can do that

    // TODO implement checking whether user is an admin for business plan to upgrade to enterprise
    // this is unavailable while we don't really know which of potentially multiple copilot licensed orgs the user is an admin of
    return (
      this.licenseType === CopilotLicenseType.LicensedLimited ||
      (copilotFeatureFlags.premiumRequestQuotasEnabled && this.plan === CopilotPlan.IndividualPro)
    )
  }

  chatQuotaRemaining(): number {
    return copilotFeatureFlags.premiumRequestQuotasEnabled && this.quotas?.remaining.chatPercentage !== undefined
      ? (this.quotas?.remaining.chatPercentage ?? 0)
      : (this.quotas?.remaining.chat ?? 0)
  }

  premiumInteractionsQuotaRemaining(): number {
    return this.quotas?.remaining.premiumInteractionsPercentage ?? 0
  }

  eligibleForTrial(): boolean {
    return this.trial?.eligible ?? false
  }
}

export function isPaidUser(copilotPlan?: CopilotPlan | null): boolean {
  return Boolean(copilotPlan && copilotPlan !== CopilotPlan.IndividualFree)
}
