import {HybridMarkdownEditor} from '@github-ui/hybrid-markdown-editor'
import {MarkdownEditor, type MarkdownEditorHandle} from '@github-ui/markdown-editor'
import {FileDiffIcon} from '@primer/octicons-react'
import {useEffect} from 'react'
import {flushSync} from 'react-dom'

export type SuggestedChangesConfig = {
  showSuggestChangesButton: boolean
  sourceContentFromDiffLines: string | undefined
  onInsertSuggestedChange: () => void
  shouldInsertSuggestedChange?: boolean
}

type AddSuggestionButtonProps = {
  onChange: (text: string) => void
  inputValue: string
  sourceContentFromDiffLines: string | undefined
  onInsertSuggestedChange: () => void
  shouldInsertSuggestionOnRender: boolean | undefined
  editorRef: React.RefObject<MarkdownEditorHandle | null>
}

const markdownPrefix = '```suggestion'
const markdownSuffix = '```'

/**
 * Inserts the suggested change backticks + original line into the comment box's markdown editor
 * Moves cursor to end of suggested change line
 *
 * @param onChange - function that changes the body of the comment box's markdown editor
 * @param inputValue - the current value of the comment box markdown editor, used to determine where to insert the suggestion
 * @param sourceContentFromDiffLines - the lines from the diff to insert as a suggestion
 * @param onInsertSuggestedChange - function called when the suggestion block is inserted
 * @param shouldInsertSuggestionOnRender - boolean indicating whether to auto insert the suggested change lines (invoked by context menu)
 * @param editorRef - ref to the markdown editor's input
 */
export function AddSuggestionButton({
  onChange,
  inputValue,
  sourceContentFromDiffLines,
  onInsertSuggestedChange,
  shouldInsertSuggestionOnRender,
  editorRef,
}: AddSuggestionButtonProps) {
  const suggestionLines = sourceContentFromDiffLines ?? ''

  const suggestion = `${markdownPrefix}\n${suggestionLines}\n${markdownSuffix}`

  const insertSuggestion = () => {
    onInsertSuggestedChange()
    // Focus the editor so there is a valid activeElement
    editorRef.current?.focus()
    const updatedMarkdownBody = inputValue === '' ? suggestion : `${inputValue}\n${suggestion}`
    // Synchronously update the DOM so we can position the cursor correctly
    // eslint-disable-next-line @eslint-react/dom/no-flush-sync
    flushSync(() => {
      onChange(updatedMarkdownBody)
    })
    const activeElement = document.activeElement
    if (!activeElement || !(activeElement instanceof HTMLTextAreaElement)) return

    const endOfSuggestedChangeLine = updatedMarkdownBody.length - markdownSuffix.length
    activeElement.selectionStart = endOfSuggestedChangeLine - 1
    activeElement.selectionEnd = endOfSuggestedChangeLine - 1
  }

  useEffect(() => {
    if (shouldInsertSuggestionOnRender) {
      // Wait a tick to prevent calling flushSync during rendering
      const timeout = window.setTimeout(() => insertSuggestion())
      return () => {
        window.clearTimeout(timeout)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return <MarkdownEditor.ToolbarButton icon={FileDiffIcon} aria-label="Add a suggestion" onClick={insertSuggestion} />
}

interface HybridAddSuggestionButtonProps {
  /** The lines from the diff to insert as a suggestion */
  sourceContentFromDiffLines: string | undefined
}

/**
 * Create a config object for a custom toolbar button in the hybrid editor (this must be separate because the
 * hybrid editor uses the CodeMirror API and also doesn't support slots).
 *
 * NOTE: In the hybrid editor, we do not currently support auto-adding the suggestion on render.
 */
export function HybridAddSuggestionButton(props: HybridAddSuggestionButtonProps) {
  const {sourceContentFromDiffLines} = props

  return (
    <HybridMarkdownEditor.ToolbarButton
      telemetryId="add_suggestion"
      icon={FileDiffIcon}
      aria-label="Add a suggestion"
      onClick={view => {
        const suggestion = `${markdownPrefix}\n${sourceContentFromDiffLines ?? ''}\n${markdownSuffix}`
        const insertion = view.state.doc.length === 0 ? suggestion : `\n${suggestion}`

        view.dispatch({
          changes: [{from: view.state.doc.length, insert: insertion}],
          selection: {
            // place the cursor at the end of the suggested change, but before the closing backticks
            anchor: view.state.doc.length + insertion.length - markdownSuffix.length - 1,
          },
        })

        return true
      }}
    />
  )
}
