import React from 'react'

const AllShortcutsEnabledContext = React.createContext(true)

export function AllShortcutsEnabledProvider({
  allShortcutsEnabled,
  children,
}: React.PropsWithChildren<{allShortcutsEnabled: boolean}>) {
  return <AllShortcutsEnabledContext value={allShortcutsEnabled}> {children} </AllShortcutsEnabledContext>
}

export function useAllShortcutsEnabled() {
  return React.use(AllShortcutsEnabledContext)
}
