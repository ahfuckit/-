import {useCustomCopilotsEnabled} from '@github-ui/copilot-spaces/hooks'
import {AlertIcon, TelescopeIcon} from '@primer/octicons-react'
import {Button, Link} from '@primer/react'
import {Dialog} from '@primer/react/experimental'

import {AGENTS_MARKETPLACE_URL} from '../utils/agents-helpers'
import type {CopilotChatModel} from '../utils/copilot-chat-types'
// eslint-disable-next-line no-restricted-imports
import {useChatState} from '../utils/CopilotChatContext'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import {useDefaultModel} from '../utils/models'
import styles from './AgentsDialogs.module.css'

export function NoAgentsAvailableDialog({
  onClose,
  returnFocusRef,
}: {
  onClose: () => void
  returnFocusRef: React.RefObject<HTMLButtonElement | null>
}) {
  return (
    <Dialog
      width="large"
      title="Extensions"
      position={{
        narrow: 'fullscreen',
        regular: 'center',
      }}
      onClose={onClose}
      returnFocusRef={returnFocusRef}
      renderBody={() => (
        <div className={styles.AgentsDialogsMainContainer}>
          <div className={styles.dialogContentWrapper}>
            <TelescopeIcon size={24} />
            <h3 className={styles.dialogTitle}>Chat with your favorite tools and services</h3>
            <p className={styles.dialogDescription}>
              Browse the marketplace to find extensions for the tools and services you rely on
            </p>
            <Button as="a" href={AGENTS_MARKETPLACE_URL}>
              Browse marketplace
            </Button>
            <div className={styles.documentationLinkContainer}>
              <Link href="https://gh.io/copilot-extensions-docs">Documentation</Link>
            </div>
          </div>
        </div>
      )}
    />
  )
}

export function AgentsNotSupportedDialog({
  onClose,
  returnFocusRef,
}: {
  onClose: () => void
  returnFocusRef: React.RefObject<HTMLButtonElement | null>
}) {
  const manager = useChatManager()
  const state = useChatState()
  const customCopilotsEnabled = useCustomCopilotsEnabled()
  const defaultModel: CopilotChatModel = useDefaultModel(state.availableModels)

  return (
    <Dialog
      width="large"
      title="Extensions"
      position={{
        narrow: 'fullscreen',
        regular: 'center',
      }}
      onClose={onClose}
      returnFocusRef={returnFocusRef}
      renderBody={() => (
        <div className={styles.AgentsDialogsAlternateContainer}>
          <div className={styles.dialogContentWrapper}>
            <div className={styles.alertIconContainer}>
              <AlertIcon size={24} />
            </div>
            <h3 className={styles.dialogTitle}>
              {customCopilotsEnabled ? 'Copilots and extensions' : 'Extensions'} aren&apos;t supported by this model
            </h3>
            <p className={styles.dialogDescription}>
              Switch back to the {defaultModel.displayName} model or start a new chat
            </p>
            <Button
              onClick={() => {
                void manager.selectThread(null)
                void manager.selectModel(defaultModel)
              }}
            >
              New chat
            </Button>
          </div>
        </div>
      )}
    />
  )
}
