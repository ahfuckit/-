import {getBaseFetchHeaders} from '@github-ui/fetch-headers'
import {useMutation, useQueries, useQuery, useQueryClient} from '@github-ui/react-query'
import {verifiedFetch} from '@github-ui/verified-fetch'
import {useCallback, useEffect, useEffectEvent, useRef, useState} from 'react'

import {copilotLocalStorage} from './copilot-local-storage'
// eslint-disable-next-line no-restricted-imports
import {useChatState} from './CopilotChatContext'
import {useChatManager} from './CopilotChatManagerContext'

export interface IndexingState {
  code: TopicIndexStatus
  docs: TopicIndexStatus
  requestStatus: CanIndexStatus
  remainingRepoIndexTokens?: number
}

interface IndexingStateResponse {
  code_status: TopicIndexStatus
  docs_status: TopicIndexStatus
  can_index: CanIndexStatus
}

export const TopicIndexStatus = {
  Unindexed: 'not_indexed',
  Indexed: 'indexed',
  Indexing: 'indexing',
  PartiallyIndexed: 'partially_indexed',
  Unknown: 'unknown',
} as const

export type TopicIndexStatus = (typeof TopicIndexStatus)[keyof typeof TopicIndexStatus]

export const CanIndexStatus = {
  Requested: 'requested',
  NotFound: 'not_found',
  Unauthorized: 'unauthorized',
  ServiceUnavailable: 'service_unavailable',
  QuotaExhausted: 'quota_exhausted',
  Forbidden: 'forbidden',
  CanIndex: 'ok',
  IndexingError: 'indexing_error',
  RequestFailed: 'request_failed',
  Unknown: 'unknown',
} as const

export type CanIndexStatus = (typeof CanIndexStatus)[keyof typeof CanIndexStatus]

const errorStatuses = [
  CanIndexStatus.NotFound,
  CanIndexStatus.Unauthorized,
  CanIndexStatus.ServiceUnavailable,
  CanIndexStatus.QuotaExhausted,
  CanIndexStatus.Forbidden,
  CanIndexStatus.RequestFailed,
]

const UNKNOWN_INDEXING_STATE: IndexingState = {
  requestStatus: CanIndexStatus.Unknown,
  code: TopicIndexStatus.Unknown,
  docs: TopicIndexStatus.Unknown,
}

export const MIN_PANEL_HEIGHT = 256
export const MIN_PANEL_WIDTH = 400

export function useReposIndexingState(nwos: string[]): [IndexingState, () => void] {
  const client = useQueryClient()

  const invalidateIndexingStatus = useCallback(
    () =>
      Promise.all(nwos.map(nwo => client.invalidateQueries({queryKey: ['copilot-chat', 'repos-indexing-state', nwo]}))),
    [client, nwos],
  )

  const results = useQueries({
    queries: nwos.map(nwo => ({
      queryKey: ['copilot-chat', 'repos-indexing-state', nwo],
      queryFn: () => fetchIndexingStatus(nwo),
      placeholderData: UNKNOWN_INDEXING_STATE,
      staleTime: Infinity,
    })),
  })

  const {mutate: triggerIndexingForRepos} = useMutation({
    mutationKey: ['repos-indexing-state'],
    mutationFn: () => triggerIndexing(nwos),
    onSuccess: invalidateIndexingStatus,
  })

  const aggregatedIndexingStatus = aggregateResults(results.map(r => r.data ?? UNKNOWN_INDEXING_STATE))

  // If any repo is "indexing" and we have not encountered an error, we consider indexing to be in progress
  const isIndexingInProgress =
    aggregatedIndexingStatus.code === TopicIndexStatus.Indexing &&
    aggregatedIndexingStatus.requestStatus !== CanIndexStatus.IndexingError

  useInterval(() => void invalidateIndexingStatus(), isIndexingInProgress ? 10000 : 0)

  return [aggregatedIndexingStatus, () => triggerIndexingForRepos()]
}

export function useRepoIndexingState(nwo: string): [IndexingState, () => void] {
  const client = useQueryClient()

  const invalidateIndexingStatus = useCallback(
    () => Promise.resolve(client.invalidateQueries({queryKey: ['repo-indexing-state', nwo]})),
    [client, nwo],
  )

  const result = useQuery({
    queryKey: ['copilot-chat', 'repo-indexing-state', nwo],
    queryFn: () => fetchIndexingStatus(nwo),
    placeholderData: UNKNOWN_INDEXING_STATE,
    staleTime: Infinity,
  })

  const {mutate: triggerIndexingForRepos} = useMutation({
    mutationKey: ['repo-indexing-state'],
    mutationFn: () => triggerIndexing([nwo]),
    onSuccess: invalidateIndexingStatus,
  })

  const indexingStatus = result.data ?? UNKNOWN_INDEXING_STATE

  // If repo is "indexing" and we have not encountered an error, we consider indexing to be in progress
  const isIndexingInProgress =
    indexingStatus.code === TopicIndexStatus.Indexing && indexingStatus.requestStatus !== CanIndexStatus.IndexingError

  useInterval(() => void invalidateIndexingStatus(), isIndexingInProgress ? 10000 : 0)

  return [indexingStatus, () => triggerIndexingForRepos()]
}

export function useShowTopicPicker() {
  const state = useChatState()
  const manager = useChatManager()
  const showTopicPicker =
    (!state.selectedThreadID || state.mode === 'assistive') && state.messages.length === 0 && !state.currentTopic

  useEffect(() => {
    // When the thread updates, see if we need to show a blank thread.
    manager.showTopicPicker(showTopicPicker)
  }, [manager, showTopicPicker])
}

export function useResizablePanel() {
  const initialPanelHeight = copilotLocalStorage.getPanelHeight()
  const initialPanelWidth = copilotLocalStorage.getPanelWidth()
  const resizeStartYRef = useRef<number | null>(null)
  const resizeStartHeightRef = useRef(initialPanelHeight)
  const newHeightRef = useRef(initialPanelHeight)
  const resizeStartXRef = useRef<number | null>(null)
  const resizeStartWidthRef = useRef(initialPanelWidth)
  const newWidthRef = useRef(initialPanelWidth)
  const [panelHeight, setPanelHeight] = useState(initialPanelHeight)
  const [panelWidth, setPanelWidth] = useState(initialPanelWidth)
  const remSizeRef = useRef(0)

  useEffect(() => {
    remSizeRef.current = parseFloat(getComputedStyle(document.documentElement).fontSize)
  }, [])

  const getPanelHeight = (height: number) => {
    return Math.min(Math.max(height, MIN_PANEL_HEIGHT), window.innerHeight - remSizeRef.current)
  }

  const getPanelWidth = (width: number) => {
    return Math.min(Math.max(width, MIN_PANEL_WIDTH), window.innerWidth - 2 * remSizeRef.current)
  }

  const resize = useCallback((e: MouseEvent) => {
    if (resizeStartYRef.current !== null) {
      const dy = resizeStartYRef.current - e.clientY
      const height = getPanelHeight(resizeStartHeightRef.current + dy)
      setPanelHeight(height)
      newHeightRef.current = height
    }
    if (resizeStartXRef.current !== null) {
      const dx = resizeStartXRef.current - e.clientX
      const width = getPanelWidth(resizeStartWidthRef.current + dx)
      setPanelWidth(width)
      newWidthRef.current = width
    }
  }, [])

  const stopResize = useCallback(() => {
    window.removeEventListener('mousemove', resize)
    // eslint-disable-next-line react-hooks/immutability
    window.removeEventListener('mouseup', stopResize)
    if (resizeStartYRef.current !== null) {
      // use newHeight ref since panelHeight might not be updated yet.
      copilotLocalStorage.setPanelHeight(newHeightRef.current)
      resizeStartYRef.current = null
    }
    if (resizeStartXRef.current !== null) {
      copilotLocalStorage.setPanelWidth(newWidthRef.current)
      resizeStartXRef.current = null
    }
  }, [resize])

  const startResize = useCallback(
    (e: React.MouseEvent, horizontal: boolean, vertical: boolean) => {
      if (e.button === 0) {
        e.preventDefault()
        if (vertical) {
          resizeStartYRef.current = e.clientY
          resizeStartHeightRef.current = panelHeight
        }
        if (horizontal) {
          resizeStartXRef.current = e.clientX
          resizeStartWidthRef.current = panelWidth
        }
        window.addEventListener('mousemove', resize)
        window.addEventListener('mouseup', stopResize)
      }
    },
    [panelHeight, panelWidth, resize, stopResize],
  )

  const onResizerKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      // eslint-disable-next-line @github-ui/ui-commands/no-manual-shortcut-logic
      if (e.key === 'ArrowUp') {
        const newPanelHeight = getPanelHeight(panelHeight + 4)
        setPanelHeight(newPanelHeight)
        copilotLocalStorage.setPanelHeight(newPanelHeight)
        e.preventDefault()
        // eslint-disable-next-line @github-ui/ui-commands/no-manual-shortcut-logic
      } else if (e.key === 'ArrowDown') {
        const newPanelHeight = getPanelHeight(panelHeight - 4)
        setPanelHeight(newPanelHeight)
        copilotLocalStorage.setPanelHeight(newPanelHeight)
        e.preventDefault()
        // eslint-disable-next-line @github-ui/ui-commands/no-manual-shortcut-logic
      } else if (e.key === 'ArrowRight') {
        const newPanelWidth = getPanelWidth(panelWidth - 4)
        setPanelWidth(newPanelWidth)
        copilotLocalStorage.setPanelWidth(newPanelWidth)
        e.preventDefault()
        // eslint-disable-next-line @github-ui/ui-commands/no-manual-shortcut-logic
      } else if (e.key === 'ArrowLeft') {
        const newPanelWidth = getPanelWidth(panelWidth + 4)
        setPanelWidth(newPanelWidth)
        copilotLocalStorage.setPanelWidth(newPanelWidth)
        e.preventDefault()
      }
    },
    [panelHeight, panelWidth],
  )

  return {panelWidth, panelHeight, startResize, onResizerKeyDown}
}

async function fetchIndexingStatus(nwo: string): Promise<IndexingState> {
  const res = await fetch(`/search/check_indexing_status?nwo=${encodeURIComponent(nwo)}`, {
    headers: {Accept: 'application/json', ...getBaseFetchHeaders()},
  })

  if (!res.ok) {
    return {
      requestStatus: CanIndexStatus.RequestFailed,
      code: TopicIndexStatus.Unknown,
      docs: TopicIndexStatus.Unknown,
    }
  }

  const data = (await res.json()) as IndexingStateResponse

  return {
    requestStatus: data.can_index,
    code: data.code_status,
    docs: data.docs_status,
  }
}

async function triggerIndexing(nwos: string[]) {
  const nwosParam =
    nwos.length === 1 ? `nwo=${encodeURIComponent(nwos[0]!)}` : `nwos=${encodeURIComponent(JSON.stringify(nwos))}`

  return verifiedFetch(`/search/index_embeddings?${nwosParam}&index_code=${true}`, {method: 'POST'})
}

function aggregateResults(repoStates: IndexingState[]): IndexingState {
  return {
    requestStatus: aggregateCanIndexStatuses(repoStates.map(s => s.requestStatus)),
    code: aggregateTopicIndexStatuses(repoStates.map(s => s.code)),
    docs: aggregateTopicIndexStatuses(repoStates.map(s => s.docs)),
    remainingRepoIndexTokens: repoStates[0]?.remainingRepoIndexTokens,
  }
}

function aggregateTopicIndexStatuses(statuses: TopicIndexStatus[]): TopicIndexStatus {
  // if every repo is "indexed", return "indexed"
  if (statuses.every(s => s === TopicIndexStatus.Indexed)) return TopicIndexStatus.Indexed
  // If every repo is "unindexed", return "unindexed"
  if (statuses.every(s => s === TopicIndexStatus.Unindexed)) return TopicIndexStatus.Unindexed
  // If any repo is "indexing", return "indexing"
  if (statuses.some(s => s === TopicIndexStatus.Indexing)) return TopicIndexStatus.Indexing
  // If any repo is "unindexed", we don't have any "indexing" repos, and not all repos are indexed/unindexed, return "partially indexed"
  if (statuses.some(s => s === TopicIndexStatus.Unindexed)) return TopicIndexStatus.PartiallyIndexed
  // Fallback to "unknown"
  return TopicIndexStatus.Unknown
}

function aggregateCanIndexStatuses(statuses: CanIndexStatus[]): CanIndexStatus {
  // If we don't have any statuses, return unknown
  if (statuses.length === 0) return CanIndexStatus.Unknown
  // If any status is error, return "indexing error"
  if (
    statuses.some(s =>
      errorStatuses.includes(
        // @ts-expect-error some options for status might not be in errorStatuses
        s,
      ),
    )
  )
    return CanIndexStatus.IndexingError
  // If all statuses are "can index", return "can index"
  if (statuses.every(s => s === CanIndexStatus.CanIndex)) return CanIndexStatus.CanIndex
  // If all statuses are "unknown", return "unknown"
  if (statuses.every(s => s === CanIndexStatus.Unknown)) return CanIndexStatus.Unknown
  // Fallback to "unknown"
  return CanIndexStatus.Unknown
}

function useInterval(callback: () => void, delay: number) {
  const intervalRef = useRef<number | undefined>(undefined)
  const savedCallback = useEffectEvent(callback)
  useEffect(() => {
    const tick = () => savedCallback()
    if (delay > 0) {
      intervalRef.current = window.setInterval(tick, delay)
      return () => window.clearInterval(intervalRef.current)
    }
  }, [delay])
  return intervalRef
}
