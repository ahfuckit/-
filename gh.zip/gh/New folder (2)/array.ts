/**
 * Split an array into groups based on unique values returned by the differentiator.
 * @example
 * // Split numbers into even and odd
 * const groups = partition([1,2,3,4,5], n => n % 2)
 * const evens = groups.get(0) ?? []
 * const odds = groups.get(1) ?? []
 */
export function group<T, K extends string | number | symbol>(array: T[], differentiator: (el: T) => K) {
  const result: Partial<Record<K, T[]>> = {}
  for (const el of array) {
    const key = differentiator(el)
    result[key] ??= []
    result[key].push(el)
  }
  return result
}

/**
 * Creates a new array of unique values from the provided array based on a key function.
 * Duplicate items are determined by the return value of the key function.
 * When duplicates are found, the first item with the same key is kept.
 *
 * @param array - The array to filter for unique values.
 * @param fn - A function that returns a key for each item in the array.
 * @returns An array of unique items based on the provided key function.
 */
export function uniqueBy<T, K extends string | number | symbol>(array: T[], fn: (item: T) => K): T[] {
  const result = []
  const seenKeys = new Set<K>()

  for (const item of array) {
    const key = fn(item)

    // If the key has been seen before, skip adding this duplicate item
    if (seenKeys.has(key)) {
      continue
    }
    seenKeys.add(key)
    result.push(item)
  }

  return result
}
