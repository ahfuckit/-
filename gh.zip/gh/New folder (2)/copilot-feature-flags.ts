import {isFeatureEnabled} from '@github-ui/feature-flags'

/**
 * IMPORTANT NOTICE: Feature flags added here must also be added to the `packages/feature-flags/client-feature-flags.ts` file
 * or they will not be available to check in this file!
 */

class CopilotFeatureFlags {
  get immersiveFigmaIntegration() {
    return isFeatureEnabled('copilot_immersive_figma_integration')
  }

  get focusTextAreaInsteadOfWorkbench() {
    return isFeatureEnabled('copilot_focus_text_area_instead_of_workbench')
  }

  get forceLegacyChatDefaultModel() {
    return isFeatureEnabled('copilot_api_force_legacy_base_chat_model')
  }

  get domPageContext() {
    return isFeatureEnabled('copilot_use_dom_page_context')
  }

  /**
   * When enabled, the interview survey dialog replaces the 'Give feedback' dialog in copilot chat.
   * @returns {boolean} Whether the feature is enabled.
   */
  get copilotChatInterviewSurvey() {
    return isFeatureEnabled('copilot_chat_interview_survey')
  }

  get attachMultipleImages() {
    return isFeatureEnabled('copilot_chat_attach_multiple_images')
  }

  get clearModelSelectionForDefaultChange() {
    return isFeatureEnabled('copilot_chat_clear_model_selection_for_default_change')
  }

  /**
   * When enabled, uses REST endpoints instead of Relay/GraphQL for repository fetching.
   * This removes the react-relay dependency from the copilot-chat bundle.
   */
  get deprecateRelay() {
    return isFeatureEnabled('copilot_chat_deprecate_relay')
  }

  get enableToolCallLogs() {
    return isFeatureEnabled('copilot_chat_enable_tool_call_logs')
  }

  /** Feature flag for text selection attachments in file previews */
  get selectionAttachments() {
    return isFeatureEnabled('copilot_chat_selection_attachments')
  }

  get customCopilots() {
    return isFeatureEnabled('copilot_custom_copilots')
  }

  get immersiveLayoutRoutes() {
    return isFeatureEnabled('copilot_immersive_layout_routes')
  }

  get immersiveStructuredModelPicker() {
    return isFeatureEnabled('copilot_immersive_structured_model_picker')
  }

  get customCopilotsFeaturePreview() {
    return isFeatureEnabled('copilot_custom_copilots_feature_preview')
  }

  get workbenchPlugin() {
    return isFeatureEnabled('copilot_workbench')
  }

  get copilotChatOpeningThreadSwitch() {
    return isFeatureEnabled('copilot_chat_opening_thread_switch')
  }

  get copilotDuplicateThread() {
    return isFeatureEnabled('copilot_duplicate_thread')
  }

  get copilotShareActiveSubthread() {
    return isFeatureEnabled('copilot_share_active_subthread')
  }

  get copilotChatO1Tools() {
    return isFeatureEnabled('copilot_api_tools_for_non_streaming_models')
  }

  get showDeepCodeSearchButton() {
    return (
      isFeatureEnabled('copilot_show_deep_code_search_button') && isFeatureEnabled('copilot_api_search_agent_skill')
    )
  }

  get deleteAllConversations() {
    return isFeatureEnabled('copilot_delete_all_conversations')
  }

  get staffPromptDialog() {
    return isFeatureEnabled('copilot_staff_prompt_dialog')
  }

  get staffToolsMenu() {
    return isFeatureEnabled('copilot_staff_tools_menu')
  }

  get visionAllowedInClaude() {
    return isFeatureEnabled('copilot_chat_vision_in_claude')
  }

  get premiumRequestQuotasEnabled() {
    return isFeatureEnabled('copilot_premium_request_quotas')
  }

  get freeToPaidTelemetry() {
    return isFeatureEnabled('copilot_free_to_paid_telem')
  }

  get freeToPaidSettingsUpgrade() {
    return isFeatureEnabled('copilot_ftp_settings_upgrade')
  }

  get freeToPaidYourCopilotSettings() {
    return isFeatureEnabled('copilot_ftp_your_copilot_settings')
  }

  get freeToPaidUpgradeToProFromModels() {
    return isFeatureEnabled('copilot_ftp_upgrade_to_pro_from_models')
  }

  get spacesImagesEnabled() {
    return isFeatureEnabled('copilot_custom_copilots_images')
  }

  get immersiveJobResultPreview() {
    return isFeatureEnabled('copilot_immersive_job_result_preview')
  }

  get disableModelPickerWhileStreaming() {
    return isFeatureEnabled('copilot_chat_disable_model_picker_while_streaming')
  }

  get freeToPaidHyperspaceUpgradePrompt() {
    return isFeatureEnabled('copilot_ftp_hyperspace_upgrade_prompt')
  }

  get reduceChatQuotaChecks() {
    return isFeatureEnabled('copilot_chat_reduce_quota_checks')
  }

  get requestTracing() {
    return isFeatureEnabled('copilot_api_staff_only_tracing')
  }

  get coffeTraceViewer() {
    return isFeatureEnabled('copilot_coffe_trace_view_enabled')
  }

  get capiErrorResponseTelemetry() {
    return isFeatureEnabled('copilot_capi_error_response_telemetry')
  }

  get fileBlockRefMatching() {
    return isFeatureEnabled('copilot_file_block_ref_matching')
  }

  get stableConversationView() {
    return isFeatureEnabled('copilot_stable_conversation_view')
  }

  get copilotRedirectDiffViewToImmersive() {
    return isFeatureEnabled('copilot_chat_diff_view_redirect') && !isFeatureEnabled('copilot_immersive_embedded')
  }

  get copilotRedirectFileViewToImmersive() {
    return isFeatureEnabled('copilot_chat_file_redirect') && !isFeatureEnabled('copilot_immersive_embedded')
  }

  get copilotRedirectSnippetToImmersive() {
    return isFeatureEnabled('copilot_chat_snippet_redirect') && !isFeatureEnabled('copilot_immersive_embedded')
  }

  get immersiveEmbedded() {
    return isFeatureEnabled('copilot_immersive_embedded')
  }

  get immersiveEmbeddedImplicitReferences() {
    return isFeatureEnabled('copilot_immersive_embedded_implicit_references')
  }

  get copilotResourcePanel() {
    return isFeatureEnabled('copilot_resource_panel')
  }

  get spacesIndividualPoliciesEnabled() {
    return isFeatureEnabled('copilot_spaces_individual_policies_ga')
  }

  get copilotWorkbenchSlimLineTopTabs() {
    return isFeatureEnabled('copilot_workbench_slim_line_top_tabs')
  }

  get sweAgentUseSubagents() {
    return isFeatureEnabled('copilot_swe_agent_use_subagents')
  }

  get chatInputCommands() {
    return isFeatureEnabled('copilot_chat_input_commands')
  }

  get agentTaskListV2() {
    return isFeatureEnabled('copilot_agent_task_list_v2')
  }

  get removeAssistiveChatButton() {
    return isFeatureEnabled('copilot_chat_remove_assistive_button')
  }

  get hideExtensionsInDotcomChat() {
    return isFeatureEnabled('copilot_extensions_hide_in_dotcom_chat')
  }

  get copilotSearchBarRedirect() {
    return isFeatureEnabled('copilot_chat_search_bar_redirect')
  }

  get askModeDropdown() {
    return isFeatureEnabled('copilot_ask_mode_dropdown')
  }

  get taskWithinChatThread() {
    return isFeatureEnabled('copilot_immersive_task_within_chat_thread')
  }

  get previewFeaturesVisionGate() {
    return isFeatureEnabled('copilot_chat_vision_preview_gate')
  }

  get codingAgentModelSelection() {
    return isFeatureEnabled('coding_agent_model_selection')
  }

  get codingAgentModelSelectionAllSkus() {
    return isFeatureEnabled('coding_agent_model_selection_all_skus')
  }

  get codingAgentProposeTasks() {
    return isFeatureEnabled('coding_agent_propose_tasks')
  }

  get codingAgentPullRequestToggle() {
    return isFeatureEnabled('coding_agent_pull_request_toggle')
  }

  get codingAgentHideModelPickerIfOnlyAuto() {
    return isFeatureEnabled('copilot_swe_agent_hide_model_picker_if_only_auto')
  }

  get defaultToTaskInput() {
    return isFeatureEnabled('copilot_default_to_task_input')
  }

  get defaultToTaskControl() {
    return isFeatureEnabled('copilot_default_to_task_input_control_group')
  }

  get copilotIcebreakersExperimentDashboard() {
    return isFeatureEnabled('copilot_icebreakers_experiment_dashboard')
  }

  get copilotIcebreakersExperimentHyperspace() {
    return isFeatureEnabled('copilot_icebreakers_experiment_hyperspace')
  }

  get copilotChatRepositoryPicker() {
    return this.askModeDropdown && isFeatureEnabled('copilot_chat_repository_picker')
  }

  get copilotSpacesPagination() {
    return isFeatureEnabled('copilot_spaces_pagination')
  }

  get customInstructionsFileReferences() {
    return isFeatureEnabled('custom_instructions_file_references')
  }

  get chatInputPerformanceOptimizations() {
    return isFeatureEnabled('copilot_chat_input_performance_optimizations')
  }

  get scrollPreviewTabs() {
    return isFeatureEnabled('copilot_scroll_preview_tabs')
  }

  get filePreviewKeepMounted() {
    return isFeatureEnabled('copilot_immersive_file_preview_keep_mounted')
  }
}

export const copilotFeatureFlags = new CopilotFeatureFlags()
export type {CopilotFeatureFlags}
