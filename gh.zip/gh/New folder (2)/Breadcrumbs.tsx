import {Breadcrumbs} from '@github-ui/pacer/Breadcrumbs'
import type {Pull} from '../../types/pull'

export function TaskBreadcrumbs({pull}: {pull: Pull | undefined}) {
  return (
    <Breadcrumbs>
      <Breadcrumbs.Item href="/copilot/agents">Agents</Breadcrumbs.Item>
      <Breadcrumbs.Item loading={!pull}>{pull?.title}</Breadcrumbs.Item>
    </Breadcrumbs>
  )
}
