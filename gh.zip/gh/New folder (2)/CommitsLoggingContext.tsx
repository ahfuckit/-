import type React from 'react'
import {createContext, use} from 'react'

import type {LoggingInformation} from '../types/commits-types'

export const baseLoggingInfo: LoggingInformation = {
  loggingPayload: undefined,
  loggingPrefix: undefined,
}

const CommitsLoggingContext = createContext<LoggingInformation>(baseLoggingInfo)

export function CommitsLoggingInfoProvider({
  children,
  loggingInfo,
}: React.PropsWithChildren<{loggingInfo: LoggingInformation}>) {
  return <CommitsLoggingContext value={loggingInfo}>{children}</CommitsLoggingContext>
}

export function useIsLoggingInformationProvided() {
  const loggingInfo = use(CommitsLoggingContext)
  const loggingInfoIsPresent = loggingInfo.loggingPayload !== undefined && loggingInfo.loggingPrefix !== undefined
  return loggingInfoIsPresent
}

export function useLoggingInfo() {
  const loggingInfo = use(CommitsLoggingContext)

  return loggingInfo
}
