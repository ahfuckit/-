import {sendEvent} from '@github-ui/hydro-analytics'
import {useAppPayload} from '@github-ui/react-core/use-app-payload'
import {LockIcon, PencilIcon, TrashIcon, UnlockIcon} from '@primer/octicons-react'
import {ActionList, ConfirmationDialog, FormControl, TextInput} from '@primer/react'
import {Dialog} from '@primer/react/experimental'
import {type FormEvent, useCallback, useId, useRef, useState} from 'react'

import {useNavigateToNewThread} from '../../hooks/use-navigate-to-new-thread'
import {findAgentCorrespondents} from '../../utils/copilot-chat-helpers'
import type {ShareablePayload} from '../../utils/copilot-chat-types'
// eslint-disable-next-line no-restricted-imports
import {useChatState} from '../../utils/CopilotChatContext'
import {useChatManager} from '../../utils/CopilotChatManagerContext'
import styles from './ConversationActions.module.css'
import {ConversationSharingDialog} from './ConversationSharingDialog'
import {ExportActionList} from './export/ExportActionList'

interface ConversationActionsProps {
  onOpenDialog: (dialog: ConversationActionDialogName) => void
  showShare?: boolean
  hideShareOnDesktop?: boolean
  isShared?: boolean
  threadName: string
  threadId: string
}

export function ConversationActions({
  onOpenDialog,
  showShare = true,
  hideShareOnDesktop = false,
  isShared = false,
  threadName,
  threadId,
}: ConversationActionsProps) {
  const {canShareThread} = useAppPayload<ShareablePayload>()
  // TODO: We should use another method to get messages, as the user can click "Manage conversation" for a different thread
  // than the one currently selected. It's only a UI issue rather than a security one though, since we check if the thread is shareable
  // on CAPI side.
  const {isWaitingOnCopilot, messages, currentUserLogin, selectedThreadID} = useChatState()
  const agents = findAgentCorrespondents(messages)
  const shareDisabled = agents.length > 0 || isWaitingOnCopilot

  return (
    <>
      <ActionList.Item
        onSelect={() => {
          sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_CONTEXT_MENU_RENAME', mode: 'immersive'})
          onOpenDialog('rename')
        }}
      >
        <ActionList.LeadingVisual>
          <PencilIcon />
        </ActionList.LeadingVisual>
        Rename
      </ActionList.Item>
      {showShare && canShareThread && (
        <ActionList.Item
          className={hideShareOnDesktop ? styles.hideOnDesktop : undefined}
          disabled={shareDisabled}
          onSelect={() => {
            sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_CONTEXT_MENU_SHARE', mode: 'immersive'})
            onOpenDialog('share')
          }}
        >
          <ActionList.LeadingVisual>{isShared ? <UnlockIcon /> : <LockIcon />}</ActionList.LeadingVisual>
          Share
        </ActionList.Item>
      )}
      <ExportActionList
        threadName={threadName}
        threadId={threadId}
        currentUserLogin={currentUserLogin}
        messages={messages}
        selectedThreadID={selectedThreadID}
      />
      <ActionList.Item
        variant="danger"
        onSelect={() => {
          sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_CONTEXT_MENU_DELETE', mode: 'immersive'})
          onOpenDialog('delete')
        }}
      >
        <ActionList.LeadingVisual>
          <TrashIcon />
        </ActionList.LeadingVisual>
        Delete
      </ActionList.Item>
    </>
  )
}

export type ConversationActionDialogName = 'delete' | 'rename' | 'share'

interface ConversationActionDialogsProps {
  visibleDialog: ConversationActionDialogName | null
  onClose: () => void
  threadName: string
  threadId: string
  selectedThreadId?: string
  onStartLoading: () => void
  onFinishLoading: () => void
  returnFocusRef: React.RefObject<HTMLElement | null>
}

export function ConversationActionDialogs({
  visibleDialog,
  onClose,
  threadName,
  threadId,
  selectedThreadId,
  onStartLoading,
  onFinishLoading,
  returnFocusRef,
}: ConversationActionDialogsProps) {
  const {threads} = useChatState()
  const manager = useChatManager()
  const navigateToNewThread = useNavigateToNewThread()

  const closeConversationSharingDialog = () => {
    sendEvent('dotcom_chat.activate', {target: 'COPILOT_SHARE_DIALOG_CLOSE', mode: 'immersive'})
    onClose()
  }

  const confirmDelete = useCallback(async () => {
    sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_LIST_ACTION_DELETE', mode: 'immersive'})
    onStartLoading()
    const threadToDelete = threads.get(threadId)
    if (threadToDelete) {
      // navigate away before deleting
      if (threadId === selectedThreadId) {
        await navigateToNewThread({clearTopic: true, includeThreads: false})
      }
      await manager.deleteThread(threadToDelete)
    }
    onFinishLoading()
    onClose()
  }, [threads, threadId, selectedThreadId, navigateToNewThread, manager, onFinishLoading, onStartLoading, onClose])

  const submitRename = useCallback(
    async (name: string) => {
      sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_LIST_ACTION_RENAME', mode: 'immersive'})
      onStartLoading()
      const threadToRename = threads.get(threadId)
      if (threadToRename) {
        await manager.renameThread(threadToRename, name)
      }
      onFinishLoading()
      onClose()
    },
    [threads, threadId, manager, onStartLoading, onFinishLoading, onClose],
  )

  return (
    <>
      {visibleDialog === 'delete' ? (
        <DeleteDialog onCancel={onClose} onConfirm={confirmDelete} returnFocusRef={returnFocusRef} />
      ) : visibleDialog === 'rename' ? (
        <RenameDialog
          onCancel={onClose}
          currentName={threadName}
          onSubmit={submitRename}
          returnFocusRef={returnFocusRef}
        />
      ) : visibleDialog === 'share' ? (
        <ConversationSharingDialog
          closeDialog={closeConversationSharingDialog}
          threadId={threadId}
          returnFocusRef={returnFocusRef}
        />
      ) : null}
    </>
  )
}

interface DeleteDialogProps {
  onCancel: () => void
  onConfirm: () => void
  returnFocusRef: React.RefObject<HTMLElement | null>
}

const DeleteDialog = ({onConfirm, onCancel, returnFocusRef}: DeleteDialogProps) => (
  <ConfirmationDialog
    title="Delete chat"
    onClose={gesture => {
      if (gesture === 'confirm') {
        sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_DIALOG_DELETE_CONFIRM', mode: 'immersive'})
        // After a chat is deleted, the button or menu item that triggered this confirmation dialog is no longer in the DOM. To prevent focus loss (for accessibility), focus its closest landmark parent instead. In most cases, this will focus the conversation list.
        const closestLandmarkParent = returnFocusRef.current?.closest('nav,aside,section')
        onConfirm()
        window.setTimeout(() => {
          if (closestLandmarkParent instanceof HTMLElement) {
            closestLandmarkParent.focus()
          }
        }, 0)
      } else {
        sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_DIALOG_DELETE_CANCEL', mode: 'immersive'})
        onCancel()
        window.setTimeout(() => returnFocusRef.current?.focus(), 0)
      }
    }}
    confirmButtonContent="Delete"
    confirmButtonType="danger"
  >
    Are you sure you want to delete this chat? This action cannot be undone.
  </ConfirmationDialog>
)

interface RenameDialogProps {
  onCancel: () => void
  currentName: string
  onSubmit: (newName: string) => void
  returnFocusRef: React.RefObject<HTMLElement | null>
}

const RenameDialog = ({currentName, onCancel, onSubmit, returnFocusRef}: RenameDialogProps) => {
  const [invalid, setInvalid] = useState<'required' | 'max_length' | undefined>(undefined)
  const inputRef = useRef<HTMLInputElement>(null)
  const formId = useId()
  const dialogId = useId()

  const submit = (event: FormEvent) => {
    event.preventDefault()
    const value = inputRef.current?.value?.trim() ?? ''

    if (!value) {
      setInvalid('required')
      inputRef.current?.focus() // Focusing the input ensures the validation message is announced
    } else if (value.length > 100) {
      setInvalid('max_length')
      inputRef.current?.focus() // Focusing the input ensures the validation message is announced
    } else {
      setInvalid(undefined)
      onSubmit(value)
    }
  }

  const handleClose = () => {
    sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_DIALOG_RENAME_CANCEL', mode: 'immersive'})
    onCancel()
  }

  return (
    <Dialog
      title={<span id={dialogId}>Rename chat</span>}
      onClose={handleClose}
      width="small"
      footerButtons={[
        {
          content: 'Cancel',
          onClick: handleClose,
        },
        {
          content: 'Update',
          buttonType: 'primary',
          type: 'submit',
          form: formId,
          onClick: () =>
            sendEvent('dotcom_chat.activate', {target: 'CONVERSATION_DIALOG_RENAME_CONFIRM', mode: 'immersive'}),
        },
      ]}
      initialFocusRef={inputRef}
      returnFocusRef={returnFocusRef}
    >
      <form id={formId} onSubmit={submit}>
        <FormControl required>
          <FormControl.Label visuallyHidden>Rename chat</FormControl.Label>
          <TextInput
            aria-labelledby={dialogId}
            aria-describedby={invalid ? 'error-message' : undefined}
            aria-invalid={invalid ? 'true' : undefined}
            ref={inputRef}
            defaultValue={currentName}
            block
          />
          {invalid && (
            <FormControl.Validation id="error-message" variant="error">
              {invalid === 'required' ? 'Enter a name' : 'Name cannot exceed 100 characters'}
            </FormControl.Validation>
          )}
        </FormControl>
      </form>
    </Dialog>
  )
}
