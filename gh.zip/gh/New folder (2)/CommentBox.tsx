import type {ValidationResult} from '@github-ui/entity-validators'
import {isFeatureEnabled} from '@github-ui/feature-flags'
import {
  MarkdownEditor,
  type MarkdownEditorHandle,
  type MarkdownEditorProps,
  type ViewMode,
} from '@github-ui/markdown-editor'
import type {DefaultViewMode} from '@github-ui/markdown-editor-view-switch/types'
import {noop} from '@github-ui/noop'
import safeStorage from '@github-ui/safe-storage'
import type {TestIdProps} from '@github-ui/test-id-props'
import {useClientValue} from '@github-ui/use-client-value'
import {useViewerSettings} from '@github-ui/use-viewer-settings'
import {Flash, useRefObjectAsForwardedRef} from '@primer/react'
import React, {
  Children,
  cloneElement,
  Fragment,
  isValidElement,
  type ReactElement,
  type ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'

import {AddSuggestionButton, HybridAddSuggestionButton, type SuggestedChangesConfig} from './AddSuggestionButton'
import {acceptedFileTypes, useUploadFile} from './api/file-upload'
import {useGetPreview} from './api/preview'
import {ApiMarkdownSubject} from './api/types'
import styles from './CommentBox.module.css'
import {SaveButton} from './components/SaveButton'
import {SlashCommandsButton, SlashCommandsProvider} from './components/SlashCommandsProvider'
import {REGEX_STRINGS} from './constants/regex'
import strings from './constants/strings'
import type {Subject} from './subject'
import {useMarkdownSuggestions} from './util/use-markdown-suggestions'

type MarkdownSuggestionsFetchMethod = 'eager' | 'lazy'

export type CommentBoxHandle = MarkdownEditorHandle

export const CommentBoxButton = MarkdownEditor.ActionButton

export interface CommentBoxProps
  extends
    TestIdProps,
    Omit<
      MarkdownEditorProps,
      | 'emojiSuggestions'
      | 'mentionSuggestions'
      | 'referenceSuggestions'
      | 'onUploadFile'
      | 'acceptedFileTypes'
      | 'savedReplies'
      | 'onRenderPreview'
      | 'children'
      | 'errorMessage'
    > {
  label?: string
  showLabel?: boolean
  subject?: Subject
  onSave?: () => void
  onCancel?: () => void
  validationResult?: ValidationResult
  saveButtonText?: string
  saveButtonTrailingIcon?: boolean
  actions?: ReactNode
  footerButtons?: ReactNode[]
  /** Custom toolbar buttons to add to the markdown toolbar. */
  toolbarButtons?: ReactNode
  /** Block saving due to stale content. */
  contentIsStale?: boolean
  fileUploadsEnabled?: boolean
  buttonSize?: 'small' | 'medium'
  suggestedChangesConfig?: SuggestedChangesConfig
  /**
   * The method to fetch markdown suggestions. If set to `lazy`, suggestions will be fetched only when the editor is focused.
   * If set to `eager`, suggestions will be fetched immediately.
   * @default 'lazy'
   */
  markdownSuggestionsFetchMethod?: MarkdownSuggestionsFetchMethod
  /**
   * Optional error message to display in an error banner below the input area.
   * Takes priority over infoBanner if provided.
   */
  markdownErrorMessage?: string
  /**
   * Optional info banner to display inside the editor below the input area.
   * Only shown if markdownErrorMessage is not provided.
   */
  infoBanner?: React.ReactNode
  setIsFileUploading?: (value: boolean) => void
  lineNumber?: number
  filePath?: string
  startLineNumber?: number
  /** Callback fired when the input is focused */
  onInputFocus?: () => void
  /** When true, displays a skeleton loading state instead of the textarea. */
  generatingText?: boolean

  ref?: React.Ref<CommentBoxHandle>
}

const DEFAULT_VIEW_KEY = 'comment_box_last_view_mode'

export const getMarkdownEditorDefaultViewMode = () => {
  const safeLocalStorage = safeStorage('localStorage')
  const hybridEditorEnabled = isFeatureEnabled('markdown_experience_hybrid_editor')
  if (hybridEditorEnabled) {
    const cachedViewMode = safeLocalStorage.getItem(DEFAULT_VIEW_KEY) as DefaultViewMode | null
    return cachedViewMode ?? 'hybrid'
  }
  return 'edit'
}

export const CommentBox = ({
  ref: forwardedRef,
  ['aria-describedby']: ariaDescribedby,
  ['data-testid']: testId,
  label,
  labelledBy,
  showLabel,
  disabled = false,
  subject,
  viewMode,
  onChangeViewMode,
  value,
  placeholder,
  onChange,
  onSave,
  onCancel,
  validationResult,
  saveButtonText = 'Save',
  saveButtonTrailingIcon = true,
  actions,
  footerButtons,
  toolbarButtons,
  contentIsStale,
  fileUploadsEnabled = true,
  minHeightLines,
  maxHeightLines,
  className,
  onPrimaryAction,
  buttonSize,
  suggestedChangesConfig,
  markdownErrorMessage,
  infoBanner,
  teamHovercardsEnabled,
  setIsFileUploading,
  markdownSuggestionsFetchMethod = 'lazy',
  lineNumber,
  filePath,
  startLineNumber,
  onInputFocus,
  generatingText,
}: CommentBoxProps): ReactElement => {
  const apiSubject: Partial<ApiMarkdownSubject> = ApiMarkdownSubject.fromPropsSubject(subject)
  const projectId = subject?.type === 'project' ? subject?.id?.databaseId.toString() : undefined

  const [fetchSuggestions, setFetchSuggestions] = useState<boolean>(markdownSuggestionsFetchMethod === 'eager')
  const {mentions, references, emojis, savedReplies} = useMarkdownSuggestions(apiSubject, fetchSuggestions)
  const renderPreview = useGetPreview({
    ...apiSubject,
    path: filePath,
    lineNumber,
    startCommitOid: subject?.type === 'project' ? '' : subject?.comparison?.startCommitOid,
    startLineNumber,
    endCommitOid: subject?.type === 'project' ? '' : subject?.comparison?.endCommitOid,
    baseCommitOid: subject?.type === 'project' ? '' : subject?.comparison?.startCommitOid,
    subject: subject?.type === 'project' ? undefined : subject?.pullRequestNumber,
  })

  const uploadFile = useUploadFile(apiSubject.subjectRepoId?.toString(), projectId)
  const safeLocalStorage = safeStorage('localStorage')

  // Defaulting to edit mode on the server isn't ideal because it will cause a flicker from edit to hybrid mode when
  // SSR completes. But on the server we have no way of knowing what the default mode should be since we store that
  // in local storage. The only way to fix this would be to move the default view mode into a server-side database
  // field, which we probably should do eventually (or just make hybrid mode always the default when enabled, once
  // it has full feature parity with edit mode).
  // Of course, once we get to that point we'll also need to actually make the hybrid editor support SSR somehow.
  // Currently it renders only with CodeMirror, which is client-side only, so the initial render would have empty
  // contents if it was rendered via SSR. So we'd probably need to add some kind of suspense fallback.
  const [defaultViewMode] = useClientValue(() => getMarkdownEditorDefaultViewMode(), 'edit')

  const [currentViewMode, setCurrentViewMode] = useState<ViewMode>(viewMode ?? defaultViewMode)
  const [showContentIsStaleWarning, setShowContentIsStaleWarning] = useState(false)

  const ref = useRef<MarkdownEditorHandle>(null)
  useRefObjectAsForwardedRef(forwardedRef ?? null, ref)

  const warningRef = useRef<HTMLDivElement | null>(null)

  const isRepoSubject = subject !== undefined && 'repository' in subject && subject.repository !== undefined
  const isRepoSlashCommandEnabled = isRepoSubject && subject.repository.slashCommandsEnabled

  const [shouldInsertSuggestedChangeOnRender, setShouldInsertSuggestedChangeOnRender] = useState<boolean>(
    suggestedChangesConfig?.shouldInsertSuggestedChange ?? false,
  )

  useEffect(() => {
    setShowContentIsStaleWarning(contentIsStale ?? false)
    return () => {
      setShowContentIsStaleWarning(false)
    }
  }, [contentIsStale])

  const onSaveAction = useMemo(() => {
    if (showContentIsStaleWarning) {
      // This effectively disables/hides the save button
      return noop
    }
    return () => {
      onSave?.()
      setCurrentViewMode(defaultViewMode)
    }
  }, [onSave, showContentIsStaleWarning, defaultViewMode])

  useEffect(() => {
    // Ensures that when we get the correct default view mode from local storage after hydration, we then switch to
    // that view
    setCurrentViewMode(defaultViewMode)
    // I *think* we also reset the default view when the subject changes because that's considered a 'reset'. For
    // example the user might be moving from issue to issue in a docked side panel
  }, [apiSubject.subjectRepoId, apiSubject.subjectId, defaultViewMode])

  useEffect(() => {
    if (viewMode) {
      setCurrentViewMode(viewMode)
    }
  }, [viewMode])

  const onChangeViewModeInternal = useCallback(
    (v: ViewMode) => {
      setCurrentViewMode(v)
      if (isFeatureEnabled('markdown_experience_hybrid_editor'))
        safeLocalStorage.setItem(DEFAULT_VIEW_KEY, v === 'preview' ? 'edit' : v)
      onChangeViewMode?.(v)
    },
    [onChangeViewMode, safeLocalStorage],
  )

  const onInsertText = useCallback(
    (text: string) => {
      ref.current?.focus()
      try {
        document.execCommand('insertText', false, text)
      } catch {
        // this is a pretty naive approach and may fail in some environments (particularly JSDom)
        // but it will work in most cases and it's not worth reimplementing the full robust effort
        // used by the MarkdownEditor internals
      }
    },
    [ref],
  )

  // When the editor body is focused or the saved replies picker is opened we fetch suggestions
  const onActive = useCallback(() => {
    if (markdownSuggestionsFetchMethod === 'lazy' && !fetchSuggestions) {
      setFetchSuggestions(true)
    }
    onInputFocus?.()
  }, [fetchSuggestions, markdownSuggestionsFetchMethod, onInputFocus])

  // Only scroll to the warning banner if otherwise the user would not be able to see it
  const warningBannerPosition = 173
  // eslint-disable-next-line ssr-friendly/no-dom-globals-in-react-fc
  if (showContentIsStaleWarning && warningRef.current !== null && window.scrollY > warningBannerPosition) {
    warningRef.current.scrollIntoView()
  }

  // As to get access to the information about files being uploaded in the issue body we need access to the MarkdownEditor context,
  // we can also rely directly on the body and detect file uploading directly there
  const isUploadingFiles = useMemo(() => REGEX_STRINGS.isFileUploading.test(value), [value])

  useEffect(() => {
    if (setIsFileUploading) {
      setIsFileUploading(isUploadingFiles)
    }
  }, [isUploadingFiles, setIsFileUploading])

  const extractActionsFromFragment = useMemo(
    () =>
      (actionNode: ReactNode): ReactNode[] => {
        if (
          isValidElement(actionNode) &&
          typeof actionNode === 'object' &&
          typeof actionNode.type === 'symbol' &&
          String(actionNode.type) === 'Symbol(react.fragment)'
        ) {
          const fragmentNode = actionNode as ReactElement<React.ComponentProps<typeof Fragment>>
          // eslint-disable-next-line @eslint-react/no-children-to-array
          return Children.toArray(fragmentNode.props.children)
        }

        // eslint-disable-next-line @eslint-react/no-children-to-array
        return Children.toArray(actionNode)
      },
    [],
  )

  const addDisabledPropToActions = useMemo(
    () =>
      (actionsNode: ReactNode): ReactNode[] => {
        return extractActionsFromFragment(actionsNode).map((action, index) =>
          isValidElement<{disabled: boolean}>(action)
            ? // eslint-disable-next-line @eslint-react/no-clone-element
              cloneElement(action, {
                // eslint-disable-next-line @eslint-react/no-array-index-key
                key: index,
                disabled: disabled || isUploadingFiles,
              })
            : action,
        )
      },
    [extractActionsFromFragment, disabled, isUploadingFiles],
  )

  const viewerSettings = useViewerSettings(false)

  const editor = (
    <>
      {showContentIsStaleWarning && (
        <Flash ref={warningRef} variant="danger" className={styles.staleContentWarning}>
          {strings.staleContentError}
        </Flash>
      )}
      <MarkdownEditor
        aria-describedby={ariaDescribedby}
        labelledBy={labelledBy}
        disabled={disabled}
        value={value}
        placeholder={placeholder !== undefined ? placeholder : strings.leaveCommentLabel}
        emojiSuggestions={emojis}
        emojiTone={viewerSettings.settings.emojiTone}
        mentionSuggestions={mentions}
        referenceSuggestions={references}
        viewMode={currentViewMode}
        onChangeViewMode={onChangeViewModeInternal}
        onChange={onChange}
        onInputFocus={onActive}
        onRenderPreview={renderPreview}
        onUploadFile={fileUploadsEnabled ? uploadFile : undefined}
        acceptedFileTypes={fileUploadsEnabled ? acceptedFileTypes(isRepoSubject) : undefined}
        onPrimaryAction={() => {
          onSaveAction()
          onPrimaryAction?.()
        }}
        ref={ref}
        pasteUrlsAsPlainText={viewerSettings.settings.pasteUrlsAsPlainText}
        savedReplies={savedReplies}
        monospace={viewerSettings.settings.useMonospaceFont}
        minHeightLines={minHeightLines}
        maxHeightLines={maxHeightLines}
        className={className}
        teamHovercardsEnabled={teamHovercardsEnabled}
        onSavedRepliesOpen={onActive}
        banner={
          markdownErrorMessage ? (
            <MarkdownEditor.ErrorBanner>{markdownErrorMessage}</MarkdownEditor.ErrorBanner>
          ) : (
            infoBanner
          )
        }
        generatingText={generatingText}
        hybridEditorProps={
          suggestedChangesConfig?.showSuggestChangesButton || toolbarButtons
            ? {
                customToolbarButtons: (
                  <>
                    {toolbarButtons}
                    {suggestedChangesConfig?.showSuggestChangesButton && (
                      <HybridAddSuggestionButton
                        sourceContentFromDiffLines={suggestedChangesConfig?.sourceContentFromDiffLines}
                      />
                    )}
                  </>
                ),
              }
            : undefined
        }
      >
        <MarkdownEditor.Label visuallyHidden={!showLabel}>{label ?? 'Markdown Editor'}</MarkdownEditor.Label>
        <MarkdownEditor.Actions>
          {addDisabledPropToActions(actions)}
          {onCancel && (
            <MarkdownEditor.ActionButton variant="default" size={buttonSize} onClick={onCancel} value="Cancel">
              Cancel
            </MarkdownEditor.ActionButton>
          )}
          {onSaveAction && validationResult && (
            <SaveButton
              onSave={onSaveAction}
              validationResult={validationResult}
              trailingIcon={saveButtonTrailingIcon}
              disabled={disabled || isUploadingFiles}
              size={buttonSize}
            >
              {saveButtonText}
            </SaveButton>
          )}
        </MarkdownEditor.Actions>
        <MarkdownEditor.Toolbar>
          {suggestedChangesConfig?.showSuggestChangesButton && (
            <AddSuggestionButton
              shouldInsertSuggestionOnRender={shouldInsertSuggestedChangeOnRender}
              inputValue={value}
              onChange={onChange}
              sourceContentFromDiffLines={suggestedChangesConfig?.sourceContentFromDiffLines}
              editorRef={ref}
              onInsertSuggestedChange={() => {
                suggestedChangesConfig?.onInsertSuggestedChange()
                setShouldInsertSuggestedChangeOnRender(false)
              }}
            />
          )}
          {toolbarButtons}
          <MarkdownEditor.DefaultToolbarButtons />
          <SlashCommandsButton />
        </MarkdownEditor.Toolbar>
        {footerButtons && <MarkdownEditor.Footer>{footerButtons}</MarkdownEditor.Footer>}
      </MarkdownEditor>
    </>
  )

  return (
    <div data-testid={testId} className={styles.commentBoxContainer}>
      {isRepoSlashCommandEnabled ? (
        <SlashCommandsProvider subject={subject} onInsertText={onInsertText} onSave={onSaveAction}>
          {editor}
        </SlashCommandsProvider>
      ) : (
        editor
      )}
    </div>
  )
}

CommentBox.displayName = 'CommentBox'
