// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {CopilotNavigationWithContext} from '@github-ui/copilot-chat/components/navigation/CopilotNavigation'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {useChatManager} from '@github-ui/copilot-chat/CopilotChatManagerContext'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {copilotFeatureFlags} from '@github-ui/copilot-chat/utils/copilot-feature-flags'
import {AgentsList} from '@github-ui/dashboard-lists/components/AgentsList'
import {setTitle} from '@github-ui/document-metadata'
import {isFeatureEnabled} from '@github-ui/feature-flags'
import {sendEvent} from '@github-ui/hydro-analytics'
import type {IntentDetectionMode} from '../../types/intent-detection-mode'
import {TransactionalMessageBanner} from '@github-ui/in-product-targeting'
import {ContentView} from '@github-ui/pacer/ContentView'
import {Layout as PacerLayout} from '@github-ui/pacer/Layout'
import {useAppPayload} from '@github-ui/react-core/use-app-payload'
import {useFeatureFlag} from '@github-ui/react-core/use-feature-flag'
import {useSearchParams} from '@github-ui/use-navigate'
import {useCallback, useEffect, useRef, useState} from 'react'
import {ConsecutiveCAPI401sProvider} from '../../contexts/ConsecutiveCAPI401sContext'
import {useSSOChangeDetection} from '../../hooks/use-sso-change-detection'
import type {DropdownRepository} from '../../hooks/useCopilotRepoFetching'
import {useCreateAPITask} from '../../hooks/use-create-api-task'
import type {CreateAPITaskMutationParams} from '../../types/api-task'
import {useTaskEntrypoint} from '../../hooks/useTaskEntrypoint'
import {
  useTasks,
  getAgentTasksQueryKeyForMutation,
  getFlatTaskList,
  setFlatTaskList,
  PAGE_SIZE,
  type FetchTasksResponse,
} from '../../hooks/useTasks'
import type {AgentTasksAppPayload} from '../../types/agent-tasks-app-payload'
import type {Pull} from '../../types/pull'
import type {SelectedAgent, SessionState} from '../../types/session'
import {NewTaskChatInput} from '../new-task-chat-input/NewTaskChatInput'
import {PremiumRequestsBanner} from '../PremiumRequestsBanner'
import {
  TaskCreationFailedBannerList,
  type FailedAPITaskCreationAttempt,
  getAPITaskParamsFromAttempt,
} from '../TaskCreationFailedBanner'
import {
  CopilotCodingAgentQuotaBanner,
  useShouldShowCodingAgentQuotaBanner,
  // eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
} from '@github-ui/copilot-chat/components/quota/CopilotCodingAgentQuotaBanner'
import {CopilotDisclosure} from '../CopilotDisclosure'
import {AgentsBlankslate} from './AgentsBlankslate'
import {useInitializeAuthToken} from '../../hooks/use-initialize-auth-token'
import {TaskList} from './TaskList'
import {shouldLinkToRepoTaskView} from '../../utils/generate-task-path'
import styles from './AgentsView.module.css'

export interface TaskListItemProps {
  pullRequest: Pull
  state?: SessionState
  merged: boolean
  lastSessionStartDate?: string
  revisionCount: number
}

export function AgentsViewWrapper() {
  const {agentsEnabled, hasCEorCBAccess, memberRequestEntities, initialAuthToken} =
    useAppPayload<AgentTasksAppPayload>()

  // Initialize auth token from SSR payload before any CAPI requests are made
  useInitializeAuthToken(initialAuthToken)

  return (
    <ConsecutiveCAPI401sProvider>
      <PacerLayout data-testid="agents-layout">
        <PacerLayout.Sidebar>
          <CopilotNavigationWithContext />
        </PacerLayout.Sidebar>

        <PacerLayout.ColumnLeft>
          {!agentsEnabled ? (
            <AgentsBlankslate hasCEorCBAccess={hasCEorCBAccess} memberRequestEntities={memberRequestEntities} />
          ) : (
            <AgentsView />
          )}
        </PacerLayout.ColumnLeft>
      </PacerLayout>
    </ConsecutiveCAPI401sProvider>
  )
}

export function AgentsView() {
  const [activeTab, setActiveTab] = useState<'open' | 'closed'>('open')
  const [searchParams, setSearchParams] = useSearchParams()
  const {
    sessionsPollingInterval,
    showCopilotCodingAgentPremiumRequestsBanner,
    tasks: initialTasks,
    pullRequestsMap: initialPullRequestsMap,
    initialAuthToken,
    transactionalMessageBanner,
  } = useAppPayload<AgentTasksAppPayload>()

  // Initialize auth token from SSR payload to avoid double token fetching
  useInitializeAuthToken(initialAuthToken)

  const isTaskListV2Enabled = useFeatureFlag('copilot_agent_task_list_v2')
  const linkToSessionsInRepo = useFeatureFlag('copilot_mission_control_link_to_sessions_in_repo')
  const linkToSessionsInHyperspace = useFeatureFlag('copilot_mission_control_link_to_hyperspace')
  const takenActionOnAgentsViewRef = useRef(false)

  const [failedTaskCreationAttempts, setFailedTaskCreationAttempts] = useState<FailedAPITaskCreationAttempt[]>([])

  const [isQuotaExhausted, setIsQuotaExhausted] = useState(false)
  const shouldShowQuotaBanner = useShouldShowCodingAgentQuotaBanner()

  // Detect SSO changes and clear cached tasks
  useSSOChangeDetection()

  const decoupledModeEnabled = useFeatureFlag('copilot_mission_control_decoupled_mode')

  // It's not necessary to get the `isLoading` state from useTasks since it only applies to the first fetch,
  // and we already have all the initial data we need from the app payload.
  // TODO: Remove this call when we remove the old TaskList component below
  const {tasks, isError} = useTasks({
    sessionsPollingInterval,
    initialTasks,
    initialPullRequestsMap,
    // We need to include the filter/counts here in case this mounts before the AgentsList since they share
    // the same query key and we want to ensure the counts are available for the AgentsList to display
    taskFilter: activeTab,
    includeCounts: true,
  })

  const handleCreateTaskError = useCallback((error: Error, variables: CreateAPITaskMutationParams) => {
    setFailedTaskCreationAttempts(prev => [
      ...prev,
      {
        ...variables,
        errorMessage: error.message,
        timestamp: new Date().toISOString(),
      },
    ])
  }, [])

  const {createTask} = useCreateAPITask<FetchTasksResponse>({
    queryKey: getAgentTasksQueryKeyForMutation(),
    onError: handleCreateTaskError,
    pageSize: PAGE_SIZE,
    getFlatTaskList,
    setFlatTaskList,
    decoupledModeEnabled,
  })

  const manager = useChatManager()

  useEffect(() => {
    // Set the title of the page
    setTitle('Agents · GitHub Copilot')

    // Log feature flag values when AgentsView first renders
    sendEvent('agent_sessions.task_view', {
      target: 'AGENTS_VIEW_LOADED',
      defaultToTask: copilotFeatureFlags.defaultToTaskInput,
      defaultToTaskControl: copilotFeatureFlags.defaultToTaskControl,
      askModeDropdown: copilotFeatureFlags.askModeDropdown,
    })

    // Log bounce event if user leaves without creating a task
    return () => {
      if (!takenActionOnAgentsViewRef.current) {
        sendEvent('dotcom_chat.activate', {
          target: 'AGENTS_BOUNCE_TO_CHAT',
          mode: 'immersive',
          bounceToUrl: document.location.href,
          defaultToTask: copilotFeatureFlags.defaultToTaskInput,
          defaultToTaskControl: copilotFeatureFlags.defaultToTaskControl,
        })
      }
    }
  }, [])

  useEffect(() => {
    // clear out the thread on mount
    manager.selectThread(null, {includeThreads: false, clearTopic: true})
  }, [manager])

  const handleUserSubmit = useCallback(
    async (
      content: string,
      selectedRepo: DropdownRepository | null,
      selectedBranch: string,
      selectedAgent: SelectedAgent,
      selectedMode?: IntentDetectionMode,
      modelId?: string,
      createPullRequest?: boolean,
    ) => {
      takenActionOnAgentsViewRef.current = true

      const trimmedContent = content.trim()
      if (trimmedContent === '' || !selectedBranch || selectedBranch.trim() === '') return
      if (selectedRepo) {
        // Reset to open tab and page 1 when creating a new task
        setActiveTab('open')
        searchParams.delete('closed')
        searchParams.delete('page')
        setSearchParams(searchParams)

        // This mutation will automatically invalidate and refetch the tasks after completion
        createTask({
          nwo: selectedRepo.nameWithOwner,
          problemStatement: trimmedContent,
          baseRef: selectedBranch,
          eventType: 'agents_page',
          eventContent: trimmedContent,
          createPullRequest: !decoupledModeEnabled && createPullRequest,
          model: modelId,
          customAgent: selectedAgent?.subAgentSlug,
          agentId: selectedAgent?.topLevelAgentId,
          intentDetectionMode: selectedMode,
        })
      } else {
        manager.sendChatMessage({
          content: trimmedContent,
          thread: null,
          references: [],
        })
      }
    },
    [createTask, manager, searchParams, setSearchParams, decoupledModeEnabled],
  )

  useTaskEntrypoint(handleUserSubmit)

  // TODO: Now that we have uuids on the request, we might be able to use that to correlate requests and responses more easily.
  const handleRetry = (attemptIndex: number) => {
    const attempt = failedTaskCreationAttempts[attemptIndex]
    if (attempt) {
      // Remove this specific attempt from the list
      setFailedTaskCreationAttempts(prev => prev.filter((_, index) => index !== attemptIndex))
      createTask(getAPITaskParamsFromAttempt(attempt))
    }
  }

  const title = 'Agents'
  const description =
    "Delegate tasks to GitHub Copilot coding agent to work on in the background, and then monitor Copilot's progress."

  const [bannerDismissed, setBannerDismissed] = useState(false)

  return (
    <ContentView.Container noHeader width="small">
      {isFeatureEnabled('ipm_global_transactional_message_agents') && transactionalMessageBanner ? (
        <ContentView.Banner>
          <TransactionalMessageBanner banner={transactionalMessageBanner} />
        </ContentView.Banner>
      ) : null}
      {showCopilotCodingAgentPremiumRequestsBanner && !bannerDismissed ? (
        <ContentView.Banner>
          <PremiumRequestsBanner onBannerDismiss={() => setBannerDismissed(true)} />
        </ContentView.Banner>
      ) : null}
      {shouldShowQuotaBanner ? (
        <ContentView.Banner>
          <CopilotCodingAgentQuotaBanner
            onQuotaExhaustedChange={setIsQuotaExhausted}
            entrypointLocation="AGENTS_PAGE"
          />
        </ContentView.Banner>
      ) : null}
      <ContentView.Header>
        <ContentView.Title>{title}</ContentView.Title>
        <ContentView.Description>{description}</ContentView.Description>
      </ContentView.Header>
      <ContentView.Section>
        <NewTaskChatInput
          handleUserSubmit={handleUserSubmit}
          eventType="agents_page"
          isQuotaExhausted={isQuotaExhausted}
          decoupledModeEnabled={decoupledModeEnabled}
        />
        <TaskCreationFailedBannerList
          attempts={failedTaskCreationAttempts}
          onRetry={handleRetry}
          onDismiss={index => setFailedTaskCreationAttempts(prev => prev.filter((_, i) => i !== index))}
          className={styles.failedTaskBanners}
        />
      </ContentView.Section>

      <ContentView.Section>
        {isTaskListV2Enabled ? (
          <AgentsList
            title="Recent sessions"
            initialResultCount={PAGE_SIZE}
            showPillMenu
            showPagination
            linkToSessionsInRepo={shouldLinkToRepoTaskView(linkToSessionsInRepo, linkToSessionsInHyperspace)}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            includeCounts
          />
        ) : (
          <TaskList tasks={tasks} isError={isError} activeTab={activeTab} setActiveTab={setActiveTab} />
        )}
      </ContentView.Section>

      <CopilotDisclosure />
    </ContentView.Container>
  )
}
