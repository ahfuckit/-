/**
 * Builds the URL path for fetching Codespaces content
 * @param repoId - The repository ID
 * @param refName - The branch/ref name
 * @returns The encoded URL path for Codespaces
 */
export function buildCodespacesPath(repoId: number, refName: string): string {
  const encodeRef = encodeURIComponent(refName)
  return `/codespaces?codespace%5Bref%5D=${encodeRef}&current_branch=${encodeRef}&event_target=REPO_PAGE&repo=${repoId}`
}
