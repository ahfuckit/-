import {sendEvent} from '@github-ui/hydro-analytics'

import {makePlaceholderReference} from './copilot-chat-helpers'
import type {CopilotChatManager} from './copilot-chat-manager'
import type {CopilotChatState} from './copilot-chat-reducer'
import type {CopilotChatModel, ImageReference, LoadingReference} from './copilot-chat-types'
import {copilotFeatureFlags} from './copilot-feature-flags'
import {sendVisionErrorEvent} from './copilot-image-helpers'
import {UploadableFileAttachment} from './uploadable-file-attachment'

// Should be limited to images that are supported by our models and other dependencies.
// We pull the types from the model capabilities and filter for these types.
// NOTE - when we update this, we need to also update our Copilot::ChatAttachment::CHAT_SPECIFIC_CONTENT_TYPES
const ACCEPTED_BASE64_IMAGE_FILE_MIME_TYPES: string[] = ['image/gif', 'image/jpeg', 'image/png', 'image/webp']

const DOTCOM_CHAT_ATTACHMENT_LIMIT = 1
const DOTCOM_CHAT_ATTACHMENT_LIMIT_MULTIPLE = 4
const DOTCOM_CHAT_ATTACHMENT_SIZE_LIMIT = 3.75 * 1024 * 1024 // Claude only supports up to 3.75MB

export class CopilotImageAttacher {
  private state: CopilotChatState
  private manager: CopilotChatManager

  constructor(state: CopilotChatState, manager: CopilotChatManager) {
    this.state = state
    this.manager = manager
  }

  static getAllowedImageFileExtensions(model: CopilotChatModel): string {
    return this.getFileExtensions(model).join(',')
  }

  static isTypeAllowed(itemType: string, model: CopilotChatModel): boolean {
    itemType = itemType.toLowerCase()
    const mimeTypes = this.getMimeTypes(model)
    return mimeTypes.includes(itemType)
  }

  static getAllowedFiles(files: File[], model: CopilotChatModel): [allowedImages: File[], otherFiles: File[]] {
    const [allowedImages, otherFiles] = files.reduce(
      ([images, other]: [File[], File[]], file) =>
        this.isTypeAllowed(file.type, model) ? [[...images, file], other] : [images, [...other, file]],
      [[], []],
    )
    return [allowedImages, otherFiles]
  }

  static getAttachmentLimit(): number {
    return copilotFeatureFlags.attachMultipleImages
      ? DOTCOM_CHAT_ATTACHMENT_LIMIT_MULTIPLE
      : DOTCOM_CHAT_ATTACHMENT_LIMIT
  }

  static getAttachmentSizeLimit(): number {
    return DOTCOM_CHAT_ATTACHMENT_SIZE_LIMIT
  }

  static makeImageReference(file: File, threadIDToAssociate: string | null): ImageReference {
    const referenceId = crypto.randomUUID()
    const attachment = new UploadableFileAttachment(referenceId, file, threadIDToAssociate)

    return {
      id: referenceId,
      attachment,
      type: 'image',
      name: file.name || 'Image',
    }
  }

  static getFileExtensions(model: CopilotChatModel | CopilotChatModel[]): string[] {
    if (Array.isArray(model)) {
      const extensions = model.flatMap(m => this.getFileExtensions(m))
      return Array.from(new Set(extensions))
    }

    const extensions = this.getMimeTypes(model).map(type => `.${type.split('/')[1]}`)

    if (extensions.includes('.jpeg')) {
      extensions.push('.jpg')
    }

    return extensions
  }

  static getMimeTypes(model: CopilotChatModel | CopilotChatModel[]): string[] {
    if (Array.isArray(model)) {
      const allowedTypes = model.flatMap(m => this.getMimeTypes(m))
      return Array.from(new Set(allowedTypes))
    }

    if (model.capabilities.limits.vision) {
      const supportedTypes = model.capabilities.limits.vision.supported_media_types
      // for now, we can only return supported types that can be base 64 encoded. Remove once we stop
      // encoding images as base 64
      return supportedTypes.filter(type => ACCEPTED_BASE64_IMAGE_FILE_MIME_TYPES.includes(type))
    }

    return []
  }

  /**
   * Adds image attachments to the current chat thread. If no thread is selected and file upload is enabled,
   * a new thread will be created.
   *
   * @param files - The list of image files to attach.
   * @param uploadType - The type of upload action (e.g., 'drag', 'paste', 'menu', or 'unknown').
   * @param customCopilotId - (Optional) A custom Copilot ID to associate with the thread being created.
   * @param preventThreadSelection - (Optional) If true, prevents the selection of the thread being created. By default, it is false.
   */
  async addImageAttachments(
    files: File[],
    uploadType: 'drag' | 'paste' | 'menu' | 'unknown' = 'unknown',
  ): Promise<ImageReference[]> {
    if (files.length === 0) return []

    const previewFeaturesDisabled =
      copilotFeatureFlags.previewFeaturesVisionGate &&
      this.state.hasCEorCBAccess &&
      !this.state.optedInToPreviewFeatures

    if (previewFeaturesDisabled) {
      this.manager.addAmbientError(
        'Copilot in GitHub.com preview features must be enabled to upload images. Please request access from your administrator and try again.',
      )
      sendVisionErrorEvent('preview_features_not_enabled')
      return []
    }

    const imageReferenceCount = this.state.currentReferences.filter(reference => reference.type === 'image').length
    const imageLimit = CopilotImageAttacher.getAttachmentLimit()
    if (imageReferenceCount + files.length > imageLimit) {
      const errorMessage = copilotFeatureFlags.attachMultipleImages
        ? `You can add up to ${imageLimit} image files per message.`
        : 'Only one image can be uploaded at a time'
      this.manager.addAmbientError(errorMessage)
      sendVisionErrorEvent('file_limit_reached')
      return []
    }

    const newReferences: ImageReference[] = []
    const validFilesWithPlaceholders: Array<{file: File; placeholder: LoadingReference; reference: ImageReference}> = []

    for (const file of files) {
      // Valid file types: attempts to bypass the file types allowed by the input element can occur, so we should check here as well
      if (!CopilotImageAttacher.isTypeAllowed(file.type, this.state.model)) {
        sendVisionErrorEvent('included_unsupported_file', {fileTypes: file.type, uploadType})
        return []
      }

      // Base64 encoding always increases the size of a file, so it should be safe to return here in both upload flows.
      // We also check the size after encoding, but returning earlier here helps avoid some UI flickering.
      if (file.size > CopilotImageAttacher.getAttachmentSizeLimit()) {
        this.manager.addAmbientError('Only images below 3.75MB are supported')
        sendVisionErrorEvent('size_limit_exceeded', {size: file.size})
        return []
      }

      const reference = CopilotImageAttacher.makeImageReference(file, this.state.selectedThreadID)

      // Claude models reject images with any dimension exceeding 8000 pixels
      if (this.state.model.id.startsWith('claude') && this.state.model.capabilities.supports.vision) {
        const dimensions = await reference.attachment.getDimensions()
        if (dimensions.width && dimensions.height) {
          if (dimensions.width > 8000 || dimensions.height > 8000) {
            this.manager.addAmbientError(
              'The image you uploaded exceeds the maximum allowed dimensions for Claude models. Please try again with another model.',
            )
            sendVisionErrorEvent('dimension_limit_exceeded', {
              width: dimensions.width,
              height: dimensions.height,
            })
            continue
          }
        }
      }

      const placeholder = makePlaceholderReference(file.name)
      this.manager.addReference(placeholder, 'image-attacher')
      if (validFilesWithPlaceholders.length === 0) {
        this.manager.dispatch({type: 'WAITING_ON_ATTACHMENT', loading: true, attachmentType: 'file-upload'})
      }
      validFilesWithPlaceholders.push({file, placeholder, reference})
    }

    // Load each of the attachments
    try {
      // eslint-disable-next-line github/array-foreach
      validFilesWithPlaceholders.forEach(({file, placeholder, reference}) => {
        try {
          this.manager.setImageAttachmentUploaded(reference.id, reference.attachment)
          this.manager.replaceReference(placeholder, reference)
          sendEvent('dotcom_chat.vision.image_added', {uploadType})
          newReferences.push(reference)
        } catch (error) {
          this.manager.removeReference(placeholder)

          const UNEXPECTED_ERROR = `An unexpected error occurred while reading the file`
          if (typeof error === 'string') {
            this.manager.addAmbientError(`An error occurred uploading the attachment ${file.name}`)
            sendVisionErrorEvent('ErrorString', {message: error})
            throw Error(error)
          } else if (error instanceof Error) {
            sendVisionErrorEvent(error.name, {message: error.message})
            if (error.name === 'GenericServerError' && error.message.includes('Error creating policy')) {
              this.manager.addAmbientError(UNEXPECTED_ERROR)
            } else {
              this.manager.addAmbientError(UNEXPECTED_ERROR)
              throw error
            }
          } else {
            this.manager.addAmbientError(UNEXPECTED_ERROR)
            throw error
          }
        }
      })
    } finally {
      this.manager.dispatch({type: 'WAITING_ON_ATTACHMENT', loading: false})
    }

    return newReferences
  }
}
