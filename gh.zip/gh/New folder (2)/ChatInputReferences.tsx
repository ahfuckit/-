import {testIdProps} from '@github-ui/test-id-props'
import {FocusKeys} from '@primer/behaviors'
import {EyeClosedIcon, EyeIcon, FileIcon, KebabHorizontalIcon, TrashIcon} from '@primer/octicons-react'
import {ActionList, ActionMenu, Button, IconButton, Spinner, useFocusZone} from '@primer/react'
import {clsx} from 'clsx'
import type React from 'react'
import {useLayoutEffect} from 'react'
import {
  type KeyboardEventHandler,
  memo,
  type RefObject,
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from 'react'

import {useCopilotSpaceSelection} from '../contexts/CopilotSpaceSelectionContext'
import {useIsScrolledToEnd} from '../hooks/use-is-scrolled-to-end'
import {useOverflowDetection} from '../hooks/use-overflow-detection'
import {
  getRenderableReferences,
  isCopilotSpaceReference,
  referenceID,
  referencesAreEqual,
} from '../utils/copilot-chat-helpers'
import {TopicIndexStatus, useRepoIndexingState} from '../utils/copilot-chat-hooks'
import type {
  CopilotChatReference,
  CopilotChatReferenceType,
  CustomTokenRenderable,
  RepositoryReference,
} from '../utils/copilot-chat-types'
import {copilotFeatureFlags} from '../utils/copilot-feature-flags'
import {useChatStateLens, useChatStateValues} from '../utils/CopilotChatContext'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import styles from './ChatInputReferences.module.css'
import {ReferenceToken, type ReferenceTokenProps, RemoveReferenceTokenButton} from './ReferenceToken'
import referenceTokenStyles from './ReferenceToken.module.css'

interface ChatInputReferencesProps {
  className?: string
  /** Element to return focus to when all references are deleted. */
  returnFocusRef: RefObject<HTMLElement | null>
  tokenSize?: 'small' | 'medium'
  isLoading?: boolean
  onSelectReference?: (reference: CopilotChatReference, event?: React.MouseEvent<HTMLAnchorElement>) => void
  getReferenceVersion?: (reference: CopilotChatReference) => number | undefined
  showConvertToFileText?: boolean
  onConvertToFile?: () => void
  onConvertToFileDismiss?: () => void
  hideAttachmentsMenu?: boolean
  onRemoveReference?: (reference: CopilotChatReference) => void
  /**
   * Filter references to only show specific types.
   * When set, only references matching these types will be displayed.
   * Example: ['image'] to show only image references.
   */
  referenceTypeFilter?: readonly CopilotChatReferenceType[]
}

export const ChatInputReferences = memo(
  ({
    className,
    isLoading,
    returnFocusRef,
    tokenSize = 'medium',
    onSelectReference,
    getReferenceVersion,
    showConvertToFileText,
    onConvertToFile,
    onConvertToFileDismiss,
    hideAttachmentsMenu,
    onRemoveReference,
    referenceTypeFilter,
  }: ChatInputReferencesProps) => {
    const {currentReferences, implicitReferences, selectedThreadID} = useChatStateValues(
      'currentReferences',
      'implicitReferences',
      'selectedThreadID',
    )
    const manager = useChatManager()

    const scrollContainerRef = useRef<HTMLDivElement>(null)
    const scrolledToEnd = useIsScrolledToEnd(scrollContainerRef)
    const [showFullAttachmentNames, setShowFullAttachmentNames] = useState(false)
    const selectedReferences = useMemo(() => {
      let renderableRefs = getRenderableReferences(currentReferences)
      // Hide repository references when new picker is enabled and no thread exists yet (no messages sent)
      if (copilotFeatureFlags.copilotChatRepositoryPicker && !selectedThreadID) {
        renderableRefs = renderableRefs.filter(ref => ref.type !== 'repository')
      }
      // Filter to specific reference types when filter is provided
      if (referenceTypeFilter) {
        renderableRefs = renderableRefs.filter(ref => referenceTypeFilter.includes(ref.type))
      }
      return renderableRefs
    }, [currentReferences, selectedThreadID, referenceTypeFilter])
    const {setSelectedCopilotSpaceId} = useCopilotSpaceSelection()

    const containerRef = useRef<HTMLDivElement>(null)
    useFocusZone(
      {
        containerRef,
        focusableElementFilter: el => !el.hasAttribute('aria-hidden'),
        bindKeys: FocusKeys.ArrowHorizontal | FocusKeys.HomeAndEnd,
        focusInStrategy: 'previous',
        focusOutBehavior: 'stop',
      },
      [selectedReferences],
    )

    const tokensRef = useRef<Array<HTMLElement | null>>([])
    const onRemove = (reference: CopilotChatReference, index: number) => {
      const nextFocusTarget = tokensRef.current[index + 1] ?? tokensRef.current[index - 1] ?? returnFocusRef.current
      nextFocusTarget?.focus()
      onRemoveReference?.(reference)
      if (isCopilotSpaceReference(reference)) {
        setSelectedCopilotSpaceId(undefined)
      }
      manager.removeReference(reference)
    }

    const onRemoveAll = () => {
      // setTimeout to delay so we pull focus after the ActionMenu tries to return focus to its (now nonexistent) anchor
      setTimeout(() => returnFocusRef.current?.focus())
      const spaceReferences = selectedReferences.filter(isCopilotSpaceReference)
      if (spaceReferences.length > 0) {
        setSelectedCopilotSpaceId(undefined)
      }
      manager.clearCurrentReferences()
    }

    // Scroll to the token that was most recently added
    const prevSelectedReferences = useRef<CopilotChatReference[]>(selectedReferences)
    useLayoutEffect(() => {
      if (prevSelectedReferences.current.length < selectedReferences.length) {
        const newReference = selectedReferences.find(
          reference => !prevSelectedReferences.current.find(prevRef => referencesAreEqual(prevRef, reference)),
        )
        const lastIndex = newReference ? selectedReferences.indexOf(newReference) : -1
        tokensRef?.current?.[lastIndex]?.scrollIntoView({behavior: 'smooth', block: 'nearest', inline: 'end'})
      }
      prevSelectedReferences.current = selectedReferences
    }, [selectedReferences])

    const handleConvertToDismiss = useCallback(() => {
      onConvertToFileDismiss?.()
    }, [onConvertToFileDismiss])

    const handleToggleFullAttachmentNames = useCallback(() => {
      setShowFullAttachmentNames(prev => !prev)
    }, [])

    const hasOverflowingText = useOverflowDetection(
      selectedReferences,
      tokensRef,
      containerRef,
      `.${referenceTokenStyles.name}`,
    )

    const descriptionId = useId()

    const onKeyDown: KeyboardEventHandler<HTMLButtonElement> = event => {
      // eslint-disable-next-line @github-ui/ui-commands/no-manual-shortcut-logic
      if (event.key === 'Delete' || event.key === 'Backspace') {
        event.preventDefault()
        event.stopPropagation()
        if (showConvertToFileText) {
          handleConvertToDismiss()
        }
      }
    }

    if (selectedReferences.length === 0 && !isLoading && !showConvertToFileText) return null

    return (
      <div role="toolbar" aria-label="Attachments" className={clsx(className, styles.container)} ref={containerRef}>
        <div
          className={clsx(styles.attachmentsList, scrolledToEnd && styles.scrolledToEnd, isLoading && styles.loading)}
          ref={scrollContainerRef}
        >
          {showConvertToFileText && (
            <div className={styles.convertToFileContainer}>
              <Button
                onClick={onConvertToFile}
                leadingVisual={FileIcon}
                className={styles.convertToFileButton}
                aria-describedby={descriptionId}
                onKeyDown={onKeyDown}
              >
                Convert to file
              </Button>
              <RemoveReferenceTokenButton
                size={tokenSize}
                onRemove={handleConvertToDismiss}
                descriptionId={descriptionId}
              />
            </div>
          )}
          {selectedReferences.map((reference, index) => {
            // Check if reference provides its own token component
            const customRef = reference as CustomTokenRenderable
            if (customRef.TokenComponent) {
              const TokenComp = customRef.TokenComponent
              return (
                <TokenComp
                  key={referenceID(reference)}
                  reference={reference}
                  onRemove={() => onRemove(reference, index)}
                  size={tokenSize}
                  fullWidth={showFullAttachmentNames}
                  tokenRef={el => {
                    tokensRef.current[index] = el
                  }}
                />
              )
            }

            return reference.type === 'repository' ? (
              <RepoReferenceToken
                reference={reference}
                key={referenceID(reference)}
                ref={el => {
                  tokensRef.current[index] = el
                }}
                data-index={index}
                size={tokenSize}
                fullWidth={showFullAttachmentNames}
                onRemove={() => onRemove(reference, index)}
                onClick={onSelectReference}
                getReferenceVersion={getReferenceVersion}
              />
            ) : (
              <ReferenceToken
                reference={reference}
                key={referenceID(reference)}
                ref={el => {
                  tokensRef.current[index] = el
                }}
                data-index={index}
                size={tokenSize}
                fullWidth={showFullAttachmentNames}
                onRemove={() => onRemove(reference, index)}
                onClick={onSelectReference}
                getReferenceVersion={getReferenceVersion}
                isImplicitReference={implicitReferences.has(reference)}
              />
            )
          })}

          {isLoading && (
            <div className={styles.functionLoading} {...testIdProps('loading-indicator')}>
              <Spinner size="small" />
              Retrieving…
            </div>
          )}
        </div>

        {selectedReferences.length > 0 && !hideAttachmentsMenu && (
          <>
            <div className={styles.divider} />
            <ActionMenu>
              <ActionMenu.Anchor>
                <IconButton
                  icon={KebabHorizontalIcon}
                  aria-label="Attachments options"
                  variant="invisible"
                  tooltipDirection="n"
                  className={styles.menuButton}
                  size={tokenSize}
                />
              </ActionMenu.Anchor>

              <ActionMenu.Overlay width="small">
                <ActionList>
                  {hasOverflowingText && (
                    <ActionList.Item onSelect={handleToggleFullAttachmentNames}>
                      <ActionList.LeadingVisual>
                        {showFullAttachmentNames ? <EyeClosedIcon /> : <EyeIcon />}
                      </ActionList.LeadingVisual>
                      {showFullAttachmentNames ? 'Hide full attachment names' : 'Show full attachment names'}
                    </ActionList.Item>
                  )}
                  <ActionList.Item onSelect={onRemoveAll}>
                    <ActionList.LeadingVisual>
                      <TrashIcon />
                    </ActionList.LeadingVisual>
                    Remove attachments
                  </ActionList.Item>
                </ActionList>
              </ActionMenu.Overlay>
            </ActionMenu>
          </>
        )}
      </div>
    )
  },
)

ChatInputReferences.displayName = 'ChatInputReferences'

/**
 * It's just a ReferenceToken but it automatically kicks off repo indexing when mounted (if needed).
 */
function RepoReferenceToken({
  ref,
  ...props
}: ReferenceTokenProps & {reference: RepositoryReference; ref?: React.Ref<HTMLAnchorElement | null>}) {
  const repo = props.reference
  const indexingAllowed = useChatStateLens(s => s.model && !s.model.hasLimitedCapabilities)

  const nameWithOwner = `${repo.ownerLogin}/${repo.name}`

  const [indexingState, triggerIndexing] = useRepoIndexingState(nameWithOwner)

  const autoTriggeredIndexing = useRef(false)

  const isNotIndexed =
    indexingState.code === TopicIndexStatus.Unindexed || indexingState.docs === TopicIndexStatus.Unindexed

  useEffect(
    function startIndexing() {
      if (!autoTriggeredIndexing.current && isNotIndexed && indexingAllowed) {
        autoTriggeredIndexing.current = true
        triggerIndexing()
      }
    },
    [indexingAllowed, isNotIndexed, triggerIndexing],
  )

  return <ReferenceToken {...props} ref={ref} />
}
