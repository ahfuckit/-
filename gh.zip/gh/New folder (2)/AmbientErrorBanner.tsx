import {Banner} from '@primer/react'
import {useEffect, useRef, useState} from 'react'

import type {AmbientError} from '../utils/copilot-chat-reducer'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import styles from './AmbientErrorBanner.module.css'

export function AmbientErrorBanner({
  ambientError,
  useLargerBorderRadius = false,
}: {
  ambientError: AmbientError
  useLargerBorderRadius?: boolean
}) {
  const chatManager = useChatManager()
  const [bannerKey, setBannerKey] = useState(0)
  const borderRadiusClass = useLargerBorderRadius ? styles.largeBorderRadius : styles.mediumBorderRadius
  const errorMessageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (ambientError.message) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setBannerKey(prev => prev + 1)
      // Ensure focus shifts to the error message for screen readers
      // Add delay to allow screen readers to process the banner change
      const timeoutId = setTimeout(() => {
        if (errorMessageRef.current) {
          errorMessageRef.current.focus()
        }
      }, 250)

      return () => clearTimeout(timeoutId)
    }
  }, [ambientError])

  return (
    <Banner
      key={bannerKey}
      aria-atomic="true"
      className={`${styles.ambientErrorBanner} ${borderRadiusClass}`}
      description={
        <div ref={errorMessageRef} tabIndex={-1} style={{outline: 'none'}}>
          {ambientError.message}
        </div>
      }
      variant="critical"
      title="Error during copilot chat has occurred."
      hideTitle
      onDismiss={() => {
        chatManager.dismissAmbientError()
      }}
    />
  )
}
