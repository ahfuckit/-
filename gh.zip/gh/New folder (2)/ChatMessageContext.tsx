import {createContext, type PropsWithChildren, use, useMemo} from 'react'

import type {CopilotChatMessage} from '../utils/copilot-chat-types'

export interface ChatMessageContextProps {
  message: CopilotChatMessage
}

const ChatMessageContext = createContext<ChatMessageContextProps | undefined>(undefined)

export const ChatMessageProvider = ({message, children}: PropsWithChildren<ChatMessageContextProps>) => {
  const providerData = useMemo(() => ({message}) satisfies ChatMessageContextProps, [message])
  return <ChatMessageContext value={providerData}>{children}</ChatMessageContext>
}

export const useChatMessage = () => {
  const context = use(ChatMessageContext)
  if (!context) throw new Error('useChatMessage must be used with ChatMessageProvider.')
  return context
}
