import {VersionName} from '@github-ui/copilot-chat/components/VersionName'
import {AlertIcon, CheckIcon} from '@primer/octicons-react'
import {Banner, Button, Dialog, Spinner} from '@primer/react'
import {InlineMessage} from '@primer/react/experimental'
import React, {useCallback, useMemo} from 'react'

import {type DraftOrExistingIssue, getRevisionNumber} from '../content-preview-types'
import {useContentPreview} from '../ContentPreviewContext'
import styles from './BulkCreateDialog.module.css'
import {IssueIcon} from './IssueIcon'
import {type BlockedByDependencies, IssueTree as CommonIssueTree} from './IssueTree'
import {TREE_ERROR_KEY, useBulkIssueValidation} from './use-bulk-issue-validation'
import {type TreeNode, visit} from './use-draft-issue-tree-map'
import {useIssueCreationHandler} from './use-issue-creation-handler'

export function BulkCreateDialog({
  issueNode,
  onComplete,
  onCancel,
}: {
  issueNode: TreeNode<DraftOrExistingIssue>
  onComplete: () => void
  onCancel: () => void
}) {
  const rootNode = useMemo(() => {
    let currentNode: TreeNode<DraftOrExistingIssue> | undefined = issueNode
    while (currentNode?.parent) {
      currentNode = currentNode.parent
    }
    return currentNode
  }, [issueNode])

  const totalDraftIssueCount = useMemo(() => {
    let count = 0
    visit(rootNode, node => {
      if (node.item.type === 'new-issue') {
        count++
      }
    })
    return count
  }, [rootNode])

  // Use unified hook for issue creation
  const {handleCreate, isLoading, isComplete, isError, error, data} = useIssueCreationHandler({
    issueNode: rootNode,
    onComplete,
  })

  const {loading: isValidating, result: validationResult} = useBulkIssueValidation(rootNode)
  const hasValidationErrors = useMemo(() => {
    return validationResult && Object.values(validationResult).some(result => result.errorMessages.length > 0)
  }, [validationResult])

  const handleCancel = useCallback(() => {
    if (isLoading || isComplete) {
      return
    }
    onCancel()
  }, [isLoading, isComplete, onCancel])

  const labels = useMemo(() => {
    const distinctTypes = new Set<string>()
    visit(rootNode, node => distinctTypes.add(node.item.type))

    // if all existing issues
    if (distinctTypes.size === 1 && rootNode.item.type === 'existing-issue') {
      return {
        title: 'Update existing issues?',
        description: 'Clicking Update will update the relationships between the issues shown below.',
        button: 'Update issues',
      }
    }

    // if mixed tree with existing root
    if (distinctTypes.size > 1 && rootNode.item.type === 'existing-issue') {
      return {
        title: 'Create all linked draft issues?',
        description:
          "Clicking Create will publish all Copilot draft issues shown below. Existing sub-issues aren't displayed and remain unchanged.",
        button: totalDraftIssueCount === 1 ? 'Create 1 issue' : `Create ${totalDraftIssueCount} issues`,
      }
    }

    // if mixed tree with draft root
    if (distinctTypes.size > 1 && rootNode.item.type === 'new-issue') {
      return {
        title: 'Create all linked draft issues?',
        description: 'Clicking Create will publish the Copilot draft issues shown below.',
        button: totalDraftIssueCount === 1 ? 'Create 1 issue' : `Create ${totalDraftIssueCount} issues`,
      }
    }

    // if all draft issues
    return {
      title: 'Create all linked draft issues?',
      description:
        'These drafts are linked. Creating a sub-issue automatically publishes its parent and any nested drafts.',
      button: totalDraftIssueCount === 1 ? 'Create 1 issue' : `Create ${totalDraftIssueCount} issues`,
    }
  }, [rootNode, totalDraftIssueCount])

  const {openItem, openPreviewPane} = useContentPreview()
  const onNodeClick = useCallback(
    (node: TreeNode<DraftOrExistingIssue>) => {
      if (isLoading || isComplete) {
        return
      }
      openItem(node.item.id, true)
      openPreviewPane()
      onCancel()
    },
    [isComplete, isLoading, onCancel, openItem, openPreviewPane],
  )

  const warningMessage = useMemo(() => {
    if (validationResult[TREE_ERROR_KEY]) {
      return validationResult[TREE_ERROR_KEY]?.errorMessages[0]
    }
    return 'Fill out missing required fields to create all of these issues.'
  }, [validationResult])

  function renderBody() {
    if (isValidating) {
      return (
        <div className={styles.loadingIndicator} role="status" aria-label="Validating issues">
          <Spinner />
        </div>
      )
    }

    if (hasValidationErrors) {
      return (
        <>
          <Banner
            variant="warning"
            hideTitle
            title="Validation errors"
            description={warningMessage}
            className="tmp-mb-3"
          />
          <IssueTree
            issueNode={rootNode}
            onNodeClick={onNodeClick}
            statusSelector={node => {
              const errorMessage = validationResult[node.item.tag]?.errorMessages[0]
              if (errorMessage) {
                return {
                  trailingVisual: (
                    <AlertIcon className="fgColor-attention" data-testid={`warning-icon-${node.item.tag}`} />
                  ),
                  description: <span className="fgColor-attention">{errorMessage}</span>,
                }
              }
            }}
          />
        </>
      )
    }

    return (
      <>
        <p>{labels.description}</p>
        <IssueTree
          issueNode={rootNode}
          onNodeClick={onNodeClick}
          statusSelector={node => {
            const isCompleted = data?.job.completed_issues.some(issue => issue.tag === node.item.tag)
            return {
              trailingVisual: isCompleted && (
                <CheckIcon className="fgColor-success" data-testid={`success-icon-${node.item.tag}`} />
              ),
            }
          }}
        />
      </>
    )
  }

  return (
    <Dialog
      title={labels.title}
      onClose={handleCancel}
      renderFooter={() => {
        // Don't show the footer (buttons) while the validation spinner is active
        if (isValidating) {
          return null
        }

        return (
          <Dialog.Footer className={styles.dialogFooter}>
            <div className={styles.dialogFooterStatus}>
              {isError && <InlineMessage variant="critical">{error?.message}</InlineMessage>}
            </div>
            <div className={styles.dialogFooterActions}>
              <Button variant="default" onClick={handleCancel} inactive={isLoading || isComplete}>
                Cancel
              </Button>
              <Button
                variant="primary"
                onClick={handleCreate}
                loading={isLoading || isComplete}
                disabled={hasValidationErrors || isError}
              >
                {labels.button}
              </Button>
            </div>
          </Dialog.Footer>
        )
      }}
    >
      {renderBody()}
    </Dialog>
  )
}

function IssueTree({
  issueNode,
  onNodeClick,
  statusSelector,
}: {
  issueNode: TreeNode<DraftOrExistingIssue>
  onNodeClick: (node: TreeNode<DraftOrExistingIssue>) => void
  statusSelector?: (node: TreeNode<DraftOrExistingIssue>) =>
    | {
        trailingVisual?: React.ReactNode
        description?: React.ReactNode
      }
    | undefined
}) {
  const {versionedItems, items} = useContentPreview()

  const totalChildCount = useMemo(() => {
    let count = 0
    visit(issueNode, node => {
      if (node.parent) {
        count++
      }
    })
    return count
  }, [issueNode])

  const blockedByDependencies = (node: TreeNode<DraftOrExistingIssue>): BlockedByDependencies[] | undefined => {
    return node.blockedBy.map(b => {
      return {
        title: b.item.name ?? '',
        onClick: () => {
          onNodeClick(b)
        },
      }
    })
  }

  const renderChild = (node: TreeNode<DraftOrExistingIssue>) => {
    const version = getRevisionNumber(node.item.id, versionedItems, items)
    const details = statusSelector?.(node)

    return (
      <CommonIssueTree.Item
        key={node.item.tag}
        title={node.item.name}
        leadingVisual={<IssueIcon {...node.item} />}
        trailingBadge={
          <>
            {version != null ? <VersionName version={version} /> : undefined}
            <IssueLocation node={node} />
          </>
        }
        trailingVisual={details?.trailingVisual}
        description={details?.description}
        onClick={() => onNodeClick(node)}
        blockedBy={blockedByDependencies(node)}
      >
        {node.children.map(renderChild)}
      </CommonIssueTree.Item>
    )
  }

  const rootNodeVersion = getRevisionNumber(issueNode.item.id, versionedItems, items)
  const details = statusSelector?.(issueNode)

  return (
    <CommonIssueTree
      subIssueHeaderText={issueNode.item.type === 'existing-issue' ? 'New sub-issues' : undefined}
      subIssueCount={totalChildCount}
      hasTrailingVisuals
    >
      <CommonIssueTree.RootItem
        title={issueNode.item.name}
        leadingVisual={<IssueIcon {...issueNode.item} />}
        trailingBadge={
          <>
            {rootNodeVersion != null ? <VersionName version={rootNodeVersion} /> : undefined}
            <IssueLocation node={issueNode} />
          </>
        }
        trailingVisual={details?.trailingVisual}
        description={details?.description}
        onClick={() => onNodeClick(issueNode)}
        blockedBy={blockedByDependencies(issueNode)}
      />
      {issueNode.children.map(renderChild)}
    </CommonIssueTree>
  )
}

function IssueLocation({node}: {node: TreeNode<DraftOrExistingIssue>}) {
  if (!node.item.repository) {
    return
  }

  if (node.item.repository === node.parent?.item.repository) {
    return
  }

  return <span className="fgColor-muted">{node.item.repository}</span>
}
