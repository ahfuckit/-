import {copilotSpaceIdFromThread} from '@github-ui/copilot-spaces/utils/copilot-space-id-from-thread'
import {sendEvent} from '@github-ui/hydro-analytics'
import {clearSessionStorageByKeyPrefix} from '@github-ui/use-safe-storage/session-storage'
import {verifiedFetch} from '@github-ui/verified-fetch'
import type {Dispatch} from 'react'

import type {TraceAction} from '../components/tracing/utilities/trace-reducer'
import type {ImmersivePlugin} from '../plugin/copilot-immersive-plugin'
import {getActivePluginFromLocation} from '../plugin/plugin-helpers'
import {copilotChatHeaderButtonID, reviewUserMessage} from './constants'
import type {
  AddCopilotChatReferenceEvent,
  OpenCopilotChatEvent,
  SearchCopilotEvent,
  SymbolChangedEvent,
} from './copilot-chat-events'
import {
  buildMessage,
  COPILOT_BILLING_SETTINGS_URL,
  customInstructionsOwnersFromReferences,
  customInstructionsOwnersFromReferencesAsync,
  ERROR_MSG,
  ERRORS_BY_STATUS,
  ERRORS_BY_TYPE,
  getCustomInstructionsFromReferences,
  getCustomInstructionsFromReferencesAsync,
  getThreadStaticSuggestions,
  hasCustomInstructions,
  hasCustomInstructionsAsync,
  isFileReference,
  isRepository,
  isThreadOlderThan4Hours,
  makeOrgInstructionsReference,
  makeRepositoryReference,
  referencesAreEqual,
} from './copilot-chat-helpers'
import {CopilotChatMessageStreamer} from './copilot-chat-message-streamer'
import type {CopilotChatState, Dispatcher, Timings} from './copilot-chat-reducer'
import {CopilotChatService} from './copilot-chat-service'
import {getActiveMessages, getParentMessage} from './copilot-chat-subthreading-helpers'
import type {
  AppAgentRequestErrorPayload,
  ChatError,
  CopilotAgentConfirmation,
  CopilotChatAgent,
  CopilotChatDuplicate,
  CopilotChatEventPayload,
  CopilotChatIntentsType,
  CopilotChatMessage,
  CopilotChatMessageFeedback,
  CopilotChatMode,
  CopilotChatModel,
  CopilotChatOrg,
  CopilotChatReference,
  CopilotChatReferenceType,
  CopilotChatRepo,
  CopilotChatSettings,
  CopilotChatThread,
  CopilotClientConfirmation,
  CopilotCustomInstructions,
  CopilotSpaceId,
  CopilotSpacePayload,
  FileReference,
  MediaContentItem,
  MessageStreamingErrorType,
  MessageStreamingResponse,
  MessageStreamingResponseError,
  NotAuthorizedForAgentErrorPayload,
  RepositoryReference,
  SkillOptions,
  TopicItem,
} from './copilot-chat-types'
import {CopilotChatIntents, MESSAGE_STREAMING_ERROR_TYPES, SUPPORTED_FUNCTIONS} from './copilot-chat-types'
import {copilotFeatureFlags} from './copilot-feature-flags'
import {copilotLocalStorage, type SavedMessageSource} from './copilot-local-storage'
import {filterOutCustomCopilotReferences} from './custom-copilots-references-helpers'
import {toCopilotChatModels} from './models'
import {processTraceData} from './tracing'
import {type DotcomFileAttachment, UploadableFileAttachment} from './uploadable-file-attachment'

export const MAX_MESSAGES_PER_THREAD = 3000
export const MAX_SUBTHREADS_PER_MESSAGE = 99
const MAX_MESSAGES_FOR_THREAD_RENAMING = 8

const multipleAgentsAttemptMessage =
  "Only one agent is allowed per thread, and their context can't be shared. If you want to interact with another agent, please start a new thread and @ mention the new agent."

// We do not expect the list of models to change during a browser session, so cache the response
let modelsCache: CopilotChatModel[] | null = null

export interface SelectThreadOptions {
  clearTopic?: boolean
  includeThreads?: boolean
}

export class CopilotChatManager {
  dispatch: Dispatcher
  traceDispatch?: Dispatch<TraceAction> | null
  service: CopilotChatService
  private getChatState: () => CopilotChatState
  private hasCEorCBAccess: boolean
  private timings: Omit<Timings, 'endTime'> = {startTime: 0}

  // The following variables are stateful and require stable chat manager instance to support streaming,
  // interrupting and reloading the thread after interrupt.
  private streamer?: CopilotChatMessageStreamer
  private messageAbortController?: AbortController
  private reloadingThreadPromise: Promise<boolean> | undefined
  private fetchingThreadID: string | null = null
  private afterThreadReloadCallback: ((messages: CopilotChatMessage[]) => void) | undefined

  private plugins: ImmersivePlugin[]

  constructor(
    dispatch: Dispatcher,
    apiURL: string,
    ssoOrganizations: CopilotChatOrg[],
    getChatState: () => CopilotChatState,
    realIp: string | undefined,
    chatService: CopilotChatService | undefined,
    hasCEorCBAccess: boolean | undefined,
    plugins: ImmersivePlugin[],
    apiVersion?: string,
    traceDispatch?: Dispatch<TraceAction> | null,
  ) {
    this.dispatch = dispatch
    this.traceDispatch = traceDispatch
    this.service = chatService ?? new CopilotChatService(apiURL, ssoOrganizations, realIp, apiVersion)
    this.getChatState = getChatState
    this.hasCEorCBAccess = !!hasCEorCBAccess
    this.plugins = plugins
  }

  /**
   * Helper to fetch repository for custom instructions.
   * Creates a RepositoryReference from the fetched repo.
   */
  private async fetchRepoForInstructions(repoID: number) {
    const res = await this.service.fetchRepo(repoID)
    if (res.ok) {
      return makeRepositoryReference(res.payload)
    }
    return null
  }

  /**
   * Opens a new chat window
   * @param thread the thread to display (leave null to try to find an appropriate thread to open or start a new thread)
   * @param currentView
   * @param source what is triggering the open, e.g. 'search-bar' or 'header'
   * @param expectedReference a reference the thread should be relevant to, if the default one doesn't reference this, create a new thread.
   * @returns
   */
  async openChat(
    thread: CopilotChatThread | null,
    currentView: 'thread' | 'list',
    source: string,
    chatVisibleSettingPath?: string,
    expectedReference?: CopilotChatReference,
    forceNewThread?: boolean,
  ) {
    this.dispatch({type: 'OPEN_COPILOT_CHAT', source})

    if (currentView === 'thread') {
      await this.findOrStartNewThread(thread, expectedReference, forceNewThread)
    }

    copilotLocalStorage.setCollapsedState(false)

    const state = this.getChatState()
    const entryPointId = state.entryPointId ?? copilotChatHeaderButtonID
    setCopilotButtonAriaExpanded(entryPointId, true)

    if (chatVisibleSettingPath) {
      const data = new FormData()
      data.set('copilot_chat_visible', 'true')
      void verifiedFetch(chatVisibleSettingPath, {method: 'PUT', body: data})
    }
  }

  closeChat() {
    this.dispatch({type: 'CLOSE_COPILOT_CHAT'})
    copilotLocalStorage.setCollapsedState(true)
    const state = this.getChatState()
    const entryPointId = state.entryPointId ?? copilotChatHeaderButtonID
    setCopilotButtonAriaExpanded(entryPointId, false)
  }

  hideChat(chatVisibleSettingPath?: string) {
    this.dispatch({type: 'HIDE_COPILOT_CHAT'})
    this.closeChat()

    if (chatVisibleSettingPath) {
      const data = new FormData()
      data.set('copilot_chat_visible', 'false')
      void verifiedFetch(chatVisibleSettingPath, {method: 'PUT', body: data})
    }
  }

  toggleRepoCustomInstructions(value: boolean) {
    this.dispatch({type: 'TOGGLE_REPO_CUSTOM_INSTRUCTIONS', value})
    copilotLocalStorage.setRepoCustomInstructionsState(value)
  }

  viewAllThreads() {
    this.dispatch({type: 'VIEW_ALL_THREADS'})
  }

  viewCurrentThread() {
    this.dispatch({type: 'VIEW_CURRENT_THREAD'})
  }

  maxMessagesReached() {
    return this.getChatState().messages.length >= MAX_MESSAGES_PER_THREAD
  }

  setShouldReplaceHistoryOnNavigation(value: boolean) {
    this.dispatch({type: 'SET_SHOULD_REPLACE_HISTORY_ON_NAVIGATION', value})
  }

  async sendChatMessage({
    thread,
    content,
    references,
    topic,
    context,
    confirmations,
    customInstructions,
    model,
    customCopilotId,
    intent,
    parentMessageId,
    modeOverride,
    skillOptions,
    noSend,
    mediaContent,
  }: {
    thread: CopilotChatThread | null
    content: string
    references: CopilotChatReference[]
    topic?: CopilotChatRepo
    context?: CopilotChatReference[]
    confirmations?: CopilotClientConfirmation
    customInstructions?: CopilotCustomInstructions
    model?: CopilotChatModel | null
    customCopilotId?: CopilotSpaceId | null
    intent?: CopilotChatIntentsType
    parentMessageId?: string
    modeOverride?: string
    skillOptions?: SkillOptions
    /** if true, stops short of actually sending the message */
    noSend?: boolean
    /** if image attachments have been previously uploaded, use this */
    mediaContent?: MediaContentItem[]
  }): Promise<{
    thread: CopilotChatThread
    references: CopilotChatReference[]
    mediaContent: MediaContentItem[]
  } | null> {
    const repo = topic
    let threadToUse = thread

    if (!threadToUse) {
      const pendingUserMessage = buildMessage({
        role: 'user',
        content,
        mediaContent: [],
        references,
      })
      this.dispatch({
        type: 'SET_PENDING_FIRST_MESSAGE',
        message: pendingUserMessage,
      })

      try {
        threadToUse = await this.createThread({customCopilotId})
      } catch (e) {
        // This shouldn't happen, since the error coming out of createThread should be an Error object.
        let errorMessage = 'An unexpected error has occurred.'
        if (e instanceof Error) {
          errorMessage = e.message
        }
        this.handleSendMessageError(
          threadToUse,
          makeBasicError(errorMessage),
          content,
          'ERROR_THREAD_CREATION',
          errorMessage,
        )
        return null
      }
    }

    mediaContent ||= references.length
      ? await Promise.all(
          references
            .filter(ref => ref.type === 'image')
            .map(async (ref): Promise<MediaContentItem> => {
              const {attachment} = ref
              if (!attachment.threadID) {
                attachment.threadID = threadToUse?.id || null
                try {
                  await attachment.prefetch()
                } catch {
                  const errorMessage = 'An error occurred uploading image attachments'
                  this.handleSendMessageError(
                    threadToUse,
                    makeBasicError(errorMessage),
                    content,
                    'ERROR_IMAGE_UPLOAD',
                    errorMessage,
                  )
                }
              }
              const url = await attachment.url()
              const file = attachment.file
              return {
                mediaType: file.type,
                name: file.name,
                url,
                chatAttachmentUrl: url,
                width: attachment.width,
                height: attachment.height,
              }
            }),
        )
      : []

    // We filter the images out of references
    // as we don't want to send images to CAPI in the references array.
    // We'll send it in a separate media field instead.
    let filteredReferences: CopilotChatReference[] = references.filter(ref => ref.type !== 'image')
    // don't include unauthenticated figma references
    filteredReferences = filteredReferences.filter(ref => ref.type !== 'figma' || !ref.authenticationRequired)

    // Remove edited references from storage on message submission.
    if (threadToUse != null) {
      this.clearEditedReferencesFromSessionStorage(threadToUse.id)
    }

    if (noSend) {
      return {thread: threadToUse, references: filteredReferences, mediaContent}
    }

    await this.sendNewMessage(
      threadToUse,
      content,
      mediaContent,
      filteredReferences,
      intent,
      repo,
      context,
      confirmations,
      customInstructions,
      model,
      customCopilotId,
      parentMessageId,
      modeOverride,
      skillOptions,
    )
    return null
  }

  FindLastMessageID(): string {
    const activeMessages = getActiveMessages(this.getChatState().messages)
    return activeMessages[activeMessages.length - 1]?.id || 'root'
  }

  async retryLastUnsuccessfulChatMessage(thread: CopilotChatThread) {
    const {currentTopic, context, customInstructions, model} = this.getChatState()
    const repo = currentTopic

    const lastUserMessage = getActiveMessages(this.getChatState().messages).findLast(m => m.role === 'user')

    if (!lastUserMessage?.content) return

    // When retrying, we should preserve the original references,
    // instead of relying on the currentReferences (which may have been cleared).
    const references = lastUserMessage.references?.length
      ? lastUserMessage.references
      : (thread.currentReferences ?? [])
    const mediaContent = lastUserMessage.mediaContent || []

    this.dispatch({type: 'MESSAGES_CLEAR_LAST_ERROR'})
    this.unselectPreviousChildMessage(lastUserMessage)

    let parentMessageID = ''
    if (lastUserMessage.clientSide) {
      // If the last message is client-side-only, find last known server-side message and chain to that
      // If it's a user message, that means we have siblings and had error using retry feature
      // If it's an assistant message, that means we should continue the subthread
      // If there is no last active message, then this is the first message and should point to the root.
      const activeMessages = getActiveMessages(this.getChatState().messages)
      const lastServerMessage = activeMessages.findLast(message => !message.clientSide)
      if (lastServerMessage) {
        if (lastServerMessage.role === 'user') {
          // If last server message is user message, create new sibling to it
          // Note that we will keep previous messages/errors in UI until full page reload
          parentMessageID = lastServerMessage.parentMessageID || 'root'
        } else {
          // If last server message is assistant message, chain to it
          parentMessageID = lastServerMessage.id
        }
      } else {
        parentMessageID = 'root'
      }
    } else {
      parentMessageID = lastUserMessage.id
    }

    return this.sendMessage(
      thread,
      lastUserMessage.content,
      mediaContent,
      references,
      lastUserMessage.intent,
      context,
      repo,
      customInstructions,
      model,
      undefined,
      parentMessageID,
    )
  }

  /** Resends the user message that is a parent of an assistant message and creates a subthread
   * This supports the retry button in the assistant messages */
  async retryUserChatMessage(thread: CopilotChatThread, message: CopilotChatMessage, selectedModel?: CopilotChatModel) {
    const {currentTopic, context, customInstructions, model} = this.getChatState()
    const repo = currentTopic

    let parentMessage: CopilotChatMessage | undefined = undefined

    if (message.parentMessageID) {
      // Find the parent message by matching its ID with the parentMessageID of the provided message
      parentMessage = this.getChatState().messages.findLast(m => m.id === message.parentMessageID)
    }

    if (!parentMessage || !parentMessage.content) return

    // Terminate active message list after the parent so we can show streaming message
    this.unselectPreviousChildMessage(parentMessage)

    const references = parentMessage.references || []
    const mediaContent = parentMessage.mediaContent || []

    // Send same content as before, but include additional parent message ID
    // This prevents the user message from getting stored as a new message.
    return this.sendMessage(
      thread,
      parentMessage.content,
      mediaContent,
      references,
      message.intent,
      context,
      repo,
      customInstructions,
      selectedModel || model,
      undefined,
      parentMessage.id,
    )
  }

  /** Edits the user message and creates a subthread */
  async editUserChatMessage(thread: CopilotChatThread, message: CopilotChatMessage, content: string) {
    if (!content) return // Don't send empty messages

    const {currentTopic, context, customInstructions, messages, model} = this.getChatState()
    const repo = currentTopic

    const parentMessage = getParentMessage(messages, message)
    if (!parentMessage) return

    const parentMessageID = parentMessage?.id || ''

    const confirmationResponses = message.clientConfirmations ?? []
    const references = message.references || []
    const mediaContent = message.mediaContent || []

    const userMessage = buildMessage({
      role: 'user',
      content,
      mediaContent,
      references,
      thread,
      confirmationResponses,
      parentMessageID,
    })

    // Use async version only when feature flag is enabled to avoid microtask delays in tests
    const hasInstructions = copilotFeatureFlags.customInstructionsFileReferences
      ? await hasCustomInstructionsAsync(references, repoID => this.fetchRepoForInstructions(repoID))
      : hasCustomInstructions(references)
    const instructionsOwners = copilotFeatureFlags.customInstructionsFileReferences
      ? await customInstructionsOwnersFromReferencesAsync(references, repoID => this.fetchRepoForInstructions(repoID))
      : customInstructionsOwnersFromReferences(references)

    this.dispatch({
      type: 'MESSAGE_ADDED',
      message: userMessage,
      repoHasCustomInstructions: Boolean(hasInstructions),
      usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
      customInstructionsOwners: instructionsOwners,
    })

    if (this.reloadingThreadPromise) {
      this.dispatch({type: 'WAITING_ON_COPILOT', loading: true})

      // After thread is reloaded, re-add the new user message so it shows up in the UI
      this.afterThreadReloadCallback = () => {
        this.dispatch({
          type: 'MESSAGE_ADDED',
          message: userMessage,
          repoHasCustomInstructions: Boolean(hasInstructions),
          usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
          customInstructionsOwners: instructionsOwners,
        })
      }

      // Wait until thread reloads successfully
      // If reload failed, discard new message
      if (!(await this.reloadingThreadPromise)) return
    }

    // Find the first ancestor that is stored on server, and attach to that
    // This handles scenario where there are multiple errors and/or edit attempts between last server reply and the message being edited
    let ancestor: CopilotChatMessage | undefined = parentMessage
    while (ancestor) {
      if (!ancestor.clientSide) {
        break
      }
      ancestor = getParentMessage(messages, ancestor)
    }

    // Send same content as before, but include additional parent message ID
    return this.sendMessage(
      thread,
      content,
      mediaContent,
      references,
      message.intent,
      context,
      repo,
      customInstructions,
      model,
      undefined,
      ancestor?.id || '',
    )
  }

  handleFeedback(message: CopilotChatMessage, feedback: CopilotChatMessageFeedback) {
    this.dispatch({type: 'MESSAGE_FEEDBACK', message, feedback})
  }

  setSelectedMessage(message: CopilotChatMessage) {
    // clear edited references from session storage when switching messages
    this.clearEditedReferencesFromSessionStorage(message.threadID)
    this.dispatch({type: 'MESSAGES_SET_SELECTED_MESSAGE', message})
  }

  unselectPreviousChildMessage(message: CopilotChatMessage) {
    this.dispatch({type: 'MESSAGES_UNSELECT_PREVIOUS_MESSAGE', message})
  }

  async stopStreaming() {
    if (this.streamer) {
      // there is an active stream that we can just abort
      await this.streamer.stop()
      this.streamer = undefined
    } else {
      // currently waiting for Copilot to begin streaming, so just cancel the initial request
      this.messageAbortController?.abort()
    }

    this.dispatch({type: 'MESSAGE_STREAMING_STOPPED', timings: this.completeTiming()})
  }

  async getSystemPrompt() {
    const {mode} = this.getChatState()

    // When embedded flag is on, always use immersive prompt
    const effectiveMode = copilotFeatureFlags.immersiveEmbedded ? 'immersive' : mode
    const prompt = await this.systemPrompt(effectiveMode)
    return prompt
  }

  // Used to create a thread. Usage of this should be limited to not create too many empty threads.
  async createThread(opts?: {
    customCopilotId?: CopilotSpaceId | null
    preventThreadSelection?: boolean
    scopeId?: string
    savedMessageSource?: SavedMessageSource
  }): Promise<CopilotChatThread> {
    const {customCopilotId, preventThreadSelection = false, scopeId, savedMessageSource = 'immersive'} = opts || {}
    const res = await this.service.createThread(customCopilotId, scopeId)
    let thread: CopilotChatThread
    if (res.ok) {
      thread = res.payload
      copilotLocalStorage.migrateNullThreadToNewThread(thread.id, savedMessageSource)
      this.dispatch({type: 'THREAD_CREATED', thread, preventThreadSelection})

      return thread
    } else {
      throw new Error(res.error)
    }
  }

  private async sendNewMessage(
    thread: CopilotChatThread | null,
    content: string,
    mediaContent: MediaContentItem[],
    references: CopilotChatReference[],
    intent?: CopilotChatIntentsType,
    repo?: CopilotChatRepo,
    context?: CopilotChatReference[],
    confirmations?: CopilotClientConfirmation,
    customInstructions?: CopilotCustomInstructions,
    model?: CopilotChatModel | null,
    customCopilotId?: CopilotSpaceId | null,
    parentMessageID?: string,
    modeOverride?: string,
    skillOptions?: SkillOptions,
  ) {
    const {mode} = this.getChatState()
    const confirmationsArray = confirmations ? [confirmations] : []
    const userMessage = buildMessage({
      role: 'user',
      content,
      mediaContent,
      references,
      thread,
      confirmationResponses: confirmationsArray,
      parentMessageID: parentMessageID || this.FindLastMessageID(), // User messages are chained to the last visible message
      skillOptions,
    })

    // Use async version only when feature flag is enabled to avoid microtask delays in tests
    const hasInstructions = copilotFeatureFlags.customInstructionsFileReferences
      ? await hasCustomInstructionsAsync(references, repoID => this.fetchRepoForInstructions(repoID))
      : hasCustomInstructions(references)
    const instructionsOwners = copilotFeatureFlags.customInstructionsFileReferences
      ? await customInstructionsOwnersFromReferencesAsync(references, repoID => this.fetchRepoForInstructions(repoID))
      : customInstructionsOwnersFromReferences(references)
    this.dispatch({
      type: 'MESSAGE_ADDED',
      message: userMessage,
      repoHasCustomInstructions: Boolean(hasInstructions),
      usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
      customInstructionsOwners: instructionsOwners,
    })

    // create thread if one is not given
    if (!thread) {
      try {
        thread = await this.createThread({customCopilotId})
      } catch (e) {
        // This shouldn't happen, since the error coming out of createThread should be an Error object.
        let errorMessage = 'An unexpected error has occurred.'
        if (e instanceof Error) {
          errorMessage = e.message
        }
        this.handleSendMessageError(
          thread,
          makeBasicError(errorMessage),
          content,
          'ERROR_THREAD_CREATION',
          errorMessage,
        )
        return
      }
    }

    this.dispatch({type: 'THREAD_UPDATED', thread: {id: thread.id, updatedAt: new Date().toISOString()}})

    this.dispatch({type: 'CLEAR_CURRENT_REFERENCES'})

    // When we send a message to a thread using a particular model, save that model for the thread.
    if (model && (mode !== 'assistive' || copilotFeatureFlags.immersiveEmbedded)) {
      copilotLocalStorage.setModel(thread.id, model, false) // don't update default model
    }

    let overrideParentMessageID = ''
    if (!parentMessageID) {
      const activeMessages = getActiveMessages(this.getChatState().messages)
      const lastMessage = activeMessages[activeMessages.length - 1]
      if (lastMessage) {
        if (lastMessage.clientSide) {
          // If the last message is client-side-only, find last known server-side message and chain to that
          // Note that we are looking for assistant messages, so this will start new subthread at the last successful user message
          // If there is no last active message, then this is the first message and should point to the root.
          parentMessageID =
            activeMessages.findLast(message => !message.clientSide && message.role === 'assistant')?.id || 'root'
        } else {
          parentMessageID = lastMessage.id
        }
      } else {
        parentMessageID = 'root'
      }

      if (this.reloadingThreadPromise) {
        // Set loading state, since we have to wait
        this.dispatch({type: 'WAITING_ON_COPILOT', loading: true})
        this.afterThreadReloadCallback = messages => {
          if (messages.length === 0) return
          // We need to find the parent message ID of the last message in the current subthread
          // This should be the last message in the messages array, as we just cancelled it before reloading from server
          overrideParentMessageID = messages[messages.length - 1]!.id
          userMessage.parentMessageID = overrideParentMessageID
          this.dispatch({
            type: 'MESSAGE_ADDED',
            message: userMessage,
            repoHasCustomInstructions: Boolean(hasInstructions),
            usedRepoCustomInstructions: Boolean(hasInstructions && this.repoInstructionsEnabled()),
            customInstructionsOwners: instructionsOwners,
          })
        }

        // If reload failed, discard new message
        if (!(await this.reloadingThreadPromise)) return
      }
    }

    return this.sendMessage(
      thread,
      content,
      mediaContent,
      references,
      intent,
      context,
      repo,
      customInstructions,
      model,
      confirmations,
      overrideParentMessageID || parentMessageID,
      modeOverride,
      skillOptions,
    )
  }

  private async sendMessage(
    thread: CopilotChatThread,
    content: string,
    mediaContent: MediaContentItem[],
    references: CopilotChatReference[],
    intent?: CopilotChatIntentsType,
    context?: CopilotChatReference[],
    repo?: CopilotChatRepo,
    customInstructions?: CopilotCustomInstructions,
    model?: CopilotChatModel | null,
    confirmations?: CopilotClientConfirmation,
    parentMessageID?: string,
    modeOverride?: string,
    skillOptions?: SkillOptions,
  ) {
    intent ??= CopilotChatIntents.conversation

    const confirmationsArray = confirmations ? [confirmations] : []
    const streamingMessage = buildMessage({role: 'assistant', content: '', mediaContent: [], thread, parentMessageID})
    streamingMessage.messageIndex = -1

    this.dispatch({type: 'WAITING_ON_COPILOT', loading: true})

    const implicitContext =
      !references.length || (references.length === 1 && references[0]?.type === 'repository') ? context : undefined
    sendEvent('copilot.implicit_context', {
      usedImplicitContext: !!implicitContext,
      type: implicitContext?.[0]?.type,
      count: implicitContext?.length,
    })
    if (!references.length && repo) references = [makeRepositoryReference(repo)]

    const messageCustomInstructions: CopilotCustomInstructions[] = []

    // repo-level custom instructions
    // pull custom instructions from references instead
    if (this.repoInstructionsEnabled()) {
      const instructionsFromReferences = copilotFeatureFlags.customInstructionsFileReferences
        ? await getCustomInstructionsFromReferencesAsync(references, repoID => this.fetchRepoForInstructions(repoID))
        : getCustomInstructionsFromReferences(references)
      messageCustomInstructions.push(...instructionsFromReferences)
    }

    // NOTE: this has not been shipped yet and it might not ever be
    // org-level custom instructions
    // Only add default custom instructions if one is not associated with the repo
    if (
      customInstructions?.type === 'Organization' &&
      !messageCustomInstructions.find(i => i.type === 'Organization')
    ) {
      messageCustomInstructions.push(customInstructions)
    }

    if (customInstructions?.type === 'Assistant') {
      messageCustomInstructions.push(customInstructions)
    }

    // render reference if custom instructions exists
    const orgInstructions = messageCustomInstructions.find(i => i.type === 'Organization')
    if (orgInstructions) {
      references.push(makeOrgInstructionsReference(orgInstructions.owner))
    }

    const customInstructionsArray: string[] = messageCustomInstructions.map(i => i.prompt)

    const {mode} = this.getChatState()

    this.timings = {startTime: Date.now()}
    this.streamer = undefined
    this.messageAbortController = new AbortController()

    try {
      const defaultOptions = {
        threadID: thread.id,
        messageID: streamingMessage.id,
        content,
        mediaContent,
        intent,
        mode: modeOverride || mode,
        references,
        context: implicitContext ?? [],
        confirmations: confirmationsArray,
        customInstructions: customInstructionsArray,
        model: model?.id,
        customCopilotID: copilotSpaceIdFromThread(thread),
        parentMessageID,
        signal: this.messageAbortController.signal,
        skillOptions,
      }

      const options = this.activePlugin?.overrideCreateMessageOptions
        ? await this.activePlugin.overrideCreateMessageOptions(defaultOptions)
        : defaultOptions
      const res = await this.service.createMessageStreaming(options)
      if (!res.ok) {
        if (this.messageAbortController.signal.aborted) return
        this.handleSendMessageError(thread, makeBasicError(res.error), content, 'ERROR_MESSAGE_STREAMING', res.error)
      } else {
        const reader = res.response.body?.getReader()
        if (!reader) {
          this.handleSendMessageError(thread, makeBasicError(ERROR_MSG), content, 'ERROR_STREAM_READER', ERROR_MSG)
          return
        }
        // Extract the request ID for easy error reporting later
        // Note: This does not exist on local env since glb is not running to add the header
        streamingMessage.requestID = res.response.headers.get('x-github-request-id') || undefined
        const streamer = new CopilotChatMessageStreamer(reader)
        this.streamer = streamer

        this.dispatch({type: 'MESSAGE_STREAMING_STARTED', message: streamingMessage})

        await this.handleStreamingMessage(thread, streamer)
        await this.generateThreadName(thread)
      }
    } finally {
      this.streamer = undefined
      this.messageAbortController = undefined
    }
  }

  private repoInstructionsEnabled() {
    return !!copilotLocalStorage.getRepoCustomInstructionsState()
  }

  private async populateReferenceLanguage(reference: FileReference) {
    const response = await this.service.fetchLanguageForFileReference(reference)
    if (response.ok && response.payload.language) {
      const {languageName, languageId} = response.payload.language
      this.replaceReference(reference, {...reference, languageName, languageId})
    }
  }

  clearEditedReferencesFromSessionStorage(threadID: string) {
    clearSessionStorageByKeyPrefix(`edited-${threadID}-`)
  }

  addReference(reference: CopilotChatReference, source: string, opts: {implicit?: boolean} = {}) {
    this.dispatch({type: 'ADD_REFERENCE', reference, source, implicit: !!opts.implicit})

    if (isFileReference(reference) && (reference.languageId === undefined || reference.languageName === undefined)) {
      void this.populateReferenceLanguage(reference)
    }
  }

  removeReference(reference: CopilotChatReference | undefined) {
    if (reference) {
      abortInProcessImageDownloads([reference])
      this.dispatch({type: 'REMOVE_REFERENCES', references: [reference]})
    }
  }

  removeReferences(references: CopilotChatReference[]) {
    abortInProcessImageDownloads(references)
    this.dispatch({type: 'REMOVE_REFERENCES', references})
  }

  clearCurrentReferences = (keepTypes?: CopilotChatReferenceType[]) => {
    if (!keepTypes || !keepTypes.includes('image')) {
      abortInProcessImageDownloads(this.getChatState().currentReferences)
    }
    this.dispatch({type: 'CLEAR_CURRENT_REFERENCES', keepTypes})
  }

  clearAllReferences = () => {
    abortInProcessImageDownloads(this.getChatState().currentReferences)
    this.dispatch({type: 'CLEAR_ALL_REFERENCES'})
  }

  clearImplicitReferences() {
    this.dispatch({type: 'CLEAR_IMPLICIT_REFERENCES'})
  }

  /**
   * Replace the given reference in `currentReferences`. The reference to delete will be matched based on ID, and if
   * it is not found the operation will be a no-op.
   */
  replaceReference(referenceToDelete: CopilotChatReference, referenceToInsert: CopilotChatReference) {
    this.dispatch({type: 'REPLACE_REFERENCE', referenceToDelete, referenceToInsert})
  }

  setImageAttachmentUploaded(referenceId: string, dotcomAttachment: DotcomFileAttachment) {
    this.dispatch({type: 'IMAGE_UPLOADED', referenceId, dotcomAttachment})
  }

  selectModel(model: CopilotChatModel, updateLocalStorage = true, updateDefault = true) {
    this.dispatch({type: 'SELECT_MODEL', model})
    if (updateLocalStorage) {
      copilotLocalStorage.setModel(this.getChatState().selectedThreadID, model, updateDefault)
    }
  }

  private get activePlugin(): ImmersivePlugin | undefined {
    return getActivePluginFromLocation(location, this.plugins)
  }

  setCopilotSettings(settings: CopilotChatSettings) {
    copilotLocalStorage.settings = settings
  }

  async selectThread(thread: CopilotChatThread | null, options?: SelectThreadOptions) {
    const {clearTopic, includeThreads = true} = options ?? {}

    await this.fetchModels() // Make sure we have these first so that we can ensure the model we apply is available

    await this.stopStreaming()

    this.dispatch({type: 'CLEAR_SHARED_THREAD_CHANNEL'})

    this.dispatch({type: 'SELECT_THREAD', thread, clearTopic})
    const thingsToFetch: Array<Promise<unknown>> = []

    thingsToFetch.push(this.fetchMessages(thread?.id || null))
    if (includeThreads) thingsToFetch.push(this.fetchThreads())

    await Promise.all(thingsToFetch)
  }

  addMessage(
    role: 'user' | 'assistant',
    thread: CopilotChatThread | null,
    content: string,
    mediaContent: MediaContentItem[],
    references: CopilotChatReference[],
    clientConfirmations?: CopilotClientConfirmation[],
    clientSkillConfirmations?: CopilotAgentConfirmation[],
  ) {
    const message = buildMessage({
      role,
      content,
      mediaContent,
      references,
      thread,
      confirmationResponses: clientConfirmations,
      clientSkillConfirmations,
      parentMessageID: this.FindLastMessageID(), // Attach client skill request to any last message in current subthread
    })
    this.dispatch({type: 'MESSAGE_ADDED', message})
  }

  async renameThread(thread: CopilotChatThread, newName: string) {
    const res = await this.service.renameThread(thread.id, newName)
    if (res.ok) {
      this.dispatch({type: 'THREAD_UPDATED', thread: {id: thread.id, name: newName}})
    }
  }

  async generateThreadName(thread: CopilotChatThread) {
    // Validate that thread.id is not empty to prevent invalid API requests
    if (!thread.id || thread.id.trim() === '') return

    // If no thread name, we will ALWAYS try to generate one
    // and we will update the name if the thread is still relatively new (4 turns or less)
    const messages = this.getChatState().messages
    if (thread.name !== '' && messages.length > MAX_MESSAGES_FOR_THREAD_RENAMING) return

    const res = await this.service.generateThreadName(thread.id)
    if (res.ok) {
      this.dispatch({type: 'THREAD_UPDATED', thread: {id: thread.id, name: res.payload}})
    }
  }

  dismissAmbientError() {
    this.dispatch({type: 'DISMISS_AMBIENT_ERROR'})
  }

  addAmbientError(message: string) {
    this.dispatch({type: 'ADD_AMBIENT_ERROR', message})
    // Send telemetry for all ambient errors
    const {mode} = this.getChatState()
    sendEvent('dotcom_chat.activate.error', {
      target: 'ERROR_AMBIENT',
      mode,
      message,
    })
  }

  async clearThread(thread: CopilotChatThread) {
    const res = await this.service.clearThread(thread.id)
    if (res.ok) {
      this.dispatch({type: 'CLEAR_THREAD', threadID: thread.id})
    }
  }

  async deleteThreadKeepSelection(thread: CopilotChatThread) {
    this.dispatch({type: 'DELETE_THREAD_KEEP_SELECTION', thread})
    const res = await this.service.deleteThread(thread.id)
    if (!res.ok) this.dispatch({type: 'DELETE_THREAD_ERROR', thread, error: res.error})
  }

  async deleteAllThreadKeepSelection(threads: CopilotChatThread[]) {
    this.dispatch({type: 'DELETE_ALL_THREADS_KEEP_SELECTION', threads})
    const threadIds = threads.map(thread => thread.id)
    // Delete threads in batches of 100 as this is our current limit in API endpoint
    const batchSize = 100
    for (let i = 0; i < threadIds.length; i += batchSize) {
      const batch = threadIds.slice(i, i + batchSize)
      const res = await this.service.deleteAllThreads({threadIDs: batch})
      if (!res.ok) {
        this.dispatch({type: 'DELETE_ALL_THREADS_ERROR', threads, error: res.error})
      }
    }
  }

  async deleteThread(thread: CopilotChatThread) {
    // Clear edited references from session storage before deleting the thread
    this.clearEditedReferencesFromSessionStorage(thread.id)
    this.dispatch({type: 'DELETE_THREAD', thread})
    // await this.deleteTraceSpansForGivenThread(thread.id)
    const res = await this.service.deleteThread(thread.id)
    if (!res.ok) this.dispatch({type: 'DELETE_THREAD_ERROR', thread, error: res.error})
  }

  generateSuggestions(context: CopilotChatReference | CopilotChatRepo) {
    const suggestions = getThreadStaticSuggestions(context)
    this.dispatch({type: 'SUGGESTIONS_GENERATED', suggestions})
  }

  clearSuggestions(): void {
    this.dispatch({type: 'CLEAR_SUGGESTIONS'})
  }

  async handleOpenPanelEvent(
    thread: CopilotChatThread | null,
    e: OpenCopilotChatEvent,
    chatIsOpen: boolean,
    topic?: CopilotChatRepo,
    model?: CopilotChatModel | null,
  ) {
    const payload = e.payload
    const newThreadIsOpen = !thread && chatIsOpen
    const activeThreadIsOpen = thread && chatIsOpen
    // We always want to create a new thread for icebreakers, they don't make sense to include in an existing thread
    if (payloadIsIcebreaker(payload) || payloadIsNewThread(payload)) {
      await this.selectThread(null)
      thread = null
    } else if (payloadHasIntent(payload, [CopilotChatIntents.reviewPr])) {
      this.addMessage('user', payload.thread, reviewUserMessage, [], payload.references)
      this.addMessage('assistant', payload.thread, payload.completion, [], payload.references)
      // don't load all the threads as part of selecting the thread
      void this.selectThread(payload.thread, {includeThreads: false})
    } else if (newThreadIsOpen) {
      // If chat is open and there's no thread, skip finding a previous thread
    } else {
      // If the chat is not open and we are not attaching to an existing thread, create a new thread.
      if (copilotFeatureFlags.copilotChatOpeningThreadSwitch) {
        if ((payloadIsAttachToThread(payload) && !chatIsOpen) || activeThreadIsOpen) {
          thread = await this.findOrStartNewThread(thread)
        } else {
          await this.selectThread(null)
          thread = null
        }
      } else {
        thread = await this.findOrStartNewThread(thread)
      }
    }

    copilotLocalStorage.setCollapsedState(false)
    this.dispatch({type: 'HANDLE_EVENT_START', references: payload.references, id: payload.id})

    // conversation events are only used to set up references, unless it is an icebreaker
    if (
      payloadHasIntent(payload, [
        CopilotChatIntents.conversation,
        CopilotChatIntents.discussFileDiff,
        CopilotChatIntents.reviewPr,
      ]) &&
      !payloadIsIcebreaker(payload)
    ) {
      return
    }

    let source = `blob ${payload.intent}`
    if (payload.id) {
      source = `element ${e.payload.id}`
    }
    sendEvent('copilot.open_copilot_chat', {source})

    await this.sendNewMessage(
      thread,
      payload.content,
      [],
      payload.references ?? [],
      payload.intent,
      isRepository(topic) ? topic : undefined,
      undefined,
      undefined,
      undefined,
      model,
      undefined,
    )
  }

  async handleSearchCopilotEvent(e: SearchCopilotEvent, model?: CopilotChatModel | null) {
    const topic = await this.fetchCurrentRepo(e.repoNwo)
    const ref: RepositoryReference[] = topic ? [{type: 'repository', ...topic}] : []

    if (copilotFeatureFlags.copilotSearchBarRedirect) {
      const url = new URL('/copilot', window.location.origin)
      if (e.content) {
        // Strip search qualifiers and only pass free text
        const promptContent = e.content
          .replace(/\b\w+:[^\s]+/g, '')
          .replace(/\s+/g, ' ')
          .trim()
        if (promptContent) {
          url.searchParams.set('prompt', promptContent)
        }
      }
      window.location.href = url.toString()
      sendEvent('dotcom_chat.activate', {
        target: `MAIN_NAVIGATION_SEARCH_BAR_TO_IMMERSIVE`,
        mode: 'search-bar',
      })
    } else {
      void this.openChat(null, 'thread', 'search-bar')
      await this.sendNewMessage(
        null,
        e.content,
        [],
        ref,
        CopilotChatIntents.conversation,
        undefined,
        undefined,
        undefined,
        undefined,
        model,
      )
      sendEvent('copilot.open_copilot_chat', {source: 'search-bar'})
    }
  }

  handleAddReferenceEvent(e: AddCopilotChatReferenceEvent) {
    this.addReference(e.reference, 'event')
    if (e.openPanel) {
      this.dispatch({type: 'OPEN_COPILOT_CHAT', source: 'event', id: e.id})
    }
  }

  handleSymbolChangedEvent(e: SymbolChangedEvent) {
    const symbolContext = e.context
    this.dispatch({type: 'IMPLICIT_CONTEXT_UPDATED', context: [symbolContext]})
  }

  sortAndFilterThreads(
    threads: Map<string, CopilotChatThread>,
    filter: (thread: CopilotChatThread) => boolean = () => true,
  ): CopilotChatThread[] {
    const threadsArr = Array.from(threads.values())

    // Filter out threads that don't match the filter or have a scope.
    // Threads with a scope are associated with a specific context and should not be shown in the main thread list.
    return threadsArr
      .filter(thread => filter(thread) && !thread.scopeID)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
  }

  async sendMessageToNewThread(
    prevThreadID: string | null,
    message: string,
    refs: CopilotChatReference[],
    context?: CopilotChatReference[],
    model?: CopilotChatModel | null,
    source: SavedMessageSource = 'immersive',
  ) {
    if (message.trim() === '') {
      const [inferred, newMessage] = this.tryInferMessage(refs)
      if (!inferred || !newMessage) {
        return
      } else {
        message = newMessage
      }
    }

    if (prevThreadID) {
      copilotLocalStorage.setSavedMessageFast(prevThreadID, source, null)
      copilotLocalStorage.clearCurrentReferences(prevThreadID)
    }
    // Create a new thread and send the message
    await this.sendNewMessage(null, message, [], refs, undefined, undefined, context, undefined, undefined, model)
  }

  resolvePromise: (value: boolean | PromiseLike<boolean>) => void = () => {}

  // Create new promise that blocks new messages from being added until thread is reloaded
  startThreadReload() {
    this.reloadingThreadPromise = new Promise(resolve => {
      this.resolvePromise = resolve
    })
  }

  // Destroy blocking promise created by startThreadReload
  cancelThreadReload() {
    this.resolvePromise(false)
    this.resolvePromise = () => {}
    this.reloadingThreadPromise = undefined
    this.afterThreadReloadCallback = undefined
    this.fetchingThreadID = null
  }

  async fetchMessages(
    threadID: string | null,
    reloadThread: boolean = false,
    expectNewMessages: boolean = false,
  ): Promise<() => void> {
    const refs = copilotLocalStorage.getCurrentReferences(threadID)

    if (!threadID) {
      this.threadDataLoaded(threadID, [], refs || [])
      return () => {}
    }

    if (!reloadThread) {
      this.dispatch({type: 'MESSAGES_UPDATED', state: 'loading'})
    }

    const originalMessages = this.getChatState().messages
    this.fetchingThreadID = threadID

    const getMessages = async (shouldExpectNewMessages: boolean): Promise<boolean> => {
      const res = await this.service.listMessages(threadID)
      // If the thread has changed while we were waiting for the reloaded messages, ignore the response
      // because the user switched threads
      if (reloadThread && this.fetchingThreadID !== threadID) return false
      if (res.ok) {
        if (shouldExpectNewMessages && res.payload.messages.length === originalMessages.length) {
          // Try one more time to get the messages, in case server needed more time to save the cancelled message
          return getMessages(false)
        } else {
          const thread = res.payload.thread
          this.threadDataLoaded(threadID, res.payload.messages, refs || thread.currentReferences || [])
          if (this.afterThreadReloadCallback) {
            this.afterThreadReloadCallback(res.payload.messages)
            this.afterThreadReloadCallback = undefined
          }
          return true
        }
      } else {
        this.setMessageUpdatedError(res.status, res.payload?.missingOrgIds)
        this.afterThreadReloadCallback = undefined
        return false
      }
    }
    const result = await getMessages(expectNewMessages)
    // Once state updates, unblock new messages from being added, if thread reloaded successfully and user didn't change active thread
    return () => {
      this.resolvePromise(result)
      this.resolvePromise = () => {}
      this.reloadingThreadPromise = undefined
    }
  }

  async fetchSharedThreadMessages(threadID: string | null) {
    if (!threadID) return

    this.dispatch({type: 'MESSAGES_UPDATED', state: 'loading'})

    const res = await this.service.listSharedThreadMessages(threadID)
    this.dispatch({
      type: 'FETCH_SHARED_THREAD_MESSAGES',
      ok: res.ok,
      status: res.status,
      shareId: threadID,
      originalThreadId: res.ok ? res.payload.thread.id : undefined,
    })

    if (res.ok) {
      this.threadDataLoaded(threadID, res.payload.messages, [])

      // Set the current model based on the model used in the shared thread's
      // most recently created message.
      await this.fetchModels()
      const lastModelID = res.payload.messages?.at(-1)?.model
      const lastModel = lastModelID && this.getChatState().availableModels?.find(m => m.id === lastModelID)
      if (lastModel) this.selectModel(lastModel)
    } else {
      this.setMessageUpdatedError(res.status, res.payload?.missingOrgIds)
    }
  }

  setMessageUpdatedError(status: number, missingOrgIds?: number[]) {
    this.dispatch({
      type: 'MESSAGES_UPDATED',
      state: 'error',
      ...(status === 404 ? {notFound: true, missingOrgIds} : {}),
    })
  }

  selectReference(reference: CopilotChatReference | null) {
    this.dispatch({type: 'SELECT_REFERENCE', reference})
  }

  setTopRepositoryTopics(topics: TopicItem[] | undefined) {
    this.dispatch({type: 'SET_TOP_REPOSITORIES', topics})
  }

  private async handleStreamingMessage(thread: CopilotChatThread, streamer: CopilotChatMessageStreamer) {
    try {
      for await (const message of streamer.stream()) {
        this.processStreamingMessage(thread, message)
      }
    } catch (e) {
      let error: ChatError
      if (this.isWrappedStreamingResponseError(e)) {
        error = this.getStreamingErrorMessage(e.error)
      } else {
        error = makeBasicError(ERROR_MSG)
        // Only track generic streaming errors if it's not a wrapped error (those are tracked in getStreamingErrorMessage)
        const {mode} = this.getChatState()
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_STREAMING_GENERIC',
          mode,
          message: 'An unexpected error occurred during message streaming.',
        })
      }

      this.handleSendMessageError(thread, error)

      return
    }
  }

  private isWrappedStreamingResponseError(e: unknown): e is {error: MessageStreamingResponseError} {
    return (
      !!e &&
      typeof e === 'object' &&
      'error' in e &&
      !!e.error &&
      typeof e.error === 'object' &&
      'errorType' in e.error &&
      typeof e.error.errorType === 'string' &&
      MESSAGE_STREAMING_ERROR_TYPES.includes(e.error.errorType as MessageStreamingErrorType)
    )
  }

  private processStreamingMessage(thread: CopilotChatThread, messageResponse: MessageStreamingResponse) {
    this.timings.firstByte ??= Date.now()
    switch (messageResponse.type) {
      case 'content': {
        this.timings.firstToken ??= Date.now()
        this.dispatch({type: 'MESSAGE_STREAMING_TOKEN_ADDED', token: messageResponse.body})
        break
      }
      case 'functionCall': {
        if (functionIsSupported(messageResponse.name)) {
          this.dispatch({
            type: 'MESSAGE_STREAMING_FUNCTION_CALLED',
            name: messageResponse.name,
            status: messageResponse.status,
            arguments: messageResponse.arguments,
            errorMessage: messageResponse.errorMessage,
            references: messageResponse.references,
            statusMessage: messageResponse.statusMessage,
            callId: messageResponse.callId,
          })
        }
        break
      }
      case 'confirmation': {
        this.dispatch({
          type: 'MESSAGE_STREAMING_CONFIRMATION',
          title: messageResponse.title,
          message: messageResponse.message,
          confirmation: messageResponse.confirmation,
        })
        break
      }
      case 'threadTitle': {
        this.dispatch({
          type: 'THREAD_UPDATED',
          thread: {
            ...thread,
            name: messageResponse.title,
          },
        })
        break
      }
      case 'complete': {
        // Filters out the message's references that are coming from the custom copilot agent
        messageResponse.references = filterOutCustomCopilotReferences(messageResponse.references)

        this.dispatch({
          type: 'MESSAGE_STREAMING_COMPLETED',
          messageResponse,
          timings: this.completeTiming(),
        })
        this.handleSendMessageSuccess(thread)
        break
      }
      case 'error': {
        const errMsg = this.getStreamingErrorMessage(messageResponse)
        this.handleSendMessageError(thread, errMsg)
        break
      }
      case 'debug': {
        // eslint-disable-next-line no-console
        console.log('Prompt Body:', messageResponse.body)
        break
      }
      case 'trace': {
        const streamingMessageId = this.getChatState().streamingMessage?.createdAt
        try {
          // Only process traces if we have a trace ID from the backend
          if (!messageResponse.traceId) {
            // eslint-disable-next-line no-console
            console.error('Received trace data without trace ID from backend, ignoring trace')
            break
          }

          const rootNodes = processTraceData(messageResponse.spans)
          if (rootNodes[0]) {
            const messageId = streamingMessageId || messageResponse.traceId

            this.traceDispatch?.({
              type: 'SET_TRACE_INFO',
              traceInfo: {
                spanNode: rootNodes[0],
                messageId,
                threadId: thread.id,
                actualTraceId: messageResponse.traceId,
              },
            })
          }
        } catch (e) {
          // eslint-disable-next-line no-console
          console.error('Failed to process trace info:', e)
        }
        break
      }
      case 'agentError':
        this.dispatch({
          type: 'AGENT_ERROR',
          error: {
            type: messageResponse.agentErrorType,
            code: messageResponse.code,
            message: messageResponse.message,
            identifier: messageResponse.identifier,
          },
        })
        break
    }
  }

  private getStreamingErrorMessage(res: MessageStreamingResponseError): ChatError {
    const {mode} = this.getChatState()
    switch (res.errorType) {
      case 'publicCode': {
        let docsURL =
          'https://docs.github.com/en/copilot/managing-copilot/managing-copilot-as-an-individual-subscriber/managing-copilot-policies-as-an-individual-subscriber'
        let message = (
          <>
            This response cannot be shown because it references public code, which is restricted by{' '}
            <a href={docsURL}>your Copilot settings</a>.
          </>
        )

        if (this.hasCEorCBAccess) {
          docsURL =
            'https://docs.github.com/en/enterprise-cloud@latest/copilot/managing-copilot/managing-github-copilot-in-your-organization/managing-policies-for-copilot-in-your-organization'
          message = (
            <>
              This response cannot be shown because it references public code, which is restricted by{' '}
              <a href={docsURL}>your organization&apos;s Copilot settings</a>.
            </>
          )
        }

        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_PUBLIC_CODE',
          mode,
          message:
            'This response cannot be shown because it references public code, which is restricted by your Copilot settings.',
        })

        return {
          type: 'publicCode',
          isError: true,
          message,
          retryable: true, // Copilot may reference different code on a retry that isn't restricted
        }
      }
      case 'filtered': {
        const termsURL =
          'https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features#github-copilot'
        const message = (
          <>
            This response has been filtered because it violates <a href={termsURL}>GitHub&apos;s safety policies</a>.
          </>
        )
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_FILTERED_RESPONSE',
          mode,
          message: "This response has been filtered because it violates GitHub's safety policies.",
        })
        return {
          type: 'filtered',
          isError: true,
          message,
          retryable: false, // either the prompt or the response got matches in a RAI filter, which should not be retried
        }
      }
      case 'contentTooLarge':
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_CONTENT_TOO_LARGE',
          mode,
          message: ERRORS_BY_STATUS[413] || ERROR_MSG,
        })
        return makeNonRetryableError(ERRORS_BY_STATUS[413] || ERROR_MSG)
      case 'rateLimit':
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_RATE_LIMIT',
          mode,
          message: ERRORS_BY_STATUS[429] || ERROR_MSG,
        })
        return makeBasicError(ERRORS_BY_STATUS[429] || ERROR_MSG)
      case 'agentUnauthorized': {
        const details = JSON.parse(res.description) as NotAuthorizedForAgentErrorPayload
        const authorizeURL = `You haven't authorized ${details.name} to access your account. You can do that by going here: ${window.location.origin}/login/oauth/authorize?client_id=${details.client_id}`
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_AGENT_UNAUTHORIZED',
          mode,
          message: authorizeURL,
        })
        return {type: 'agentUnauthorized', isError: true, message: authorizeURL, details}
      }
      case 'agentRequest': {
        const details = JSON.parse(res.description) as AppAgentRequestErrorPayload
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_AGENT_REQUEST',
          mode,
          message: details.message,
        })
        return {type: 'agentRequest', isError: true, message: details.message, details}
      }
      case 'multipleAgentsAttempt': {
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_MULTIPLE_AGENTS_ATTEMPT',
          mode,
          message: multipleAgentsAttemptMessage,
        })
        return makeBasicError(multipleAgentsAttemptMessage)
      }
      case 'networkError':
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_NETWORK',
          mode,
          message: ERRORS_BY_STATUS[408] || ERROR_MSG,
        })
        return makeBasicError(ERRORS_BY_STATUS[408] || ERROR_MSG)
      case 'quotaExceeded':
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_QUOTA_EXCEEDED',
          mode,
          message: res.description || ERRORS_BY_STATUS[402] || ERROR_MSG,
        })
        return makeNonRetryableError(res.description || ERRORS_BY_STATUS[402] || ERROR_MSG)
      case 'billingNotConfigured':
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_BILLING_NOT_CONFIGURED',
          mode,
          message: res.description || ERRORS_BY_STATUS[402] || ERROR_MSG,
        })
        return makeBillingNotConfiguredError()
      case 'exception':
      default:
        sendEvent('dotcom_chat.activate.error', {
          target: 'ERROR_EXCEPTION',
          mode,
          message: ERRORS_BY_TYPE[res.errorType] || ERROR_MSG,
        })
        return makeBasicError(ERRORS_BY_TYPE[res.errorType] || ERROR_MSG)
    }
  }

  private handleSendMessageSuccess(thread: CopilotChatThread) {
    // Note: Saved user message is cleared by useChatInput when the submit is initiated,
    // so we don't need to clear it here. This allows each source to manage its own saved messages.
    copilotLocalStorage.clearCurrentReferences(thread.id)

    this.dispatch({type: 'WAITING_ON_COPILOT', loading: false})
  }

  private handleSendMessageError(
    thread: CopilotChatThread | null,
    error: ChatError,
    submittedInput?: string,
    telemetryTarget?: string,
    errorMessage: string = ERROR_MSG,
  ) {
    if (thread && submittedInput) {
      copilotLocalStorage.setSavedUserMessageOnError(thread.id, submittedInput)
    }

    // Errors get added to last found user message
    const parentMessageID =
      getActiveMessages(this.getChatState().messages).findLast(m => m.role === 'user')?.id || 'root'

    const message = buildMessage({
      role: 'assistant',
      content: '',
      mediaContent: [],
      error,
      thread,
      parentMessageID,
    })
    this.dispatch({type: 'MESSAGE_ADDED', message})
    this.dispatch({type: 'WAITING_ON_COPILOT', loading: false})
    this.dispatch({type: 'MESSAGE_STREAMING_FAILED', timings: this.completeTiming()})

    if (telemetryTarget) {
      const {mode} = this.getChatState()
      sendEvent('dotcom_chat.activate.error', {
        target: telemetryTarget,
        mode,
        message: errorMessage,
      })
    }
  }

  async fetchModels() {
    if (modelsCache) {
      const {availableModels} = this.getChatState()
      if (!availableModels || modelsCache.length > availableModels.length) {
        this.dispatch({type: 'MODELS_LOADED', models: modelsCache})
      }
      return
    }

    this.dispatch({type: 'MODELS_LOADING'})

    const res = await this.service.listModels()

    if (res.ok) {
      const models = toCopilotChatModels(res.payload)
      modelsCache = models
      this.dispatch({type: 'MODELS_LOADED', models})

      const storedModelID = copilotLocalStorage.getModel(this.getChatState().selectedThreadID)?.id
      const model = models.find(m => m.id === storedModelID) || models.find(m => m.is_chat_default)

      if (model) {
        this.dispatch({type: 'SELECT_MODEL', model})
      }
    } else {
      this.dispatch({type: 'MODELS_LOADING_ERROR', error: res.error})
    }
  }

  private fetchThreadsPromise: Promise<CopilotChatThread[] | null> | null = null
  async fetchThreads(): Promise<CopilotChatThread[] | null> {
    if (!this.fetchThreadsPromise) {
      try {
        this.fetchThreadsPromise = this.fetchThreadsImpl()
        return await this.fetchThreadsPromise
      } finally {
        this.fetchThreadsPromise = null
      }
    }
    return this.fetchThreadsPromise
  }

  private async fetchThreadsImpl(): Promise<CopilotChatThread[] | null> {
    this.dispatch({type: 'THREADS_LOADING'})

    const res = await this.service.fetchThreads()
    if (!res.ok) {
      // There is a bit of a race condition with the THREADS_LOADING event
      // Wait before dispatching the THREADS_LOADING_ERROR event
      setTimeout(
        () =>
          this.dispatch({
            type: 'THREADS_LOADING_ERROR',
            message: res.error,
            status: res.status,
          }),
        100,
      )
      return null
    }

    // There is a bit of a race condition with the THREADS_LOADING event
    // Wait before dispatching the THREADS_LOADED event
    setTimeout(() => this.dispatch({type: 'THREADS_LOADED', threads: res.payload}), 100)

    return res.payload
  }

  async fetchSharedThreads(): Promise<CopilotChatThread[] | null> {
    this.dispatch({type: 'SHARED_THREADS_LOADING'})
    const res = await this.service.fetchSharedThreads()
    if (!res.ok) {
      setTimeout(() => this.dispatch({type: 'SHARED_THREADS_LOADING_ERROR', message: res.error}), 100)
      return null
    }
    setTimeout(() => this.dispatch({type: 'SHARED_THREADS_LOADED'}), 100)

    return res.payload
  }

  async fetchLatestThread(threadId?: string): Promise<CopilotChatThread | null> {
    const res = await this.service.fetchLatestThread(threadId)
    if (!res.ok) {
      return null
    }

    if (res.payload) {
      this.dispatch({type: 'LATEST_THREAD_LOADED', latestThread: res.payload})
    }
    return res.payload
  }

  async continueSharedThread(sharedID: string | null): Promise<CopilotChatDuplicate | null> {
    if (!sharedID) {
      this.dispatch({type: 'THREAD_CONTINUED_FAILED'})
      return null
    }

    this.dispatch({type: 'MESSAGES_UPDATED', state: 'loading'})

    const res = await this.service.continueSharedThread(sharedID)
    if (res.ok) {
      const {thread, messages} = res.payload
      this.dispatch({type: 'THREAD_CONTINUED', thread})
      this.dispatch({type: 'MESSAGES_UPDATED', state: 'loaded', messages})
      // Load traces for the new duplicated traces thread
    } else {
      return null
    }

    return res.payload
  }

  async unshareAllThreads() {
    const res = await this.service.unshareAllThreads()
    if (res.ok) {
      // Update threads in state to reflect unshared status
      const threads = Array.from(this.getChatState().threads.values())
      for (const thread of threads) {
        if (thread.sharedAt) {
          this.dispatch({
            type: 'THREAD_UPDATED',
            thread: {id: thread.id, sharedAt: undefined, sharedID: undefined},
          })
        }
      }
      return res
    } else {
      this.dispatch({
        type: 'ADD_AMBIENT_ERROR',
        message: res.error || 'Failed to unshare all threads',
      })
      return res
    }
  }

  /**
   * Finds a thread to show to the user in a new chat, or starts a new thread if none are found.
   * @param currentThread The current thread to show to the user.
   * @param expectedReference A reference the thread should be relevant to, if the default one doesn't reference this, create a new thread.
   */
  private async findOrStartNewThread(
    currentThread?: CopilotChatThread | null,
    expectedReference?: CopilotChatReference,
    forceNewThread?: boolean,
  ): Promise<CopilotChatThread | null> {
    let thread: CopilotChatThread | null = null

    if (currentThread) {
      thread = currentThread
    } else if (!forceNewThread) {
      const previouslySelectedThreadID = copilotLocalStorage.selectedThreadID || undefined
      thread = await this.fetchLatestThread(previouslySelectedThreadID)
    }

    // If the thread is associated with a space, we don't want to load this in assistive mode
    // Temporary until we figure out Spaces in assistive mode
    if (thread && (isThreadOlderThan4Hours(thread) || !!thread.customCopilotID)) thread = null

    if (thread && expectedReference) {
      const response = await this.service.listMessages(thread.id)
      if (response.ok) {
        const messages = response.payload.messages
        const len = messages?.length
        // Check for the last user message (len - 2) in the thread and see if any of its references match the the expected reference
        if (len >= 2 && !messages[len - 2]?.references?.find(ref => referencesAreEqual(ref, expectedReference))) {
          thread = null
        }
      }
    }

    await this.selectThread(thread, {includeThreads: false})

    return thread
  }

  private async systemPrompt(mode?: CopilotChatMode): Promise<string> {
    const res = await this.service.getSystemPrompt(mode)
    return res.ok ? res.payload.prompt : ''
  }

  async fetchAgents(agentsPath: string): Promise<CopilotChatAgent[]> {
    const res = await this.service.listAgents(agentsPath)
    let agents: CopilotChatAgent[] = []
    if (res.ok) {
      agents = res.payload
      this.dispatch({type: 'SET_AGENTS', agents})
    }

    return agents
  }

  async fetchCopilotSpace(customCopilotID: CopilotSpaceId): Promise<CopilotSpacePayload> {
    const res = await this.service.fetchCopilotSpace(customCopilotID)
    let customCopilot = {} as CopilotSpacePayload
    if (res.ok) {
      customCopilot = res.payload
    }

    return customCopilot
  }

  async fetchCurrentRepo(repoID: number | string): Promise<CopilotChatRepo | undefined> {
    const res = await this.service.fetchRepo(repoID)
    if (res.ok) {
      this.dispatch({type: 'ADD_REFERENCE', reference: makeRepositoryReference(res.payload), source: 'currentRepo'})
      return res.payload
    }
    return undefined
  }

  async fetchImplicitContext(url: string, owner: string, repo: string, addAsVisibleReferences = true) {
    const res = await this.service.fetchImplicitContext(url, owner, repo)

    if (res.ok) {
      const context = !res.payload ? undefined : Array.isArray(res.payload) ? res.payload : [res.payload]
      this.dispatch({type: 'IMPLICIT_CONTEXT_UPDATED', context})

      // In immersive mode, add the implicit context as visible references
      // so they show up in the input area (matching the behavior when navigating to /copilot)
      const state = this.getChatState()
      if (addAsVisibleReferences && state.mode === 'immersive' && context && context.length > 0) {
        // Filter context based on feature flag - always include repo references,
        // but only include other references (PR, issue, discussion, etc.) if flag is enabled
        const refsToAdd = copilotFeatureFlags.immersiveEmbeddedImplicitReferences
          ? context
          : context.filter(ref => ref?.type === 'repository')

        if (refsToAdd.length > 0) {
          // Hydrate PR/issue/discussion references to get full data (title, state, draft, etc.)
          const hydratedRefs = await Promise.all(
            refsToAdd.map(async ref => {
              if (!ref) return ref
              if (ref.type === 'pull-request' || ref.type === 'issue' || ref.type === 'discussion') {
                const typeParam = ref.type === 'pull-request' ? 'pull_request' : ref.type
                const hydratedRes = await this.service.fetchReferenceDetails(owner, repo, typeParam, ref.number)
                if (hydratedRes.ok && hydratedRes.payload) {
                  return hydratedRes.payload
                }
              }
              return ref
            }),
          )

          for (const ref of hydratedRefs) {
            if (ref) {
              // If an equivalent reference already exists, replace it so that
              // identity-based implicit reference tracking stays consistent.
              const currentState = this.getChatState()
              const existingRef = currentState.currentReferences?.find(existing => referencesAreEqual(existing, ref))

              if (existingRef) {
                this.replaceReference(existingRef, ref)
              } else {
                this.addReference(ref, 'implicit-context', {implicit: true})
              }
            }
          }
        }
      }

      // Generate suggestions based on the updated implicit context.
      // This ensures suggestions are refreshed even during soft navigation between pages,
      // where the use-chat.ts hook might not be triggered.
      if (context && context.length > 0 && context[0] !== undefined) {
        this.generateSuggestions(context[0])
      }
    } else {
      return undefined
    }
  }

  clearCurrentTopic = () => {
    this.dispatch({type: 'CURRENT_TOPIC_UPDATED', topic: undefined, state: 'loaded'})
  }

  showTopicPicker = (value = true) => {
    this.dispatch({type: 'SHOW_TOPIC_PICKER', show: value})
  }

  startEditingMessage = (messageId: string) => this.dispatch({type: 'START_EDITING_MESSAGE', messageId})

  cancelEditingMessage = () => this.dispatch({type: 'CANCEL_EDITING_MESSAGE'})

  private threadDataLoaded(
    threadId: string | null,
    messages: CopilotChatMessage[],
    references: CopilotChatReference[],
  ) {
    this.dispatch({
      type: 'MESSAGES_UPDATED',
      messages,
      state: 'loaded',
    })

    this.dispatch({
      type: 'REFERENCES_LOADED',
      references,
    })
  }

  dismissEditorUpsellBanner() {
    const data = new FormData()
    data.set('copilot_editor_upsell_banner_dismissed', 'true')
    void verifiedFetch('/github-copilot/preferences', {method: 'PUT', body: data})

    this.dispatch({type: 'DISMISS_EDITOR_UPSELL_BANNER'})
  }

  // This method is only meant to be called when message was determined to be absent.
  tryInferMessage(references: CopilotChatReference[]): [boolean, string?] {
    if (references) {
      const imageRef = references.find(ref => ref.type === 'image')
      if (imageRef) {
        return [true, 'Describe this image']
      }
    }

    return [false, undefined]
  }

  setWrapCodeLines(value: boolean) {
    this.dispatch({type: 'SET_WRAP_CODE_LINES', value})
    copilotLocalStorage.setWrapCodeLines(value)
  }

  clearDefaultRecipient() {
    this.dispatch({type: 'CLEAR_DEFAULT_RECIPIENT'})
  }

  private completeTiming() {
    return {...this.timings, endTime: Date.now()}
  }

  /**
   * Generates a unique key for a custom copilot based on its ID.
   * This is used to manage pending threads for different custom copilots.
   * @param customCopilotId - The ID of the custom copilot, or null for the default copilot
   * @returns A string key representing the custom copilot
   */
  private getCustomCopilotKey(customCopilotId?: CopilotSpaceId | null): string {
    return customCopilotId ? `${customCopilotId.owner}:${customCopilotId.id}` : 'default'
  }

  /**
   * Retrieves a thread by its ID
   * @param threadId - The ID of the thread to retrieve
   * @returns The thread with the specified ID, or null if not found
   */
  getThreadById(threadId: string | null): CopilotChatThread | null {
    if (!threadId) return null

    const state = this.getChatState()
    return state.threads.get(threadId) || null
  }
}

function payloadIsAttachToThread(payload: CopilotChatEventPayload) {
  return (
    payloadHasIntent(payload, [CopilotChatIntents.conversation]) && 'attachThread' in payload && payload.attachThread
  )
}

function payloadIsNewThread(payload: CopilotChatEventPayload) {
  return payloadHasIntent(payload, [CopilotChatIntents.conversation]) && 'newThread' in payload && payload.newThread
}

function payloadIsIcebreaker(payload: CopilotChatEventPayload) {
  return (
    payloadHasIntent(payload, [CopilotChatIntents.explain, CopilotChatIntents.suggest]) ||
    (payloadHasIntent(payload, [CopilotChatIntents.conversation]) && payloadHasContent(payload))
  )
}

function payloadHasContent(payload: CopilotChatEventPayload): payload is CopilotChatEventPayload & {content: string} {
  return 'content' in payload && typeof payload.content == 'string'
}

function payloadHasIntent<const Intent extends CopilotChatIntentsType>(
  payload: CopilotChatEventPayload,
  intents: readonly Intent[],
): payload is Extract<typeof payload, {intent: Intent}> {
  const set = new Set<string>(intents)
  return set.has(payload.intent)
}

function functionIsSupported(name: string): boolean {
  return SUPPORTED_FUNCTIONS.includes(name)
}

function makeBasicError(message: string): ChatError {
  return {isError: true, message, type: 'basic', retryable: true}
}

function makeBillingNotConfiguredError(): ChatError {
  const message = (
    <>
      You have Copilot licenses from multiple organizations or enterprises. To use premium requests, please select a
      billing entity in your <a href={COPILOT_BILLING_SETTINGS_URL}>Copilot billing settings</a>.
    </>
  )
  return {isError: true, message, type: 'basic', retryable: false}
}

function makeNonRetryableError(message: string, type?: 'filtered'): ChatError {
  return {isError: true, message, type: type || 'basic', retryable: false}
}

function setCopilotButtonAriaExpanded(entryPointId: string, ariaExpanded?: boolean) {
  const copilotButton = document.getElementById(entryPointId)
  // If it is currently collapsed, we are expanding the chat
  copilotButton?.setAttribute('aria-expanded', ariaExpanded ? 'true' : 'false')
}

/**
 * Used to abort any active downloads when references are dropped.
 * @param removedReferences - references that were removed from the current references
 */
function abortInProcessImageDownloads(removedReferences: CopilotChatReference[]) {
  for (const ref of removedReferences) {
    if (ref.type === 'image') {
      const attachment = ref.attachment
      if (attachment instanceof UploadableFileAttachment) {
        attachment.abortController.abort('Reference removed before upload completed')
      }
    }
  }
}
