import {useState, useId} from 'react'
import {Dialog} from '@primer/react/experimental'
import {ChevronDownIcon, ChevronRightIcon, LawIcon} from '@primer/octicons-react'
import {GitHubAvatar} from '@github-ui/github-avatar'
import {ownerAvatarPath} from '@github-ui/paths'
import type {CodeInsightsInfo} from '../../../../types/code-insights-metadata'
import {AVATAR_FALLBACK_COLORS} from '../../../../utils/constants'
import styles from './CodeInsightsDialog.module.css'

export interface CodeInsightsDialogProps {
  isOpen: boolean
  onClose: () => void
  insights: CodeInsightsInfo
}

export function CodeInsightsDialog({isOpen, onClose, insights}: CodeInsightsDialogProps) {
  const [isCodeMatchExpanded, setIsCodeMatchExpanded] = useState(true)
  const listId = useId()

  const citationsCount = insights.publicCodeReferences?.length ?? 0

  if (!isOpen) {
    return null
  }

  return (
    <Dialog
      title="Code insights"
      subtitle={<span className={styles.dialogSubtitle}>Find matches across our platform.</span>}
      onClose={onClose}
      width="large"
    >
      <div>
        {/* Code matches section */}
        {citationsCount > 0 && (
          <div className={styles.section}>
            {/* Clickable header row */}
            <button
              type="button"
              className={styles.sectionHeader}
              onClick={() => setIsCodeMatchExpanded(!isCodeMatchExpanded)}
              aria-expanded={isCodeMatchExpanded}
              aria-controls={listId}
              aria-label={isCodeMatchExpanded ? 'Collapse section' : 'Expand section'}
            >
              <span className={styles.chevronIcon}>
                {isCodeMatchExpanded ? (
                  <ChevronDownIcon size={16} aria-hidden="true" />
                ) : (
                  <ChevronRightIcon size={16} aria-hidden="true" />
                )}
              </span>
              <LawIcon size={16} className={styles.sectionIcon} aria-hidden="true" />
              <span className={styles.sectionTitle}>
                {citationsCount === 1
                  ? '1 similar code snippet found'
                  : `${citationsCount} similar code snippets found`}
              </span>
            </button>

            {/* Expanded content */}
            {isCodeMatchExpanded && (
              <div className={styles.expandedContent}>
                <div className={styles.connectorLine} aria-hidden="true" />
                <ul className={styles.matchList} id={listId}>
                  {insights.publicCodeReferences?.map(match => (
                    <li key={match.annotationId} className={styles.matchItem}>
                      <a
                        href={match.sourceURL || undefined}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={styles.matchLink}
                      >
                        <RepositoryAvatar nwo={match.nwo} />
                        <span className={styles.repositoryName}>{match.nwo ?? match.sourceURL}</span>
                        <span className={styles.licenseBadge}>
                          {match.license && match.license !== 'NOASSERTION' ? match.license : 'No license'}
                        </span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
        {citationsCount === 0 && <div className={styles.emptyState}>No code matches found.</div>}
      </div>
    </Dialog>
  )
}

/**
 * Avatar component for repositories using the owner's avatar.
 * Falls back to a deterministic colored placeholder if nwo is not available or image fails to load.
 */
function RepositoryAvatar({nwo}: {nwo?: string}) {
  const [imageError, setImageError] = useState(false)

  // Deterministic color based on nwo string
  const colorIndex =
    (nwo ?? '').split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % AVATAR_FALLBACK_COLORS.length
  const bgColor = AVATAR_FALLBACK_COLORS[colorIndex]
  // Try to show GitHubAvatar if we have an owner and no image error
  if (nwo && !imageError) {
    const [owner] = nwo.split('/')
    if (owner) {
      return (
        <GitHubAvatar
          src={ownerAvatarPath({owner})}
          size={20}
          alt={nwo}
          className={styles.repositoryAvatar}
          onError={() => setImageError(true)}
        />
      )
    }
  }

  // Fallback: deterministic colored placeholder with initial (decorative, repo name is already in link text)
  return (
    <div className={styles.repositoryAvatarFallback} style={{backgroundColor: bgColor}} aria-hidden="true">
      <span className={styles.avatarInitial}>{(nwo ?? '?').charAt(0).toUpperCase()}</span>
    </div>
  )
}
