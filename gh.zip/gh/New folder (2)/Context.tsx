import {createContext, use, useMemo} from 'react'
import type {Session} from '../../types/session'

type SessionLogsVariant = 'default' | 'mission-control' | 'chat'

/**
 * context to optionally allow consumers of SessionLogs to modify its behavior based on the variant
 * without Provider it returns default
 */
type Context = {
  variant: SessionLogsVariant
  onToolExpand: null | ((expand: boolean) => void)
  session: Session | null
  sessionNwo: string | null
}

export const SessionLogsContext = createContext<Context>({
  variant: 'default',
  onToolExpand: null,
  session: null,
  sessionNwo: null,
})

export function useSessionLogsContext() {
  return use(SessionLogsContext)
}

type SessionLogsProviderProps = {
  variant: SessionLogsVariant
  children: React.ReactNode
  onToolExpand?: Context['onToolExpand']
  session?: Session | null
  sessionNwo?: string | null
}

export function SessionLogsProvider({
  variant,
  onToolExpand = null,
  session = null,
  sessionNwo = null,
  children,
}: SessionLogsProviderProps) {
  return (
    <SessionLogsContext
      value={useMemo(
        () => ({variant, onToolExpand, session, sessionNwo}),
        [variant, onToolExpand, session, sessionNwo],
      )}
    >
      {children}
    </SessionLogsContext>
  )
}
