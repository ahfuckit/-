import type {IconProps} from '@primer/octicons-react'
import type React from 'react'

export type CircleOcticonProps = {
  as?: React.ElementType
  size?: number
  icon: React.ComponentType<React.PropsWithChildren<{size?: IconProps['size']}>>
  bg?: string
  'aria-label'?: string
  style?: React.CSSProperties
  className?: string
}
function CircleOcticon(props: CircleOcticonProps) {
  const {size = 32, as, icon: IconComponent, bg, 'aria-label': ariaLabel, style, className, ...rest} = props
  return (
    <div
      style={{
        backgroundColor: bg,
        overflow: 'hidden',
        borderWidth: 0,
        borderRadius: '50%',
        borderStyle: 'solid',
        borderColor: 'var(--borderColor-default)',
        width: size,
        height: size,
      }}
    >
      <div
        style={{
          display: 'flex',
          width: size,
          height: size,
          alignItems: 'center',
          justifyContent: 'center',
          ...style,
        }}
        className={className}
        {...rest}
      >
        <IconComponent size={size} aria-label={ariaLabel} />
      </div>
    </div>
  )
}

export default CircleOcticon
