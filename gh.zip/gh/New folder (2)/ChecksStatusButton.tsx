import {ChecksStatusBadge} from '@github-ui/commit-checks-status'
import {useMergeabilityLiveUpdates} from '@github-ui/mergebox'
import {useEffect, useMemo} from 'react'

import {useLiveCommitChecksStatus} from '../../hooks/use-live-commit-checks-status'
import styles from './PullRequestOverviewPreview.module.css'

interface ChecksStatusButtonProps {
  headSha: string
  repositoryNwo: string
  commitAliveChannel?: string
}

export function ChecksStatusButton({headSha, repositoryNwo, commitAliveChannel}: ChecksStatusButtonProps) {
  const [ownerLogin = '', name = ''] = repositoryNwo?.split('/') ?? []
  const repo = useMemo(() => ({ownerLogin, name}), [ownerLogin, name])

  const [checksDetails, fetchChecksDetails] = useLiveCommitChecksStatus(headSha, repo)

  // Set up live updates for checks status
  const channels = useMemo(
    () => ({
      stateChannel: commitAliveChannel,
      deployedChannel: null,
      reviewStateChannel: null,
      workflowsChannel: null,
      mergeQueueChannel: null,
      headRefChannel: null,
      baseRefChannel: null,
      gitMergeStateChannel: null,
      pullRequestChannel: null,
    }),
    [commitAliveChannel],
  )

  useMergeabilityLiveUpdates({
    channels,
    refetchQuery: fetchChecksDetails,
  })

  // Fetch initial data when component mounts
  useEffect(() => {
    if (headSha && repositoryNwo) {
      fetchChecksDetails()
    }
  }, [headSha, repositoryNwo, fetchChecksDetails])

  // Don't render if no required data or no checks data loaded yet
  if (!headSha || !repositoryNwo || !checksDetails || checksDetails.checkRuns.length === 0) {
    return null
  }

  const getCheckCountsText = () => {
    if (!checksDetails?.checkRuns) return ''

    const totalChecks = checksDetails.checkRuns.length
    const successfulChecks = checksDetails.checkRuns.filter(run => run.state === 'success').length

    return `${successfulChecks}/${totalChecks}`
  }

  const mapHeaderStateToStatusRollup = (headerState: string) => {
    switch (headerState) {
      case 'SUCCEEDED':
        return 'success'
      case 'FAILED':
        return 'failure'
      case 'PENDING':
        return 'pending'
      case 'UNSUCCESSFUL':
        return 'failure'
      default:
        return 'pending'
    }
  }

  return (
    <span className={styles.checksButton}>
      <ChecksStatusBadge
        statusRollup={mapHeaderStateToStatusRollup(checksDetails?.checksHeaderState || '')}
        combinedStatus={checksDetails}
        onWillOpenPopup={fetchChecksDetails}
        size="small"
        variant="default"
        descriptionText={getCheckCountsText()}
      />
    </span>
  )
}
