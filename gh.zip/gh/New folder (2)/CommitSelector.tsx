import {
  SelectBody,
  SelectContainer,
  SelectFooter,
  type SelectItemProps,
  type Items,
  type SimpleSelectDialogProps,
} from '@github-ui/simple-select'
import {ActionList, Button, type ButtonProps} from '@primer/react'
import {useImperativeHandle, useMemo, useRef, useState} from 'react'
import styles from './CommitSelector.module.css'

export interface CommitItemProps extends Omit<SelectItemProps, 'onSelect'> {
  /**
   * Defines if the item is selectable as single (instant selection) or multiple
   */
  selectionVariant: 'single' | 'multiple'
  /**
   * Used to group multiple items
   */
  groupId?: number
  /**
   * Heading for group of items, requires valid groupId to be set
   */
  groupTitle?: string
  /**
   * Optional callback for when this specific item is selected
   * If not provided, the CommitSelector's onSingleSelect or onMultiSelect will be used
   */
  onSelect?: (selectedItem: Items) => void
}

export type CommitSelectorProps = {
  /**
   * Props to pass to the trigger button, including size, leadingVisual, trailingAction, etc.
   * Note: onClick and ref are handled internally and will be overridden
   */
  buttonProps?: Omit<ButtonProps, 'onClick' | 'ref' | 'children'>
  /**
   * Label for the trigger button
   */
  anchorLabel?: string
  /**
   * Array of items to display in the selector
   */
  items: CommitItemProps[]
  /**
   * Provide a custom onMultiSelect handler to manage multi select state externally
   * @param selectedItem The item that was just selected
   */
  onMultiSelect?: (selectedItem: Items) => void
  /**
   * Provide a custom onSingleSelect handler to manage single select state externally
   * @param selectedItem The item that was just selected
   */
  onSingleSelect?: (selectedItem: Items) => void
  /**
   * Callback for when the Apply button is clicked in multi-select mode
   * @param selectedItems The currently selected items
   */
  onApply?: (selectedItems: CommitItemProps[]) => void
  /**
   * Callback for when the Clear/Cancel button is clicked in multi-select mode
   */
  onCancel?: () => void
  /**
   * The variant of the select container to use
   * - `overlay`: An overlay that is positioned relative to the trigger button.
   * - `modal`: A fullscreen modal dialog.
   * @default 'overlay'
   */
  variant?: 'overlay' | 'modal'
  /**
   * Props to pass to the underlying SimpleSelect dialog when using variant `modal`
   */
  dialogProps?: SimpleSelectDialogProps
  /**
   *  Title for the select container, provides a title for both variants
   */
  title?: string
  /**
   * The ref to the CommitSelector component
   */
  ref?: React.Ref<CommitSelectorHandle>
  /**
   * Controls whether the CommitSelector is open.
   * When provided, the component operates in controlled mode and `onOpenChange` should be used to update this value.
   * When omitted, the component manages its own open state.
   */
  open?: boolean
  /**
   * Callback fired when the open state should change.
   * Required for controlled mode to update the `open` prop.
   * @param open The new open state
   */
  onOpenChange?: (open: boolean) => void
}

export interface CommitSelectorHandle {
  /**
   * Programmatically open the selector dialog
   */
  open: () => void
}

type SelectorItems = {
  single: CommitItemProps[]
  multiple: CommitItemProps[]
}

export function CommitSelector({
  ref,
  items,
  onMultiSelect,
  onSingleSelect,
  onApply,
  onCancel,
  buttonProps,
  anchorLabel,
  variant = 'overlay',
  title,
  dialogProps,
  open: controlledOpen,
  onOpenChange,
}: CommitSelectorProps) {
  const triggerRef = useRef<HTMLButtonElement>(null)
  const [internalOpen, setInternalOpen] = useState(false)
  const [savedItems, setSavedItems] = useState<SelectorItems>()

  const isControlled = controlledOpen !== undefined
  const open = isControlled ? controlledOpen : internalOpen

  const setOpen = (newOpen: boolean) => {
    if (!isControlled) {
      setInternalOpen(newOpen)
    }
    onOpenChange?.(newOpen)
  }

  useImperativeHandle(ref, () => ({
    open: () => setOpen(true),
  }))

  const selectionItems = useMemo(
    () =>
      items.reduce(
        (acc, item) => {
          if (item.selectionVariant === 'single') return {...acc, single: [...acc.single, item]}
          if (item.selectionVariant === 'multiple') return {...acc, multiple: [...acc.multiple, item]}
          return acc
        },
        {single: [], multiple: []} as SelectorItems,
      ),
    [items],
  )

  const [commitItems, setCommitItems] = useState(() => selectionItems)

  const handleSingleSelect = (selectedItem: {id: string}) => {
    const updatedSingleItems =
      commitItems?.single.map(item => {
        if (item.id === selectedItem.id) return {...item, selected: !item.selected}
        if (item.selected) return {...item, selected: false}
        return item
      }) || []

    setCommitItems({single: updatedSingleItems, multiple: commitItems?.multiple || []})
  }

  const handleMultiSelect = (selectedItem: {id: string}) => {
    const updatedMultiItems =
      commitItems?.multiple.map(item => (item.id === selectedItem.id ? {...item, selected: !item.selected} : item)) ||
      []

    setCommitItems({single: commitItems?.single || [], multiple: updatedMultiItems})
  }

  const commitsSelected = useMemo(
    () =>
      !onMultiSelect
        ? commitItems?.multiple.filter(item => item.selected).length || 0
        : selectionItems?.multiple.filter(item => item.selected).length,
    [commitItems, selectionItems, onMultiSelect],
  )

  const selectedSavedItems = savedItems?.multiple.filter(item => item.selected).length || 0
  const label =
    !commitsSelected || selectedSavedItems === 0
      ? 'Select commits'
      : `${selectedSavedItems} commit${selectedSavedItems > 1 ? 's' : ''} selected`

  const saveSelection = () => {
    setSavedItems(commitItems)
    setOpen(false)

    // Call onApply callback if provided
    if (onApply) {
      const selectedItems = commitItems?.multiple.filter(item => item.selected) || []
      onApply(selectedItems)
    }
  }

  const cancelSelection = () => {
    setCommitItems(selectionItems)
    setSavedItems(selectionItems)

    // Call onCancel callback if provided
    onCancel?.()
  }

  return (
    <>
      <Button ref={triggerRef} onClick={() => setOpen(!open)} {...buttonProps}>
        {anchorLabel || label}
      </Button>
      <SelectContainer
        open={open}
        anchorRef={triggerRef}
        headingId="select-label"
        onClose={() => {
          setCommitItems({single: commitItems?.single || [], multiple: savedItems?.multiple || selectionItems.multiple})
          setOpen(false)
        }}
        variant={variant}
        focusZoneSettings={{
          focusOutBehavior: 'wrap',
          focusableElementFilter: element => element.tagName !== 'BUTTON',
        }}
        title={title}
        dialogProps={dialogProps}
        selectSave={saveSelection}
        selectCancel={() => {
          cancelSelection()
          setOpen(false)
        }}
      >
        <div className={styles.CommitSelectorWrapper}>
          <div className={styles.CommitSelectorContainer}>
            <ActionList role="listbox" selectionVariant="single" aria-label="Selection">
              <CommitSelectorBody
                selectionVariant="single"
                items={!onSingleSelect ? commitItems?.single || [] : selectionItems.single}
                onSelect={selectItems => {
                  if (onSingleSelect) {
                    onSingleSelect(selectItems)
                  } else {
                    handleSingleSelect(selectItems)
                  }

                  if (variant !== 'modal') setOpen(false)
                }}
                showGroupHeading={false}
              />
              <CommitSelectorBody
                selectionVariant="multiple"
                items={!onMultiSelect ? commitItems?.multiple || [] : selectionItems.multiple}
                onSelect={onMultiSelect ?? handleMultiSelect}
              />
            </ActionList>
          </div>
          {commitsSelected && variant !== 'modal' ? (
            <SelectFooter
              footerButtons={[
                {
                  content: 'Apply',
                  onClick: saveSelection,
                  action: 'save',
                },
                {
                  content: 'Clear',
                  onClick: cancelSelection,
                  action: 'cancel',
                },
              ]}
            />
          ) : null}
        </div>
      </SelectContainer>
    </>
  )
}

export function CommitSelectorBody({
  items,
  onSelect,
  selectionVariant,
  showGroupHeading = true,
}: {
  items: CommitItemProps[]
  onSelect?: (selectedItem: Items) => void
  selectionVariant: 'single' | 'multiple'
  showGroupHeading?: boolean
}) {
  return (
    <SelectBody
      selectionVariant={selectionVariant}
      items={items}
      showGroupHeading={showGroupHeading}
      onSelect={onSelect}
    />
  )
}
