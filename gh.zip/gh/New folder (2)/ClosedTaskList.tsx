import {ListBlock} from '@github-ui/pacer/ListBlock'
import {AlertIcon} from '@primer/octicons-react'
import type {HydratedTask} from '../../types/task'
import {TaskListItem} from './TaskListItem'
import type {TaskListProps} from '../../types/task-list'

interface ClosedTaskListProps extends TaskListProps {
  tasks: HydratedTask[]
}

export function ClosedTaskList({tasks, isError}: ClosedTaskListProps) {
  return (
    <ListBlock.List id="tasks-list" aria-labelledby="closed-tab">
      {isError ? (
        <ListBlock.EmptyState>
          <AlertIcon size={24} />
          <p>Sorry, something went wrong</p>
        </ListBlock.EmptyState>
      ) : tasks.length === 0 ? (
        <ListBlock.EmptyState>
          <p>No closed tasks yet.</p>
        </ListBlock.EmptyState>
      ) : (
        tasks.map(task => {
          if (!task.pull) return null

          return (
            <TaskListItem
              key={task.pull.id}
              state={task.latest_session_state}
              startedAt={task.latest_session_updated_at}
              revisionCount={task.session_count - 1}
              prState={task.pull.state}
              prUrl={task.pull.url}
              prTitle={task.pull.title}
              prNwo={task.pull.repository_nwo}
              prNumber={task.pull.number}
              prGlobalId={task.pull.global_relay_id}
              prInMergeQueue={task.pull.inMergeQueue ?? false}
              prDiffSummary={task.pull.pr_diff_summary}
            />
          )
        })
      )}
    </ListBlock.List>
  )
}
