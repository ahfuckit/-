import {Fragment} from 'react'
import {ActionList} from '@primer/react'
import {AssigneeVisual} from './AssigneeVisual'
import {hovercardAttributesForActor} from '@github-ui/hovercards'
import {ProfileReference} from '@github-ui/profile-reference'
import {isFeatureEnabled} from '@github-ui/feature-flags'
import {useAnalytics} from '@github-ui/use-analytics'

import styles from './Assignees.module.css'

export type Assignee = {
  login: string
  name?: string | null
  avatarUrl: string
  profileResourcePath?: string | null | undefined
  id: string
  displayName: string
  isCopilot: boolean
  isAgent: boolean
  assignedAgents?: Assignee[]
}
export type AssigneesProps = {
  assignees: Assignee[]
  testId?: string
}

export function Assignees({assignees, testId}: AssigneesProps) {
  const {sendAnalyticsEvent} = useAnalytics()
  const issue_cca_visualization = isFeatureEnabled('issue_cca_visualization')

  const handleClick = () => {
    sendAnalyticsEvent('analytics.click', 'ISSUE_SIDEBAR_ASSIGNEE_CLICK')
  }

  const handleContextMenu = () => {
    sendAnalyticsEvent('analytics.click', 'ISSUE_SIDEBAR_ASSIGNEE_RIGHT_CLICK')
  }

  return (
    <ActionList variant={'full'} className={styles.assigneesList}>
      {[...assignees]
        .sort(sortByLogin)
        .map(({login, name, avatarUrl, profileResourcePath, id, isCopilot, displayName, isAgent, assignedAgents}) => {
          const hasNestedAgents = issue_cca_visualization && assignedAgents && assignedAgents.length > 0

          return (
            <Fragment key={id}>
              <ActionList.LinkItem
                href={profileResourcePath ?? undefined}
                target="_blank"
                onClick={handleClick}
                onContextMenu={handleContextMenu}
                {...hovercardAttributesForActor(login, {isCopilot, isAgent})}
              >
                <ActionList.LeadingVisual>
                  <AssigneeVisual login={login} id={id} avatarUrl={avatarUrl} isCopilot={isCopilot} />
                </ActionList.LeadingVisual>
                <div data-testid={testId} className={styles.assigneeNameLabel}>
                  <ProfileReference login={displayName} profileName={name} isAgent={isAgent} />
                </div>
              </ActionList.LinkItem>

              {hasNestedAgents && (
                <li>
                  <ActionList aria-label={`Agents assigned by ${displayName}`}>
                    {assignedAgents.map((agent, agentIndex) => {
                      const isLastAgent = agentIndex === assignedAgents.length - 1

                      return (
                        <ActionList.LinkItem
                          key={agent.id}
                          href={agent.profileResourcePath ?? undefined}
                          target="_blank"
                          onClick={handleClick}
                          onContextMenu={handleContextMenu}
                          className={styles.nestedAgentItem}
                          data-testid="nested-agent-item"
                          {...hovercardAttributesForActor(agent.login, {
                            isCopilot: agent.isCopilot,
                            isAgent: agent.isAgent,
                          })}
                        >
                          <ActionList.LeadingVisual>
                            <span className={styles.nestedAgentVisual}>
                              <span
                                className={`${styles.connector} ${isLastAgent ? styles.connectorLast : styles.connectorMiddle}`}
                                aria-hidden="true"
                              />
                              <AssigneeVisual
                                login={agent.login}
                                id={agent.id}
                                avatarUrl={agent.avatarUrl}
                                isCopilot={agent.isCopilot}
                              />
                            </span>
                          </ActionList.LeadingVisual>
                          <div className={styles.assigneeNameLabel}>
                            <ProfileReference
                              login={agent.displayName}
                              profileName={agent.name}
                              isAgent={agent.isAgent}
                            />
                          </div>
                        </ActionList.LinkItem>
                      )
                    })}
                  </ActionList>
                </li>
              )}
            </Fragment>
          )
        })}
    </ActionList>
  )
}

function sortByLogin(a: Pick<Assignee, 'login'>, b: Pick<Assignee, 'login'>) {
  return a.login === b.login ? 0 : a.login > b.login ? 1 : -1
}
