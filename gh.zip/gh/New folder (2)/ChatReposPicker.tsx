import {sendEvent} from '@github-ui/hydro-analytics'
import {
  fetchSearchRepositories,
  fetchTopRepositories,
  type RepositoryPickerRepository,
  type RepositoryPickerRepositoryLight,
} from '@github-ui/item-picker/RepositoryPicker'
import {getRepositorySearchQuery} from '@github-ui/item-picker/utils/get-repository-search-query'
import {ReposSelector} from '@github-ui/repos-selector'
import {RepoCloneIcon, RepoIcon, RepoLockedIcon} from '@primer/octicons-react'
import {useCallback, useMemo, useRef, useState} from 'react'
import {useRelayEnvironment} from 'react-relay'

import {useOverlayDirection} from '../contexts/OverlayDirectionContext'
import {cleanupSearchQuery} from '../hooks/use-repository-items'
import {uniqueBy} from '../utils/array'
import {makeRepositoryReference} from '../utils/copilot-chat-helpers'
import type {TopicItem} from '../utils/copilot-chat-types'
import {copilotFeatureFlags} from '../utils/copilot-feature-flags'
import {useChatStateValues} from '../utils/CopilotChatContext'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import {getRepositoryFromOrgSearchQuery} from '../utils/custom-copilots-helpers'
import {COPILOT_CHAT_MENU_PORTAL_ROOT} from './PortalContainerUtils'

const REPO_RESULTS_LIMIT = 10

// Minimal repository type for chat dropdown - only includes fields needed for display and selection
interface ChatDropdownRepository {
  id: number
  name: string // nameWithOwner format (owner/repo)
  enabled?: boolean
  private?: boolean
}

interface ChatReposPickerProps {
  showIconOnly?: boolean
  tooltipDirection?: 'n' | 's'
}

/**
 * ChatReposPicker - Repository selection component for Copilot Chat
 */
export function ChatReposPicker({showIconOnly = false, tooltipDirection}: ChatReposPickerProps) {
  const manager = useChatManager()
  const preferredOverlaySide = useOverlayDirection()
  const relayEnvironment = useRelayEnvironment()
  // Cache for top repositories to avoid re-fetching
  const topReposCacheRef = useRef<ChatDropdownRepository[] | undefined>(undefined)
  const {currentReferences, currentRepository, currentUserLogin, mode} = useChatStateValues(
    'currentReferences',
    'currentRepository',
    'currentUserLogin',
    'mode',
  )

  // Check if we should use REST instead of Relay
  const useRest = copilotFeatureFlags.deprecateRelay

  // Snapshot of repos that should appear at the top when there's no search query.
  // Updated when: dialog opens, or user clears search after searching.
  const [pinnedReposSnapshot, setPinnedReposSnapshot] = useState<ChatDropdownRepository[]>([])

  // Repos that were recently unchecked but should still appear at top until user types or closes dialog.
  const [recentlyUncheckedRepos, setRecentlyUncheckedRepos] = useState<ChatDropdownRepository[]>([])

  // Track previous query to detect when search is cleared
  const previousQueryRef = useRef<string>('')

  // Snapshot of selected repos when search query changed - used to determine which repos to pin at top during search
  // This prevents newly selected repos from immediately jumping to the top while typing
  const [selectedReposAtQueryChange, setSelectedReposAtQueryChange] = useState<ChatDropdownRepository[]>([])

  // Get currently selected repository references
  const selectedRepoReferences = currentReferences.filter(r => r.type === 'repository')

  // Map selected references to ChatDropdownRepository format
  const selectedRepos = useMemo(() => {
    const repos: ChatDropdownRepository[] = []
    for (const ref of selectedRepoReferences) {
      repos.push({
        id: ref.id,
        name: `${ref.ownerLogin}/${ref.name}`,
        enabled: true,
        private: ref.visibility !== 'public',
      })
    }
    return repos
  }, [selectedRepoReferences])

  const setPreviouslySelectedRepos = useCallback(
    (query: string) => {
      // Check query to make sure previously selected repos stay at the top...
      // Detect when user starts typing after having no query (clears recently unchecked)
      const previousQuery = previousQueryRef.current
      previousQueryRef.current = query

      if (query.trim() && !previousQuery.trim()) {
        setRecentlyUncheckedRepos([])
        // Snapshot selected repos when starting to type - these will be pinned at top during this search
        setSelectedReposAtQueryChange(selectedRepos)
      }

      // Update snapshot when query changes (but not on every keystroke within the same search session)
      if (query.trim() && previousQuery.trim() && query.trim() !== previousQuery.trim()) {
        setSelectedReposAtQueryChange(selectedRepos)
      }

      // Detect when search is cleared (update pinned snapshot)
      if (!query.trim() && previousQuery.trim()) {
        // Snapshot current selected repos + recently unchecked repos
        const combinedPinned = uniqueBy([...selectedRepos, ...recentlyUncheckedRepos], r => r.id)
        setPinnedReposSnapshot(combinedPinned)
        // Clear recently unchecked since they're now part of the snapshot
        setRecentlyUncheckedRepos([])
      }
    },
    [recentlyUncheckedRepos, selectedRepos],
  )

  // REST-based repository loader - backend handles all search logic
  const repositoryLoaderRest = useCallback(
    async (query: string): Promise<ChatDropdownRepository[]> => {
      setPreviouslySelectedRepos(query)

      // Ensure we have top repos cached
      if (!topReposCacheRef.current) {
        const topRepos = await manager.service.fetchTopRepositories(REPO_RESULTS_LIMIT, true, currentRepository?.id)
        topReposCacheRef.current = mapTopicItemsToDropdown(topRepos, currentRepository)
      }

      let results: ChatDropdownRepository[]

      // If no query, return pinned repos (from snapshot + recently unchecked) first, then top repositories
      // Note: We only use pinnedReposSnapshot, NOT selectedRepos, so newly selected repos don't immediately move to top
      if (!query.trim()) {
        // Combine pinned snapshot with recently unchecked repos (but NOT currently selected repos)
        const pinnedRepos = uniqueBy([...pinnedReposSnapshot, ...recentlyUncheckedRepos], r => r.id)
        results = prependPinnedRepos(topReposCacheRef.current ?? [], pinnedRepos)
      } else {
        // Search with query - backend handles all search logic
        const repos = await manager.service.fetchRepositoriesSearch(
          query.trim(),
          REPO_RESULTS_LIMIT,
          true,
          currentRepository?.id,
        )
        results = mapTopicItemsToDropdown(repos, currentRepository)
      }

      // When searching, prepend selected repos (from snapshot at query change) that match the query to keep them visible at top
      // Using the snapshot instead of live selectedRepos prevents newly selected items from immediately jumping to top
      if (query.trim()) {
        const lowerQuery = query.toLowerCase()
        const matchingSelectedRepos = selectedReposAtQueryChange.filter(r => r.name.toLowerCase().includes(lowerQuery))
        if (matchingSelectedRepos.length > 0) {
          results = prependMatchingSelectedRepos(results, matchingSelectedRepos)
        }
      }

      // Enforce limit
      return results.slice(0, REPO_RESULTS_LIMIT)
    },
    [
      setPreviouslySelectedRepos,
      manager.service,
      currentRepository,
      pinnedReposSnapshot,
      recentlyUncheckedRepos,
      selectedReposAtQueryChange,
    ],
  )

  // Relay-based repository loader (legacy)
  const repositoryLoaderRelay = useCallback(
    async (query: string): Promise<ChatDropdownRepository[]> => {
      setPreviouslySelectedRepos(query)

      // Ensure we have top repos cached (needed for sorting/filtering in all query paths)
      if (!topReposCacheRef.current) {
        const topRepos = await fetchTopRepositories(relayEnvironment, {first: REPO_RESULTS_LIMIT})
        topReposCacheRef.current = mapTopRepositoriesToDropdown(topRepos, currentRepository)
      }

      let results: ChatDropdownRepository[]

      // Extract owner from query if it contains "/" (e.g., "github/copilot" -> "github")
      const ownerLogin = query.includes('/') ? query.split('/')[0] : undefined

      // If no query, return pinned repos (from snapshot + recently unchecked) first, then top repositories
      // Note: We only use pinnedReposSnapshot, NOT selectedRepos, so newly selected repos don't immediately move to top
      if (!query.trim()) {
        // Combine pinned snapshot with recently unchecked repos (but NOT currently selected repos)
        const pinnedRepos = uniqueBy([...pinnedReposSnapshot, ...recentlyUncheckedRepos], r => r.id)
        results = prependPinnedRepos(topReposCacheRef.current ?? [], pinnedRepos)
      } else if (ownerLogin) {
        // Search within the specified owner's repositories
        // e.g., "github/" returns github org repos, "github/copilot" filters by name
        const {repositories} = await fetchSearchRepositories(relayEnvironment, {
          query: getRepositoryFromOrgSearchQuery(ownerLogin, query, true),
        })
        results = mapSearchRepositoriesToDropdownAndSort(repositories, topReposCacheRef.current)
      } else {
        // Filter top repos by query - prioritize user's frequently used repos
        const lowerQuery = query.toLowerCase()
        const matchingTopRepos = topReposCacheRef.current.filter(nwo => nwo.name.toLowerCase().includes(lowerQuery))

        // If we have enough matching top repos, no need to search
        if (matchingTopRepos.length >= REPO_RESULTS_LIMIT) {
          results = matchingTopRepos
        } else {
          const repoSearchTasks: Array<Promise<RepositoryPickerRepositoryLight[]>> = []

          // Check if query starts with current user's login - if so, search their repos first
          const {query: cleanedQuery, containsUserLogin} = cleanupSearchQuery(query, currentUserLogin)
          if (containsUserLogin && currentUserLogin) {
            // Search user's repos with cleaned query
            repoSearchTasks.push(
              (async () => {
                const {repositories} = await fetchSearchRepositories(relayEnvironment, {
                  query: getRepositoryFromOrgSearchQuery(currentUserLogin, cleanedQuery, true),
                })
                return repositories
              })(),
            )
          }

          // Search all repos with the original query
          repoSearchTasks.push(
            (async () => {
              const {repositories} = await fetchSearchRepositories(relayEnvironment, {
                query: getRepositorySearchQuery(query),
              })
              return repositories
            })(),
          )

          const searchResults = await Promise.all(repoSearchTasks)
          const allRepos = uniqueBy(searchResults.flat(), repo => repo.id)
          results = mergeReposWithTopRepoPriority(matchingTopRepos, allRepos)
        }
      }

      // When searching, prepend selected repos (from snapshot at query change) that match the query to keep them visible at top
      // Using the snapshot instead of live selectedRepos prevents newly selected items from immediately jumping to top
      if (query.trim()) {
        const lowerQuery = query.toLowerCase()
        const matchingSelectedRepos = selectedReposAtQueryChange.filter(r => r.name.toLowerCase().includes(lowerQuery))
        if (matchingSelectedRepos.length > 0) {
          results = prependMatchingSelectedRepos(results, matchingSelectedRepos)
        }
      }

      // Enforce limit
      return results.slice(0, REPO_RESULTS_LIMIT)
    },
    [
      setPreviouslySelectedRepos,
      relayEnvironment,
      currentRepository,
      pinnedReposSnapshot,
      recentlyUncheckedRepos,
      currentUserLogin,
      selectedReposAtQueryChange,
    ],
  )

  // Choose the appropriate repository loader based on feature flag
  const repositoryLoader = useRest ? repositoryLoaderRest : repositoryLoaderRelay

  // Handle repository selection changes
  const handleRepoSelect = useCallback(
    async (repos: ChatDropdownRepository[] | undefined) => {
      if (!repos) {
        // Clear all repository references - track them as recently unchecked
        const uncheckedRepos: ChatDropdownRepository[] = []
        for (const ref of selectedRepoReferences) {
          uncheckedRepos.push({
            id: ref.id,
            name: `${ref.ownerLogin}/${ref.name}`,
            enabled: true,
            private: ref.visibility !== 'public',
          })
          manager.removeReference(ref)
          sendEvent('dotcom_chat.activate', {
            target: 'ATTACHMENT_MENU_REPOSITORIES',
            action: 'removed',
            component: 'REPOSITORY_PICKER',
            mode,
          })
        }
        setRecentlyUncheckedRepos(prev => uniqueBy([...prev, ...uncheckedRepos], r => r.id))
        return
      }

      const newSelectedIds = new Set(repos.map(r => r.id))
      const newlyUnchecked: ChatDropdownRepository[] = []

      // Remove deselected repos and track them as recently unchecked
      for (const ref of selectedRepoReferences) {
        if (!newSelectedIds.has(ref.id)) {
          newlyUnchecked.push({
            id: ref.id,
            name: `${ref.ownerLogin}/${ref.name}`,
            enabled: true,
            private: ref.visibility !== 'public',
          })
          manager.removeReference(ref)
          sendEvent('dotcom_chat.activate', {
            target: 'ATTACHMENT_MENU_REPOSITORIES',
            action: 'removed',
            component: 'REPOSITORY_PICKER',
            mode,
          })
        }
      }

      // Update recently unchecked repos
      if (newlyUnchecked.length > 0) {
        setRecentlyUncheckedRepos(prev => uniqueBy([...prev, ...newlyUnchecked], r => r.id))
      }

      // Remove from recently unchecked if re-selected
      const reSelectedIds = repos.filter(r => !selectedRepoReferences.some(ref => ref.id === r.id)).map(r => r.id)
      if (reSelectedIds.length > 0) {
        setRecentlyUncheckedRepos(prev => prev.filter(r => !reSelectedIds.includes(r.id)))
      }

      // Add newly selected repos
      for (const repo of repos) {
        const alreadySelected = selectedRepoReferences.some(ref => ref.id === repo.id)
        if (!alreadySelected && repo.id != null) {
          const repoResponse = await manager.service.fetchRepo(repo.id)
          if (repoResponse.ok) {
            const reference = makeRepositoryReference(repoResponse.payload)
            manager.addReference(reference, 'repoMenu')
            sendEvent('dotcom_chat.activate', {
              target: 'ATTACHMENT_MENU_REPOSITORIES',
              action: 'selected',
              component: 'REPOSITORY_PICKER',
              mode,
            })
          }
        }
      }
    },
    [selectedRepoReferences, manager, mode],
  )

  const buttonText = useMemo(() => {
    const count = selectedRepos.length
    if (count === 0) return 'All repositories'
    if (count === 1) return selectedRepos[0]?.name || 'Select repositories'
    return `${count} repositories`
  }, [selectedRepos])

  const buttonIcon = useMemo(() => {
    const count = selectedRepos.length
    if (count === 0) return RepoIcon
    if (count === 1) return selectedRepos?.[0]?.private ? RepoLockedIcon : RepoIcon

    return RepoCloneIcon
  }, [selectedRepos])

  const handleOpen = useCallback(() => {
    // Reset previous query tracking when dialog opens
    previousQueryRef.current = ''

    // Snapshot current selected repos when dialog opens
    setPinnedReposSnapshot(selectedRepos)

    // Also snapshot for search - so if user immediately starts typing, these repos will be pinned
    setSelectedReposAtQueryChange(selectedRepos)

    // Clear recently unchecked repos when dialog opens
    setRecentlyUncheckedRepos([])

    sendEvent('dotcom_chat.activate', {
      target: 'ATTACHMENT_MENU_REPOSITORIES',
      action: 'open',
      component: 'REPOSITORY_PICKER',
      mode,
    })
  }, [selectedRepos, mode])

  const handleClose = useCallback(() => {
    // Clear recently unchecked repos when dialog closes
    setRecentlyUncheckedRepos([])

    // Update pinned snapshot to current selected repos for next open
    setPinnedReposSnapshot(selectedRepos)
  }, [selectedRepos])

  return (
    <ReposSelector<ChatDropdownRepository>
      repositoryLoader={repositoryLoader}
      selectionVariant="multiple"
      selectAllOption={false}
      onSelect={handleRepoSelect}
      currentSelection={selectedRepos}
      width="medium"
      responsiveStyle="icon-on-mobile"
      iconOnly={showIconOnly}
      liveSelection
      buttonText={buttonText}
      anchorSide={preferredOverlaySide}
      tooltipDirection={tooltipDirection}
      portalContainerName={mode === 'assistive' ? COPILOT_CHAT_MENU_PORTAL_ROOT : undefined}
      overlayPosition={mode === 'assistive' ? 'relative' : undefined}
      additionalButtonProps={{
        leadingVisual: buttonIcon,
        'aria-label': 'Select repositories to attach to conversation',
      }}
      onOpen={handleOpen}
      onClose={handleClose}
    />
  )
}

/**
 * Maps RepositoryPickerRepository to ChatDropdownRepository format.
 * Optionally prepends the current repository if provided and not already in the list.
 */
function mapTopRepositoriesToDropdown(
  repos: RepositoryPickerRepository[],
  currentRepository?: {ownerLogin: string; name: string; id: number} | null,
): ChatDropdownRepository[] {
  const mapped: ChatDropdownRepository[] = repos
    .filter((repo): repo is RepositoryPickerRepository & {databaseId: number} => repo.databaseId != null)
    .map(repo => ({
      id: repo.databaseId,
      name: repo.nameWithOwner,
      enabled: true,
      private: repo.isPrivate,
    }))

  // Prepend current repository if it's not already in the list
  if (currentRepository) {
    const currentNwo = `${currentRepository.ownerLogin}/${currentRepository.name}`
    if (!mapped.some(r => r.name === currentNwo)) {
      mapped.unshift({
        id: currentRepository.id,
        name: currentNwo,
        enabled: true,
        private: undefined, // We don't have visibility info from currentRepository
      })
    }
  }

  return mapped
}

/**
 * Maps RepositoryPickerRepositoryLight to ChatDropdownRepository format.
 * If topRepos is provided, sorts results so top repos appear first.
 */
function mapSearchRepositoriesToDropdownAndSort(
  repos: RepositoryPickerRepositoryLight[],
  topRepos?: ChatDropdownRepository[],
): ChatDropdownRepository[] {
  const mapped = mapSearchRepositoriesToDropdown(repos)

  // Sort: top repos first, then others
  if (topRepos) {
    const topRepoIds = new Set(topRepos.map(r => r.id))
    const inTopRepos = mapped.filter(r => topRepoIds.has(r.id))
    const notInTopRepos = mapped.filter(r => !topRepoIds.has(r.id))
    return [...inTopRepos, ...notInTopRepos]
  }

  return mapped
}

/**
 * Maps RepositoryPickerRepositoryLight from to ChatDropdownRepository format.
 */
function mapSearchRepositoriesToDropdown(repos: RepositoryPickerRepositoryLight[]): ChatDropdownRepository[] {
  return repos
    .filter((repo): repo is RepositoryPickerRepositoryLight & {databaseId: number} => repo.databaseId != null)
    .map(repo => ({
      id: repo.databaseId,
      name: repo.nameWithOwner,
      enabled: true,
      private: repo.isPrivate,
    }))
}

/**
 * Combines matching top repos with search results, avoiding duplicates.
 * Matching top repos appear first, then search results fill the remainder.
 */
function mergeReposWithTopRepoPriority(
  matchingTopRepos: ChatDropdownRepository[],
  searchRepos: RepositoryPickerRepositoryLight[],
): ChatDropdownRepository[] {
  const topRepoIds = new Set(matchingTopRepos.map(r => r.id))
  const mappedSearchRepos = mapSearchRepositoriesToDropdown(searchRepos)
  const additionalRepos = mappedSearchRepos.filter(r => !topRepoIds.has(r.id))

  return [...matchingTopRepos, ...additionalRepos]
}

/**
 * Prepends pinned repositories (selected + recently unchecked) to the top of the list.
 * Pinned repos appear first (preserving their order), followed by remaining non-pinned repos.
 */
function prependPinnedRepos(
  repos: ChatDropdownRepository[],
  pinnedRepos: ChatDropdownRepository[],
): ChatDropdownRepository[] {
  if (pinnedRepos.length === 0) {
    return repos
  }

  const repoIds = new Set(repos.map(r => r.id))
  const pinnedIds = new Set(pinnedRepos.map(r => r.id))

  // Separate pinned repos into those in the list and those not in the list
  const pinnedNotInList = pinnedRepos.filter(r => !repoIds.has(r.id))
  const pinnedInList = repos.filter(r => pinnedIds.has(r.id))

  // Get non-pinned repos from the original list
  const notPinned = repos.filter(r => !pinnedIds.has(r.id))

  // Calculate remaining slots after all pinned repos
  const totalPinned = pinnedNotInList.length + pinnedInList.length
  const remainingSlots = Math.max(0, REPO_RESULTS_LIMIT - totalPinned)

  // Return: pinned repos not in list first, then pinned repos in list, then fill with non-pinned
  return [...pinnedNotInList, ...pinnedInList, ...notPinned.slice(0, remainingSlots)]
}

/**
 * Prepends selected repos that match the search query to the top of search results.
 * This ensures selected items remain visible and at the top when filtering.
 */
function prependMatchingSelectedRepos(
  repos: ChatDropdownRepository[],
  matchingSelectedRepos: ChatDropdownRepository[],
): ChatDropdownRepository[] {
  if (matchingSelectedRepos.length === 0) {
    return repos
  }

  const selectedIds = new Set(matchingSelectedRepos.map(r => r.id))

  // Remove matching selected repos from their current position in results
  const reposWithoutSelected = repos.filter(r => !selectedIds.has(r.id))

  // Prepend matching selected repos to the top
  return [...matchingSelectedRepos, ...reposWithoutSelected]
}

/**
 * Maps TopicItem (from REST API) to ChatDropdownRepository format.
 * Optionally prepends the current repository if provided and not already in the list.
 */
function mapTopicItemsToDropdown(
  repos: TopicItem[],
  currentRepository?: {ownerLogin: string; name: string; id: number} | null,
): ChatDropdownRepository[] {
  const mapped: ChatDropdownRepository[] = repos
    .filter((repo): repo is TopicItem & {databaseId: number} => repo.databaseId != null)
    .map(repo => ({
      id: repo.databaseId,
      name: repo.nwo,
      enabled: true,
      private: undefined, // TopicItem doesn't include visibility info
    }))

  // Prepend current repository if it's not already in the list
  if (currentRepository) {
    const currentNwo = `${currentRepository.ownerLogin}/${currentRepository.name}`
    if (!mapped.some(r => r.name === currentNwo)) {
      mapped.unshift({
        id: currentRepository.id,
        name: currentNwo,
        enabled: true,
        private: undefined, // We don't have visibility info from currentRepository
      })
    }
  }

  return mapped
}
