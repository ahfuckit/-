import {verifiedFetchJSON} from '@github-ui/verified-fetch'
import {COPILOT_ASSIGNMENT_API_ENDPOINT} from './constants'
import type {Copilot} from '../components/copilot-assignment/copilot-assignment-types'

export interface CopilotAssignmentOptions {
  instructions: string
  targetRepo: string
  targetBranch: string
  customAgent?: string
  agentId?: string
  model?: string
}

export interface CopilotAssignmentJob {
  issue_number: number
  job: {
    id: string
  }
}

export interface CopilotAssignmentSuccessResponse {
  jobs: CopilotAssignmentJob[]
  copilot?: Copilot
}

export interface CopilotAssignmentErrorResponse {
  error: string
  jobs: CopilotAssignmentJob[]
}

export interface CopilotAssignmentResponse {
  ok: boolean
  status: number
  data?: CopilotAssignmentSuccessResponse
  errorMessage?: string
  jobs?: CopilotAssignmentJob[]
  copilot?: Copilot
}

/**
 * Assigns an issue to Copilot with the specified instructions and target repository.
 *
 * @param owner - The repository owner
 * @param repo - The repository name
 * @param issueNumber - The issue number to assign
 * @param options - Assignment options including instructions and target repository
 * @returns Promise resolving to the API response
 */
export async function assignIssueToCopilot(
  owner: string,
  repo: string,
  issueNumber: number,
  options: CopilotAssignmentOptions,
): Promise<CopilotAssignmentResponse> {
  return assignIssuesToCopilot(owner, repo, [issueNumber], options)
}

/**
 * Assigns multiple issues to Copilot with the specified instructions and target repository.
 *
 * @param owner - The repository owner
 * @param repo - The repository name
 * @param issueNumbers - Array of issue numbers to assign
 * @param options - Assignment options including instructions and target repository
 * @returns Promise resolving to the API response
 */
export async function assignIssuesToCopilot(
  owner: string,
  repo: string,
  issueNumbers: number[],
  options: CopilotAssignmentOptions,
): Promise<CopilotAssignmentResponse> {
  try {
    const response = await verifiedFetchJSON(`/${owner}/${repo}${COPILOT_ASSIGNMENT_API_ENDPOINT}`, {
      method: 'POST',
      body: {
        issue_ids: issueNumbers,
        repo_name_with_owner: options.targetRepo,
        base_ref: options.targetBranch,
        custom_instructions: options.instructions,
        custom_agent: options.customAgent,
        agent_id: options.agentId,
        model: options.model,
      },
    })

    if (response.ok) {
      const data: CopilotAssignmentSuccessResponse = await response.json()
      return {
        ok: true,
        status: response.status,
        data,
      }
    } else {
      // Try to extract error message from response body
      let errorMessage: string
      try {
        const errorData: CopilotAssignmentErrorResponse = await response.json()
        errorMessage = errorData.error || `Request failed with status ${response.status}`
        const result = {
          ok: false,
          status: response.status,
          errorMessage,
          jobs: errorData.jobs || [],
        }
        return result
      } catch {
        errorMessage = `Request failed with status ${response.status}`
        return {
          ok: false,
          status: response.status,
          errorMessage,
        }
      }
    }
  } catch (error) {
    return {
      ok: false,
      status: 0,
      errorMessage: error instanceof Error ? error.message : 'An unexpected error occurred',
    }
  }
}
