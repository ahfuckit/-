import {useState} from 'react'
import {Button} from '@primer/react'
import {clsx} from 'clsx'
import {useAutomatedReviewCommentActions} from '../hooks/use-automated-review-comment-actions'
import {BaseSharedDismissalDialog} from '@github-ui/shared-dismissal/base-shared-dismissal-dialog'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {AutomatedCommentSource, DelegatedDismissalRequestStatuses} from '@github-ui/diff-lines/conversation-types'
import {StatusMessage} from './StatusMessage'
import type {AutomatedComment} from '../types'

interface BaseAutomatedReviewCommentActionsProps {
  automatedComment: AutomatedComment
  isButtonDisabled: boolean
  dismissError: Error | null
  onDismiss: (dismissalPayload: {reason: string; resolutionNote?: string}, callback: {onSuccess: () => void}) => void
  onReopen: () => void
  className?: string
}

export function BaseAutomatedReviewCommentActions({
  automatedComment,
  isButtonDisabled,
  dismissError,
  onDismiss,
  onReopen,
  className,
}: BaseAutomatedReviewCommentActionsProps) {
  const [dismissDialogIsOpen, setDismissDialogIsOpen] = useState(false)
  const {isDismissable, isReopenable, resourceName, toggleButtonLabel} =
    useAutomatedReviewCommentActions(automatedComment)
  const pendingDelegatedDismissalRequest =
    automatedComment.delegatedDismissalRequest?.status === DelegatedDismissalRequestStatuses.Pending
  const isDismissButtonDisabled =
    isButtonDisabled || !automatedComment.viewerCanDismiss || pendingDelegatedDismissalRequest
  const isReopenButtonDisabled = isButtonDisabled || !automatedComment.viewerCanReopen
  const delegatedDismissalEnabled = automatedComment.delegatedDismissalEnabled

  return (
    <>
      {dismissDialogIsOpen && (
        <BaseSharedDismissalDialog
          setOpen={setDismissDialogIsOpen}
          count={1}
          error={dismissError}
          dismissalOptions={automatedComment.dismissalOptions}
          onSubmit={({resolution, dismissalComment}) =>
            onDismiss(
              {reason: resolution, resolutionNote: dismissalComment},
              {onSuccess: () => setDismissDialogIsOpen(false)},
            )
          }
          delegatedAlertDismissalEnabled={delegatedDismissalEnabled}
          codeSecurity={automatedComment.source === AutomatedCommentSource.CodeScanning}
        />
      )}
      <div className={clsx('d-flex flex-items-center flex-wrap', className)}>
        {isDismissable && (
          <Button
            aria-label={toggleButtonLabel}
            className="mr-2"
            onClick={() => setDismissDialogIsOpen(true)}
            disabled={isDismissButtonDisabled}
          >
            {toggleButtonLabel}
          </Button>
        )}
        {isReopenable && (
          <Button aria-label={toggleButtonLabel} className="mr-2" onClick={onReopen} disabled={isReopenButtonDisabled}>
            {toggleButtonLabel}
          </Button>
        )}
        <StatusMessage automatedComment={automatedComment} resourceName={resourceName} />
      </div>
    </>
  )
}
