import React from 'react'

export type FilesPageAction = 'tree' | 'blob' | 'edit' | 'new' | 'blame'

const ActionContext = React.createContext<FilesPageAction>('tree')

export function ActionProvider({children, action}: React.PropsWithChildren<{action: FilesPageAction}>) {
  return <ActionContext value={action}>{children}</ActionContext>
}

export function useAction() {
  return React.use(ActionContext)
}
