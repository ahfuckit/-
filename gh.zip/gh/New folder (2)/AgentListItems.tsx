import {GitHubAvatar} from '@github-ui/github-avatar'
import {ActionList} from '@primer/react'
import type {AgentInfo, SelectedAgent} from '../../types/session'
import type {SubAgent} from '../../types/agent'
import {isCopilotCodingAgent} from '../../utils/agent-helpers'

type AgentListItemsProps = {
  topLevelAgents: AgentInfo[]
  customAgents: SubAgent[]
  selectedAgent: SelectedAgent
  onSelectAgent: (agent: SelectedAgent) => void
}

export function AgentListItems({topLevelAgents, customAgents, selectedAgent, onSelectAgent}: AgentListItemsProps) {
  return (
    <>
      {topLevelAgents.length > 0 && (
        <ActionList.Group selectionVariant="single">
          <ActionList.GroupHeading>Agents</ActionList.GroupHeading>
          {topLevelAgents.map((agent: AgentInfo) => {
            const isCopilot = isCopilotCodingAgent(agent.slug)
            const isTopLevelAgentSelected =
              selectedAgent?.typeName === 'topLevel' && selectedAgent.topLevelAgentId === agent.id
            const isCopilotDefaultSelected = !selectedAgent?.typeName && isCopilot
            const isSelected = isTopLevelAgentSelected || isCopilotDefaultSelected
            return (
              <ActionList.Item
                key={agent.id}
                disabled={false}
                selected={isSelected}
                onSelect={() =>
                  onSelectAgent(
                    isSelected
                      ? {}
                      : {
                          typeName: 'topLevel',
                          topLevelAgentId: agent.id,
                          displayName: agent.display_name,
                          avatarUrl: agent.avatar_url,
                          login: agent.slug,
                          botGlobalRelayId: agent.bot_global_relay_id,
                        },
                  )
                }
              >
                <ActionList.LeadingVisual>
                  <GitHubAvatar src={agent.avatar_url || ''} size={16} square />
                </ActionList.LeadingVisual>
                {agent.display_name}
              </ActionList.Item>
            )
          })}
        </ActionList.Group>
      )}

      {customAgents.length > 0 && (
        <>
          {topLevelAgents.length > 0 && <ActionList.Divider />}
          <ActionList.Group selectionVariant="single">
            <ActionList.GroupHeading>Custom agents</ActionList.GroupHeading>
            {customAgents.map(agent => {
              const hasConfigError = !!agent.config_error && agent.config_error.length > 0
              const isSelected = selectedAgent.subAgentSlug === agent.name
              return (
                <ActionList.Item
                  key={agent.name}
                  disabled={hasConfigError}
                  inactiveText={hasConfigError ? agent.config_error : undefined}
                  selected={isSelected}
                  onSelect={() =>
                    onSelectAgent(
                      isSelected
                        ? {}
                        : {
                            typeName: 'customSubAgent',
                            subAgentSlug: agent.name,
                            displayName: agent.display_name || agent.name,
                            login: agent.name,
                          },
                    )
                  }
                >
                  {agent.display_name || agent.name}
                </ActionList.Item>
              )
            })}
          </ActionList.Group>
        </>
      )}
    </>
  )
}
