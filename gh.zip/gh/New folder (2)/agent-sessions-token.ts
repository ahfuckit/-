import {AuthToken} from './auth-token'
import {CopilotAuthTokenProvider} from './copilot-auth-token'

export const AGENT_SESSIONS_TOKEN_KEY = 'AGENT_SESSIONS_TOKEN'

let agentSessionsTokenProviderInstance: AgentSessionsTokenProvider | null = null

/**
 * Returns a singleton instance of AgentSessionsTokenProvider.
 * This ensures request deduplication works across all callers.
 */
export function getAgentSessionsTokenProvider(): AgentSessionsTokenProvider {
  if (!agentSessionsTokenProviderInstance) {
    agentSessionsTokenProviderInstance = new AgentSessionsTokenProvider()
  }
  return agentSessionsTokenProviderInstance
}

/**
 * Resets the singleton instance. Only intended for use in tests.
 * @internal
 */
export function resetAgentSessionsTokenProviderForTests(): void {
  agentSessionsTokenProviderInstance = null
}

export class AgentSessionsTokenProvider extends CopilotAuthTokenProvider {
  constructor() {
    const tokenEndpoint = `/copilot/agent-sessions/token`
    super([], tokenEndpoint, AGENT_SESSIONS_TOKEN_KEY)
  }

  protected override async validateAuthToken(token: AuthToken): Promise<AuthToken> {
    if (token.ssoChanged(this.ssoOrgIDs)) {
      return this.fetchAuthToken()
    }

    if (!token.isExpired) {
      return token
    }

    return this.fetchAuthToken()
  }

  /**
   * Attempts to refresh the token by forcing a server-side cache miss.
   * Use this after receiving a 401 from CAPI (e.g., token was evicted).
   */
  async tryRefreshToken(): Promise<boolean> {
    if (this.isUnlicensed) {
      return false
    }

    try {
      await this.fetchAuthToken(true)
      return true
    } catch {
      return false
    }
  }
}
