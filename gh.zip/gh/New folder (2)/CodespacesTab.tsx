import type {RepoPolicyInfo} from '@github-ui/code-view-types'
import {ErrorBoundary} from '@github-ui/react-core/error-boundary'
import type {SafeHTMLString} from '@github-ui/safe-html'
import {VerifiedHTMLBox} from '@github-ui/safe-html/VerifiedHTML'
import {ActionList, Link, SkeletonBox} from '@primer/react'
import {Suspense, type ReactNode} from 'react'
import styles from './CodeDropdownButton.module.css'
import {useCodespaceContent} from './use-codespaces-query'

function defaultErrorMessage(contactPath: string) {
  return (
    <span>
      An unexpected error occurred. Please{' '}
      <Link inline href={contactPath}>
        contact support
      </Link>{' '}
      for more information.
    </span>
  )
}

export interface CodespacesTabProps {
  hasAccessToCodespaces: boolean
  repoPolicyInfo?: RepoPolicyInfo
  contactPath: string
  currentUserIsEnterpriseManaged?: boolean
  enterpriseManagedBusinessName?: string
  newCodespacePath?: string
  codespacesPath?: string
  isLoggedIn: boolean
}

function ErrorMessage({header, message}: {header: string; message: ReactNode}) {
  return (
    <div className="blankslate">
      <p className="fgColor-default text-bold mb-1">{header}</p>
      <p className="mt-2 tmp-mx-4">{message}</p>
    </div>
  )
}

export function CodespacesTabWrapper({children}: {children?: ReactNode}) {
  return (
    <div className="d-flex flex-justify-center">
      <ErrorBoundary
        fallback={<ErrorMessage header="Codespaces data failed to load." message="Refresh the page and try again." />}
      >
        <Suspense
          fallback={
            <div role="status" className={styles.CodespacesSkeletonWrapper} aria-busy aria-label="Loading Codespaces">
              <div className={styles.SkeletonLoaderWrapper}>
                <SkeletonBox width="100%" height={'var(--base-size-32)'} />
              </div>
              <ActionList.Divider />
              <div className={styles.SkeletonLoaderWrapper}>
                <SkeletonBox width="100%" height={'var(--base-size-64)'} />
              </div>
              <ActionList.Divider />
              <div className={styles.SkeletonLoaderWrapper}>
                <SkeletonBox width="100%" height={'var(--base-size-32)'} />
              </div>
            </div>
          }
        >
          {children}
        </Suspense>
      </ErrorBoundary>
    </div>
  )
}

function ServerRenderedCodespacesTabContent({codespacesPath}: {codespacesPath?: string}) {
  const {data: content} = useCodespaceContent(codespacesPath)

  return (
    <VerifiedHTMLBox
      className="width-full"
      /* eslint-disable-next-line @github-ui/github-monorepo/no-cast-as-safe-html-string -- HTML is sanitized server-side. This IS the ingress point. See: reactFetch(codespacesPath) */
      html={content as SafeHTMLString}
    />
  )
}

export function CodespacesTabContent(props: CodespacesTabProps) {
  const {
    hasAccessToCodespaces,
    repoPolicyInfo,
    contactPath,
    currentUserIsEnterpriseManaged,
    enterpriseManagedBusinessName,
    newCodespacePath,
    codespacesPath,
    isLoggedIn,
  } = props

  if (!hasAccessToCodespaces) {
    if (!isLoggedIn) {
      return (
        <ErrorMessage
          header="Sign in required"
          message={
            <span>
              Please{' '}
              <Link inline href={newCodespacePath}>
                sign in
              </Link>{' '}
              to use Codespaces.
            </span>
          }
        />
      )
    }

    if (!repoPolicyInfo?.allowed) {
      let message = null
      if (!repoPolicyInfo?.canBill && currentUserIsEnterpriseManaged) {
        message = (
          <span>
            <Link href="https://docs.github.com/enterprise-cloud@latest/admin/identity-and-access-management/using-enterprise-managed-users-for-iam/about-enterprise-managed-users">
              Enterprise-managed users
            </Link>
            {` must have their Codespaces usage paid for by ${enterpriseManagedBusinessName || 'their enterprise'}.`}
          </span>
        )
      } else if (repoPolicyInfo?.hasIpAllowLists) {
        message = (
          <span>
            Your organization or enterprise enforces{' '}
            <Link
              inline
              href="https://docs.github.com/enterprise-cloud@latest/organizations/keeping-your-organization-secure/managing-security-settings-for-your-organization/managing-allowed-ip-addresses-for-your-organization"
            >
              IP allow lists
            </Link>{' '}
            which are unsupported by Codespaces at this time.
          </span>
        )
      } else if (repoPolicyInfo?.disabledByBusiness) {
        message = (
          <span>
            Your enterprise has disabled Codespaces at this time. Please contact your enterprise administrator for more
            information.
          </span>
        )
      } else if (repoPolicyInfo?.disabledByOrganization) {
        message = (
          <span>
            Your organization has disabled Codespaces on this repository. Please contact your organization administrator
            for more information.
          </span>
        )
      } else {
        message = defaultErrorMessage(contactPath)
      }
      return <ErrorMessage header="Codespace access limited" message={message} />
    } else if (!repoPolicyInfo?.changesWouldBeSafe) {
      return (
        <ErrorMessage
          header="Repository access limited"
          message={<span>You do not have access to push to this repository and its owner has disabled forking.</span>}
        />
      )
    } else {
      return <ErrorMessage header="Codespace access limited" message={defaultErrorMessage(contactPath)} />
    }
  }

  return <ServerRenderedCodespacesTabContent codespacesPath={codespacesPath} />
}

export function CodespacesTab(props: CodespacesTabProps) {
  return (
    <CodespacesTabWrapper>
      <CodespacesTabContent {...props} />
    </CodespacesTabWrapper>
  )
}
