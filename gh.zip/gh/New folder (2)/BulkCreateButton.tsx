import {CommandButton} from '@github-ui/ui-commands'
import {useMemo, useState} from 'react'

import type {DraftOrExistingIssue} from '../content-preview-types'
import {BulkCreateDialog} from './BulkCreateDialog'
import {type TreeNode, visit} from './use-draft-issue-tree-map'

export function BulkCreateButton({
  issueNode,
  disabled = false,
  onSuccess,
}: {
  issueNode: TreeNode<DraftOrExistingIssue>
  disabled?: boolean
  onSuccess: () => void
}) {
  const [showBulkConfirmDialog, setShowBulkConfirmDialog] = useState(false)

  // Find the root of the issue tree from the one provided
  const rootIssueNode = useMemo(() => {
    let currentNode: TreeNode<DraftOrExistingIssue> | undefined = issueNode
    while (currentNode?.parent) {
      currentNode = currentNode.parent
    }
    return currentNode
  }, [issueNode])

  // Get the distinct types of nodes in the tree. This will tell us whether we have a mixed tree.
  const distinctNodeTypes = useMemo(() => {
    const nodeTypes = new Set<string>()
    visit(rootIssueNode, node => nodeTypes.add(node.item.type))
    return nodeTypes
  }, [rootIssueNode])

  // If we have a homogeneous tree of only existing issues, the button CTA should be "Update all"
  const buttonText = useMemo(() => {
    if (distinctNodeTypes.size === 1 && distinctNodeTypes.has('existing-issue')) {
      return 'Review and update'
    }

    return 'Review and create'
  }, [distinctNodeTypes])

  // If we have a heterogeneous tree, but this is an existing issue, we do not show the CTA button.
  if (distinctNodeTypes.size > 1 && issueNode.item.type === 'existing-issue') {
    return null
  }

  return (
    <>
      <CommandButton
        commandId="github:submit-form"
        variant="primary"
        disabled={disabled}
        data-testid="create-bulk-issue-dialog-button"
        showKeybindingHint
        onClick={e => {
          e.preventDefault()
          setShowBulkConfirmDialog(true)
        }}
      >
        {buttonText}
      </CommandButton>
      {showBulkConfirmDialog && (
        <BulkCreateDialog
          issueNode={rootIssueNode}
          onComplete={() => {
            setShowBulkConfirmDialog(false)
            onSuccess()
          }}
          onCancel={() => {
            setShowBulkConfirmDialog(false)
          }}
        />
      )}
    </>
  )
}
