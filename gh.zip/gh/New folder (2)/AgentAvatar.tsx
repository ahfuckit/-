import {GitHubAvatar} from '@github-ui/github-avatar'
import {CopilotAnimation, CopilotAnimationType} from '@github-ui/copilot-animation'
import {useAgentInfo} from '../hooks/use-agent-info'
import styles from './AgentAvatar.module.css'

interface AgentAvatarProps {
  size?: number
  animationType?: CopilotAnimationType | 'static'
  loopAnimation?: boolean
  agentId?: number
}

/**
 * Component that displays the agent's avatar if available,
 * otherwise falls back to the Copilot animation.
 *
 */
export function AgentAvatar({size = 32, animationType = 'static', loopAnimation = false, agentId}: AgentAvatarProps) {
  const {data: agentInfo} = useAgentInfo(agentId ?? null)

  const agentAvatarUrl = agentInfo?.avatar_url
  const agentDisplayName = agentInfo?.display_name || 'Agent'
  const isCopilot = agentDisplayName.toLowerCase() === 'copilot'

  if (isCopilot || !agentAvatarUrl) {
    return (
      <span className={styles.avatarWrapper}>
        <CopilotAnimation size={size} animationType={animationType} loopAnimation={loopAnimation} />
      </span>
    )
  }

  return (
    <span className={styles.avatarWrapper}>
      <GitHubAvatar src={agentAvatarUrl} size={size} alt={agentDisplayName} square />
    </span>
  )
}
