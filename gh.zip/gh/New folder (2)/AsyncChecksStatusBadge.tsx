import {ChecksStatusBadge, useCommitChecksStatusDetails} from '@github-ui/commit-checks-status'
import type {RepositoryNWO} from '@github-ui/current-repository'

import styles from './AsyncChecksStatusBadge.module.css'

interface Props {
  oid: string
  status: string | undefined
  repo: RepositoryNWO
  descriptionString?: string
  badgeProps?: Omit<
    React.ComponentProps<typeof ChecksStatusBadge>,
    'statusRollup' | 'combinedStatus' | 'onWillOpenPopup' | 'disablePopover'
  >
}

// eslint-disable-next-line @eslint-react/no-unstable-default-props
export function AsyncChecksStatusBadge({status, oid, repo, badgeProps = {}, descriptionString = ''}: Props) {
  const [details, fetchDetails] = useCommitChecksStatusDetails(oid, repo)
  return status ? (
    <ChecksStatusBadge
      disablePopover={false}
      size={'small'}
      statusRollup={status}
      combinedStatus={details}
      descriptionText={descriptionString}
      onWillOpenPopup={fetchDetails}
      buttonClassName={styles.ChecksStatusBadge}
      {...badgeProps}
    />
  ) : null
}
