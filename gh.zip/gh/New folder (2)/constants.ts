import type {Session} from '../types/session'
import type {Pull} from '../types/pull'
import type {HydratedTask} from '../types/task'

// Immersive chat plugin constants
export const AGENTS_PLUGIN_ID = 'agents'
export const AGENTS_PLUGIN_NAME = 'Agents'
export const AGENTS_PATH = '/copilot/agents'
export const TASKS_PLUGIN_ID = 'tasks'
export const TASKS_PLUGIN_NAME = 'Tasks'
export const TASK_VIEW_COMPONENT_ID = 'task-view'
export const TASKS_IN_CHAT_COMPONENT_ID = 'tasks-in-chat-view'

// Copilot assignment constants
export const COPILOT_INSTRUCTIONS_MAX_LENGTH = 10000
export const COPILOT_ASSIGNMENT_API_ENDPOINT = '/issues/agent_assignments'
export const COPILOT_REPOSITORIES_API_ENDPOINT = '/copilot/agent-sessions/repositories'
export const COPILOT_CODING_AGENT_DOCS_URL = 'https://gh.io/assigncopilot'

// Agent task prompt constants
export const MAX_AGENT_TASK_PROMPT_LENGTH = 30000

// Enterprise Copilot coding agent policy URL builder
export const buildEnterpriseCopilotCodingAgentPolicyUrl = (enterpriseSlug: string) =>
  `/enterprises/${encodeURIComponent(enterpriseSlug)}/ai-controls/agents/policies`

// Copilot assignment modal constants
export const COPILOT_ASSIGNMENT_PROMPT_PLACEHOLDER = 'Provide additional instructions for Copilot'
export const COPILOT_ASSIGNMENT_BRANCH_CAPTION =
  'Pick the starting point that Copilot will use when it creates a new branch'
export const COPILOT_ASSIGNMENT_REPO_LABEL = 'Target repository'
export const COPILOT_ASSIGNMENT_BRANCH_LABEL = 'Base branch'
export const COPILOT_ASSIGNMENT_AGENT_LABEL = 'Custom agent'
export const COPILOT_ASSIGNMENT_PROMPT_LABEL = 'Optional prompt'
export const COPILOT_ASSIGNMENT_SELECT_BRANCH_HEADING = 'Select base branch'

// Event type constants
export const COPILOT_CHAT_SPEC_TASK_EVENT_TYPE = 'copilot-chat-spec-task'

// This is a special prefix that CCA uses for models provided by CAPI. We strip out the provider before resolving the actual model.
export const SWEAGENT_CAPI_MODEL_PREFIX = 'sweagent-capi:'

// Bump this version number to reset all users' cached model selection
const AGENT_TASKS_SELECTED_MODEL_VERSION = 1
export const AGENT_TASKS_SELECTED_MODEL_KEY = `AGENT_TASKS_SELECTED_MODEL_v${AGENT_TASKS_SELECTED_MODEL_VERSION}`

// Propose work dialog constants
export const PROPOSE_WORK_MAX_TEXTAREA_HEIGHT = 500

// Avatar fallback colors for deterministic placeholder avatars
export const AVATAR_FALLBACK_COLORS = [
  'var(--fgColor-done)',
  'var(--fgColor-accent)',
  'var(--fgColor-success)',
  'var(--fgColor-attention)',
  'var(--fgColor-severe)',
  'var(--fgColor-danger)',
  'var(--fgColor-sponsors)',
] as const

// Helper function to create mock pull request data
// we can remove it once we have real data
function createMockPull(
  id: number,
  global_relay_id: string,
  number: number,
  state: 'open' | 'closed' | 'merged',
  title: string,
  reviewable_state: 'draft' | 'ready',
  labels: string[],
  comments: number,
  assignees_count: number,
  author: string,
  created_days_ago: number,
  updated_days_ago: number = 0,
  inMergeQueue: boolean = false,
): Pull {
  const baseDate = new Date('2025-06-04T20:00:00.000Z')
  const createdAt = new Date(baseDate.getTime() - created_days_ago * 24 * 60 * 60 * 1000)
  const updatedAt = new Date(baseDate.getTime() - updated_days_ago * 24 * 60 * 60 * 1000)

  return {
    id,
    global_relay_id,
    number,
    state,
    title,
    reviewable_state,
    url: `http://github.localhost:80/monalisa/smile/pull/${number}`,
    labels,
    comments,
    assignees_avatar_urls: Array.from(
      {length: assignees_count},
      (_, i) => `https://avatars.githubusercontent.com/u/${id + i}?v=4`,
    ),
    created_at: createdAt.toISOString(),
    updated_at: updatedAt.toISOString(),
    merged_at: state === 'merged' ? updatedAt.toISOString() : undefined,
    closed_at: state === 'closed' || state === 'merged' ? updatedAt.toISOString() : undefined,
    author,
    head_sha: `${title.toLowerCase().replace(/\s+/g, '')}123456789abcdef0123456789abcdef01234567`.substring(0, 40),
    repository_nwo: 'monalisa/smile',
    inMergeQueue,
    repository_id: 1,
    head_ref_name: 'feature-branch',
    base_ref_name: 'main',
    pr_diff_summary: {
      lines_added: Math.floor(Math.random() * 4) + 1,
      lines_changed: Math.floor(Math.random() * 3) + 1,
      lines_deleted: Math.floor(Math.random() * 2) + 1,
    },
  }
}

// Helper function to create mock session data
export function createMockSession(
  id: string,
  name: string,
  user_id: number,
  agent_id: number,
  state: 'idle' | 'in_progress' | 'waiting_for_user' | 'completed' | 'failed' | 'cancelled' | 'timed_out',
  resource_id: number,
  resource_global_id: string,
  created_hours_ago: number,
  updated_hours_ago: number = 0,
  premium_requests: number = 0,
  error_message?: string,
  model?: string,
): Session {
  const baseDate = new Date('2025-06-04T20:00:00.000Z')
  const createdAt = new Date(baseDate.getTime() - created_hours_ago * 60 * 60 * 1000)
  const updatedAt = new Date(baseDate.getTime() - updated_hours_ago * 60 * 60 * 1000)
  const isCompleted = state === 'completed' || state === 'failed'

  return {
    id,
    name,
    user_id,
    agent_id,
    state,
    owner_id: 9919,
    repo_id: 4,
    resource_type: 'pull' as const,
    resource_id,
    resource_global_id,
    created_at: createdAt.toISOString(),
    last_updated_at: updatedAt.toISOString(),
    completed_at: isCompleted ? updatedAt.toISOString() : undefined,
    workflow_run_id: 12340 + Math.floor(Math.random() * 30),
    log_entries: [],
    error: error_message ? {message: error_message} : null,
    premium_requests,
    event_identifiers: null,
    event_type: 'api_call_received',
    event_url: null,
    event_content: name || null,
    model: model ?? '',
  }
}

// Helper function to create Task from pull and session data
function createTask(pull: Pull, session: Session): HydratedTask {
  return {
    resource_type: 'pull',
    resource_id: pull.id,
    resource_global_id: pull.global_relay_id,
    session_count: 1,
    latest_session_updated_at: session.last_updated_at,
    latest_session_state: session.state,
    pull,
  }
}

// Generate 21 mock session items programmatically (3 Pull states × 7 session states)
export const mockAgentTasks: HydratedTask[] = (() => {
  const pullStates: Array<'open' | 'closed' | 'merged'> = ['open', 'closed', 'merged']
  const sessionStates: Array<
    'cancelled' | 'idle' | 'in_progress' | 'waiting_for_user' | 'completed' | 'failed' | 'timed_out'
  > = ['cancelled', 'idle', 'in_progress', 'waiting_for_user', 'completed', 'failed', 'timed_out']

  const mockData = {
    titles: [
      'Refactor database queries for performance',
      'Implement dark mode theme',
      'Optimize API response times',
      'Add mobile responsive design',
      'Implement caching layer',
      'Add internationalization support',
      'Update documentation and README',
      'Fix critical security vulnerability',
      'Add user authentication system',
      'Initial project setup and configuration',
      'Implement real-time notifications',
      'Add search functionality',
      'Optimize bundle size',
      'Add unit tests coverage',
      'Implement error handling',
      'Add accessibility features',
      'Optimize database connections',
      'Implement feature flags',
      'Migrate to TypeScript',
      'Implement CI/CD pipeline',
      'Add monitoring and alerts',
    ],
    authors: ['alice-dev', 'bob-backend', 'charlie-frontend', 'diana-fullstack', 'eve-designer', 'frank-security'],
    labels: [
      ['performance', 'database'],
      ['ui', 'theme', 'enhancement'],
      ['performance', 'api'],
      ['mobile', 'responsive', 'ui'],
      ['performance', 'caching', 'backend'],
      ['i18n', 'feature', 'localization'],
    ],
    errorMessages: ['timeout', 'validation error', 'resource conflict', 'permission denied'],
  }

  let id = 1
  let globalId = ''
  return [
    ...pullStates.flatMap(pullState =>
      sessionStates.map(sessionState => {
        globalId = `PR_${id}`
        const titleIndex = (id - 1) % mockData.titles.length
        const title = mockData.titles[titleIndex] as string
        const author = mockData.authors[(id - 1) % mockData.authors.length] as string
        const labels = mockData.labels[titleIndex % mockData.labels.length] as string[]

        const pull = createMockPull(
          id,
          globalId,
          id,
          pullState,
          title,
          Math.random() > 0.7 ? 'draft' : 'ready',
          labels,
          Math.floor(Math.random() * 15) + 1,
          Math.floor(Math.random() * 3),
          author,
          id,
          id,
        )

        const session = createMockSession(
          `session-${id.toString().padStart(3, '0')}`,
          `${title.split(' ').slice(0, 3).join(' ')} - ${sessionState}`,
          10053400 + id,
          1143300 + id,
          sessionState,
          id,
          globalId,
          id,
          id,
          Math.floor(Math.random() * 10),
          sessionState === 'failed'
            ? `Operation failed due to ${mockData.errorMessages[Math.floor(Math.random() * 4)] as string}`
            : undefined,
        )

        const result = createTask(pull, session)
        id++
        return result
      }),
    ),
    // Add one more session with in merge queue
    createTask(
      createMockPull(
        id,
        globalId,
        id,
        'open',
        'Add feature flags support (in merge queue)',
        'ready',
        ['feature', 'flags'],
        5,
        1,
        'alice-dev',
        21, // Sequential days from 1 to 21,
        0,
        true,
      ),
      createMockSession(
        `session-${id.toString().padStart(3, '0')}`,
        'Add feature flags support - in_progress',
        10053400 + id,
        1143300 + id,
        'in_progress',
        id,
        globalId,
        1, // Created just now
        0, // Updated just now
        2, // Premium requests
        undefined,
      ),
    ),
  ]
})()
