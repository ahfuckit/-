import {unifiedMergeView} from '@codemirror/merge'
import {noop} from '@github-ui/noop'
import {useMemo, useRef} from 'react'

import type {SpacingOptions} from './CodeMirror'
import CodeMirror from './CodeMirror'
import styles from './CodeMirrorDiff.module.css'
import {useCodeMirrorDiff} from './hooks/use-code-mirror-diff'

export interface CodeMirrorDiffProps {
  fileName: string
  /** content for the left side of the diff */
  left: string
  /** aria-labelled by for the left side of the split view */
  leftLabelledBy: string
  /** content for the right side of the diff */
  right: string
  /** aria-labelled by for the right side of the split view */
  rightLabelledBy: string
  /** aria-labelled by for the unified view */
  unifiedLabelledBy: string
  spacing: SpacingOptions
  view: 'unified' | 'split'
}

/**
 * Displays a diff using CodeMirror
 */
export function CodeMirrorDiff(props: CodeMirrorDiffProps) {
  if (!props.left || !props.right) {
    return <CodeMirrorDiffNewOrDeletedFile {...props} />
  } else if (props.view === 'split') {
    return <CodeMirrorDiffSplit {...props} />
  } else {
    return <CodeMirrorDiffUnified {...props} />
  }
}

function CodeMirrorDiffSplit(props: CodeMirrorDiffProps) {
  const containerRef = useRef<HTMLDivElement | null>(null)

  useCodeMirrorDiff({
    ...props,
    parentRef: containerRef,
  })
  return <div ref={containerRef} className={styles.container} />
}

function CodeMirrorDiffUnified(props: CodeMirrorDiffProps) {
  const unifiedExtensions = useMemo(
    () => [unifiedMergeView({original: props.left, mergeControls: false, gutter: false})],
    [props.left],
  )

  return (
    <CodeMirror
      ariaLabelledBy={props.unifiedLabelledBy}
      containerClassName={styles.container}
      fileName={props.fileName}
      height="100%"
      isReadOnly
      spacing={props.spacing}
      value={props.right}
      onChange={noop}
      placeholder="Loading..."
      hideHelp
      extensions={unifiedExtensions}
    />
  )
}

function CodeMirrorDiffNewOrDeletedFile(props: CodeMirrorDiffProps) {
  const style = props.left === '' ? styles.newFile : styles.deletedFile
  const fileValue = props.right || props.left
  return (
    <CodeMirror
      ariaLabelledBy={props.unifiedLabelledBy}
      containerClassName={style}
      fileName={props.fileName}
      height="100%"
      isReadOnly
      spacing={props.spacing}
      value={fileValue}
      onChange={noop}
      placeholder="Loading..."
      hideHelp
    />
  )
}
