import type {Repository} from '@github-ui/current-repository'
import {GitHubAvatar} from '@github-ui/github-avatar'
import {useGetHovercardAttributesForType} from '@github-ui/hovercards/use-get-hovercard-attributes-for-type'
import {commitsByAuthor} from '@github-ui/paths'
import {ProfileReference} from '@github-ui/profile-reference'
import {Link, Box} from '@primer/styled-react'
import type {BoxProps} from '@primer/styled-react'
import type {Author} from '../commit-attribution-types'
import {isBotOrApp} from '../utils'
import {AuthorTooltip} from './AuthorTooltip'
import {useAuthorSettings} from '../contexts/AuthorSettingsContext'
import {AuthorDisplayName} from './AuthorDisplayName'

import styles from './AuthorAvatar.module.css'

type AuthorAvatarProps = {
  author: Author | undefined
  repo: Pick<Repository, 'ownerLogin' | 'name'>
  sx?: BoxProps['sx']
}

/**
 * Renders the author of a commit.
 */
export function AuthorAvatar({author, repo, sx}: AuthorAvatarProps) {
  const authorSettings = useAuthorSettings()
  const getHovercardAttributesForType = useGetHovercardAttributesForType()
  const hovercardAttrs = getHovercardAttributesForType('user', {login: author?.login ?? ''})

  if (!author) return null

  const avatar = (
    <GitHubAvatar
      aria-label={`${author.login || 'author'}`}
      src={author.avatarUrl}
      alt={`${author.login || 'author'}`}
      size={authorSettings.avatarSize}
      square={isBotOrApp(author)}
      className={styles.authorAvatarImage}
    />
  )

  return (
    <Box
      sx={{
        ...sx,
      }}
      data-testid="author-avatar"
      className={styles.AuthorAvatarContainer}
    >
      {author.path ? (
        <Link href={author.path} data-testid="avatar-icon-link" {...(author.login ? hovercardAttrs : {})}>
          {avatar}
        </Link>
      ) : (
        avatar
      )}
      {author.login ? (
        <AuthorTooltip author={author} renderTooltip={authorSettings.includeTooltip}>
          <Link
            muted
            href={commitsByAuthor({repo, author: author.login})}
            aria-label={`commits by ${author.login}`}
            {...hovercardAttrs}
            sx={{
              fontWeight: authorSettings.fontWeight,
              color: authorSettings.fontColor,

              '&:hover': {
                color: authorSettings.fontColor,
              },
            }}
            className={styles.authorHoverableLink}
          >
            <ProfileReference login={author.login} profileName={author.profileName} isAgent={false} />
          </Link>
        </AuthorTooltip>
      ) : (
        <AuthorDisplayName displayName={author.displayName} authorSettings={authorSettings} />
      )}
    </Box>
  )
}
