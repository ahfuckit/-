import type {PublicUser} from './public-user'

type User = {
  avatar_url: string
  display_login: string
  global_relay_id: string
  id: number
  url: string
}

type AgentMentionType = 'timeline_comment' | 'single_comment_review' | 'review'

export type AgentMention = {
  type: AgentMentionType
  id: number
  global_relay_id: string
  pull_request_id: number
  body: string | null
  url: string
  created_at: string
  updated_at: string
  author: User
  path: string | null
  subject_type: string | null
  child_comments: number | null
  isPending: boolean
}

export function createPendingMention(body: string, currentUser?: PublicUser): AgentMention {
  const userLogin = currentUser?.login ?? 'You'
  return {
    type: 'timeline_comment',
    id: -1,
    global_relay_id: '',
    pull_request_id: 0,
    body,
    url: '',
    created_at: '',
    updated_at: '',
    author: {
      avatar_url:
        currentUser?.primaryAvatarUrl ?? `https://avatars.githubusercontent.com/${currentUser?.login ?? 'ghost'}`,
      display_login: userLogin,
      global_relay_id: '',
      id: 0,
      url: '',
    },
    path: null,
    subject_type: null,
    child_comments: null,
    isPending: true,
  }
}
