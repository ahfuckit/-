/**
 * The canonical slug for the default Copilot agent.
 * Used to determine if an agent is Copilot Coding Agent or not.
 */
export const COPILOT_AGENT_SLUG = 'copilot-swe-agent'

/**
 * Checks if an agent slug represents the default Copilot coding agent.
 * @param agentSlug - The slug of the agent to check
 * @returns true if the agent is the default Copilot coding agent
 */
export function isCopilotCodingAgent(agentSlug: string | undefined | null): boolean {
  return agentSlug === COPILOT_AGENT_SLUG
}

/**
 * Checks if the selected agent is Copilot or a custom agent (not a third-party agent).
 * Returns true for:
 * - Custom agents (no topLevelAgentId)
 * - Copilot coding agent
 * - SubAgents
 * @param selectedAgent - The currently selected agent
 * @param agentSlug - The slug of the top-level agent (from agentInfo)
 * @returns true if the agent is Copilot or a custom agent
 */
export function isCopilotOrCustomAgent(
  selectedAgent: {topLevelAgentId?: string | null; subAgentSlug?: string | null},
  agentSlug: string | undefined,
): boolean {
  return !selectedAgent.topLevelAgentId || isCopilotCodingAgent(agentSlug) || !!selectedAgent.subAgentSlug
}
