import {
  enableCopilotCodingAgentPolicy,
  removeCopilotCodingAgentRequest,
  requestCopilotCodingAgentAccess,
} from '@github-ui/copilot-member-feature-requests'
import {GitHubAvatar} from '@github-ui/github-avatar'
import {useClickAnalytics} from '@github-ui/use-analytics'
import {TriangleDownIcon} from '@primer/octicons-react'
import {Banner, ActionMenu, ActionList, registerPortalRoot} from '@primer/react'
import {useState, useRef, useCallback, useEffect, useId} from 'react'
import type {MemberRequestEnterprise, MemberRequestOrg} from '../../types/agent-tasks-app-payload'
import styles from './AgentsBlankslateBanner.module.css'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {UPGRADE_TO_PRO_PLAN_URL} from '@github-ui/copilot-chat/utils/copilot-chat-helpers'
import {buildEnterpriseCopilotCodingAgentPolicyUrl} from '../../utils/constants'

export type AccessRequestBannerProps = {
  enterprise?: MemberRequestEnterprise
  requestableOrgs: MemberRequestOrg[]
  adminableOrgs: MemberRequestOrg[]
}

export function AccessRequestBanner({enterprise, requestableOrgs, adminableOrgs}: AccessRequestBannerProps) {
  const isEnterpriseAdmin = !!enterprise?.isAdmin
  const isEnterpriseDisabled = !!enterprise?.policyDisabled
  const orgsCount = requestableOrgs.length + adminableOrgs.length
  const isSingleOrg = orgsCount === 1

  const requestedOrg = requestableOrgs.find(org => org.requestedAccess)
  const primaryOrg = adminableOrgs.length > 0 ? adminableOrgs[0] : requestableOrgs[0]
  const [currentOrg, setCurrentOrg] = useState(requestedOrg !== undefined ? requestedOrg : primaryOrg)

  const [isOrgAdmin, setIsOrgAdmin] = useState(currentOrg?.isAdmin || false)
  const [accessRequested, setAccessRequested] = useState(currentOrg?.requestedAccess || false)
  const [isRequesting, setIsRequesting] = useState(false)
  const [isEnabling, setIsEnabling] = useState(false)

  const [isError, setIsError] = useState(false)
  const [notice, setNotice] = useState<string | null>(null)

  const canEnableFeature = (isOrgAdmin && !isEnterpriseDisabled) || isEnterpriseAdmin
  const canOpenMenu = orgsCount > 1 && !isEnterpriseAdmin && !accessRequested

  const {sendClickAnalyticsEvent} = useClickAnalytics()

  const sendAgentAnalytics = useCallback(
    (action: string) => {
      sendClickAnalyticsEvent({
        category: 'member_feature_request',
        action: `action.copilot_coding_agent.${action}`,
        label: `ref_cta:${action};ref_loc:agents_blankslate;`,
      })
    },
    [sendClickAnalyticsEvent],
  )

  const handleAccess = useCallback(async () => {
    if (!currentOrg) return
    setIsError(false)
    setNotice(null)

    try {
      if (accessRequested) {
        await removeCopilotCodingAgentRequest(currentOrg.name)
        sendAgentAnalytics('request_removed')
      } else {
        await requestCopilotCodingAgentAccess(currentOrg.name)
        setNotice(`Request sent to ${currentOrg.name}.`)
        sendAgentAnalytics('request')
      }
      setAccessRequested(!accessRequested)
    } catch {
      setIsError(true)
      const errorMessage = `An error occurred while ${
        accessRequested ? 'removing' : 'sending'
      } your feature request. Please try again later.`
      setNotice(errorMessage)
    } finally {
      setIsRequesting(false)
    }
  }, [accessRequested, currentOrg, sendAgentAnalytics])

  useEffect(() => {
    if (isRequesting) {
      handleAccess()
    }
  }, [handleAccess, isRequesting])

  useEffect(() => {
    if (!isEnabling) return

    const enableFeature = async () => {
      try {
        if (enterprise && isEnterpriseAdmin) {
          sendAgentAnalytics('enterprise_enable')
          window.location.href = buildEnterpriseCopilotCodingAgentPolicyUrl(enterprise.name)
        } else if (currentOrg) {
          await enableCopilotCodingAgentPolicy(currentOrg.name)
          setNotice(`Feature enabled for ${currentOrg.name}. It may take a few minutes for changes to take effect.`)
          sendAgentAnalytics('org_enable')
        }
      } catch {
        setIsError(true)
        setNotice('An error occurred while enabling the feature. Please try again later.')
      }
    }
    enableFeature()
    // Disabling this lint rule because we only want to trigger this effect when isEnabling changes
    // and keep currentOrg and enterprise as they were when the enabling started.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEnabling, isEnterpriseAdmin, sendAgentAnalytics])

  const description =
    isSingleOrg && currentOrg && !isEnterpriseDisabled ? (
      <>
        Access to Copilot coding agent has been disabled by <span className="text-bold">{currentOrg.name}</span>.
      </>
    ) : (
      `Access to Copilot coding agent has been disabled by your ${
        isEnterpriseDisabled ? 'enterprise' : 'organizations'
      }.`
    )

  return (
    <>
      <Banner
        variant="warning"
        title="Copilot coding agent access request"
        hideTitle
        className={styles.banner}
        data-testid="agents-access-request-banner"
        primaryAction={
          <RequestAccessAction
            canOpenMenu={canOpenMenu}
            canEnableFeature={canEnableFeature}
            accessRequested={accessRequested}
            isEnabling={isEnabling}
            isRequesting={isRequesting}
            setIsEnabling={setIsEnabling}
            setIsRequesting={setIsRequesting}
            setIsOrgAdmin={setIsOrgAdmin}
            setCurrentOrg={setCurrentOrg}
            adminableOrgs={adminableOrgs}
            requestableOrgs={requestableOrgs}
            setNotice={setNotice}
          />
        }
      >
        <Banner.Description>{description}</Banner.Description>
      </Banner>
      {notice && (
        <span className={`${styles.notice} ${isError ? styles.error : ''}`} data-testid="access-request-notice">
          {notice}
        </span>
      )}
    </>
  )
}

type RequestAccessActionProps = {
  adminableOrgs: MemberRequestOrg[]
  requestableOrgs: MemberRequestOrg[]
  canOpenMenu: boolean
  canEnableFeature: boolean
  accessRequested: boolean
  isEnabling: boolean
  isRequesting: boolean
  setCurrentOrg: (org: MemberRequestOrg) => void
  setIsOrgAdmin: (isAdmin: boolean) => void
  setIsEnabling: (value: boolean) => void
  setIsRequesting: (value: boolean) => void
  setNotice: (notice: string | null) => void
}

// Note: Having this as a separate component is not ideal, but given the fact that the
// banner renders two identical buttons (leading action and trailing action) that need to share state but have
// different anchor refs for the ActionMenu overlay, this was the cleanest solution.
function RequestAccessAction({
  adminableOrgs,
  requestableOrgs,
  canOpenMenu,
  canEnableFeature,
  accessRequested,
  isEnabling,
  isRequesting,
  setCurrentOrg,
  setIsOrgAdmin,
  setIsEnabling,
  setIsRequesting,
  setNotice,
}: RequestAccessActionProps) {
  const [open, setOpen] = useState(false)
  const menuAnchorRef = useRef<HTMLButtonElement>(null)

  const handleOpen = () => {
    setNotice(null)
    setOpen(!open)
  }

  const handleClick = () => {
    if (canEnableFeature) {
      setIsEnabling(true)
    } else {
      setIsRequesting(true)
    }
  }

  // We need a portal for the ActionMenu overlay that is inside the primary
  // action div so the menu disappears correctly when the window is resized
  // We also need a unique id for the portal since each action instance
  // needs its own portal
  const containerRef = useRef<HTMLDivElement>(null)
  const id = useId()
  const portalName = `agents-access-banner-action-portal-${id}`
  useEffect(() => {
    if (containerRef.current) {
      registerPortalRoot(containerRef.current, portalName)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <>
      <Banner.PrimaryAction
        onClick={canOpenMenu ? handleOpen : handleClick}
        className={!canEnableFeature && accessRequested ? styles.removeAccessButton : ''}
        trailingAction={canOpenMenu ? TriangleDownIcon : undefined}
        inactive={isEnabling}
        loading={isRequesting}
        ref={menuAnchorRef}
      >
        {canEnableFeature ? 'Enable feature' : accessRequested ? 'Remove request' : 'Request access'}
      </Banner.PrimaryAction>

      <div ref={containerRef}>
        <ActionMenu open={open} onOpenChange={setOpen} anchorRef={menuAnchorRef}>
          <ActionMenu.Overlay align="end" portalContainerName={portalName} width="small">
            <ActionList>
              {adminableOrgs.length > 0 && (
                <ActionList.Group>
                  <ActionList.GroupHeading>Select organization to enable access</ActionList.GroupHeading>
                  <OrgActionList
                    orgs={adminableOrgs}
                    setCurrentOrg={setCurrentOrg}
                    setIsOrgAdmin={setIsOrgAdmin}
                    setStatus={setIsEnabling}
                  />
                </ActionList.Group>
              )}
              {requestableOrgs.length > 0 && adminableOrgs.length > 0 && <ActionList.Divider />}
              {requestableOrgs.length > 0 && (
                <ActionList.Group>
                  <ActionList.GroupHeading>Select organization to request access</ActionList.GroupHeading>
                  <OrgActionList
                    orgs={requestableOrgs}
                    setCurrentOrg={setCurrentOrg}
                    setIsOrgAdmin={setIsOrgAdmin}
                    setStatus={setIsRequesting}
                  />
                </ActionList.Group>
              )}
            </ActionList>
          </ActionMenu.Overlay>
        </ActionMenu>
      </div>
    </>
  )
}

type OrgActionListProps = {
  orgs: MemberRequestOrg[]
  setCurrentOrg: (org: MemberRequestOrg) => void
  setIsOrgAdmin: (isAdmin: boolean) => void
  setStatus: (value: boolean) => void
}

function OrgActionList({orgs, setCurrentOrg, setIsOrgAdmin, setStatus}: OrgActionListProps) {
  return orgs.map(org => (
    <ActionList.Item
      key={org.name}
      onSelect={() => {
        setCurrentOrg(org)
        setIsOrgAdmin(org.isAdmin)
        setStatus(true)
      }}
    >
      <ActionList.LeadingVisual>
        <GitHubAvatar src={org.avatarUrl} square />
      </ActionList.LeadingVisual>
      {org.name}
    </ActionList.Item>
  ))
}

export function AccessDisabledBanner() {
  return (
    <Banner
      variant="warning"
      title="Copilot coding agent access disabled"
      className={`${styles.banner} ${styles.basic}`}
      hideTitle
      data-testid="agents-access-disabled-banner"
    >
      <Banner.Description>Access to Copilot coding agent has been disabled by your administrator.</Banner.Description>
    </Banner>
  )
}

export type UpgradeBannerProps = {
  location?: 'agents_blankslate' | 'repo_agents_blankslate'
}

export function UpgradeBanner({location = 'agents_blankslate'}: UpgradeBannerProps) {
  const {sendClickAnalyticsEvent} = useClickAnalytics()

  const handleUpgradeClick = () => {
    sendClickAnalyticsEvent({
      category: 'copilot_upgrade',
      action: 'upgrade_plan',
      label: `ref_cta:upgrade;ref_loc:${location};`,
    })
  }

  return (
    <Banner
      variant="upsell"
      title="Copilot coding agent access unavailable for plan"
      className={`${styles.banner} ${styles.upsell}`}
      hideTitle
      primaryAction={
        <Banner.PrimaryAction as="a" href={UPGRADE_TO_PRO_PLAN_URL} onClick={handleUpgradeClick}>
          Start free trial
        </Banner.PrimaryAction>
      }
      data-testid="agents-upgrade-banner"
    >
      <Banner.Description>Available on paid plans. Try it with Copilot Pro — free for 30 days.</Banner.Description>
    </Banner>
  )
}
