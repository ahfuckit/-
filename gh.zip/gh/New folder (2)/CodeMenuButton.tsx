import {AnchoredOverlay, Button} from '@primer/react'
import type React from 'react'
import {useState} from 'react'
import {CodeIcon, TriangleDownIcon} from '@primer/octicons-react'
import {usePrefetchCodespacesQuery} from './use-codespaces-query'

export interface CodeMenuButtonProps {
  isPrimary: boolean
  children: React.ReactNode
  size?: 'small' | 'large' | 'medium'
  onOpenChange?: (open: boolean) => void
}

export const CodeMenuButton = ({isPrimary, children, size, onOpenChange}: CodeMenuButtonProps) => {
  const [showPopover, setShowPopover] = useState(false)
  const prefetch = usePrefetchCodespacesQuery()

  return (
    <AnchoredOverlay
      align="end"
      focusZoneSettings={{disabled: true}}
      open={showPopover}
      onOpen={() => {
        setShowPopover(true)
        onOpenChange?.(true)
      }}
      onClose={() => {
        setShowPopover(false)
        onOpenChange?.(false)
      }}
      renderAnchor={buttonProps => {
        return (
          <Button
            {...buttonProps}
            variant={isPrimary ? 'primary' : undefined}
            leadingVisual={() => <CodeIcon className="hide-sm" />}
            trailingVisual={() => <TriangleDownIcon />}
            size={size ? size : 'medium'}
            onMouseEnter={prefetch}
            onFocus={prefetch}
          >
            Code
          </Button>
        )
      }}
    >
      {children}
    </AnchoredOverlay>
  )
}
