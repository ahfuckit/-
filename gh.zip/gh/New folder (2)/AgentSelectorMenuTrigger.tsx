import {Button, SkeletonBox, type ButtonProps} from '@primer/react'
import {CopilotIcon, FileCheckIcon} from '@primer/octicons-react'
// eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-imports
import {IconButtonSelector} from '@github-ui/copilot-chat/components/IconButtonSelector'
import {GitHubAvatar} from '@github-ui/github-avatar'
import type {SubAgent} from '../../types/agent'
import type {AgentInfo} from '../../types/session'
import styles from './AgentSelector.module.css'
import {clsx} from 'clsx'

type AgentSelectorMenuTriggerProps = {
  isLoading: boolean
  isCopilotSelected: boolean
  selectedAgentObj: SubAgent | AgentInfo | undefined
  agentType: string | undefined
  ariaLabel: string
  disabled: boolean
  variant?: ButtonProps['variant']
  className?: string
}

export function renderAgentSelectorMenuTrigger({
  isLoading,
  isCopilotSelected,
  selectedAgentObj,
  agentType,
  ariaLabel,
  disabled,
  variant,
  className,
}: AgentSelectorMenuTriggerProps) {
  if (isLoading) {
    return (
      <Button
        aria-label="Loading agents"
        disabled
        variant={variant}
        className={clsx(styles.avatarButtonSkeleton, className)}
      >
        <SkeletonBox width="32px" height="32px" data-testid="agent-selector-skeleton" />
      </Button>
    )
  }
  // Special case for Copilot to use icon instead of avatar - This allows Copilot to change with dark mode
  if (isCopilotSelected) {
    return (
      <IconButtonSelector
        icon={CopilotIcon}
        selectedIcon={CopilotIcon}
        aria-label={ariaLabel}
        selected={false}
        disabled={disabled}
        variant={variant}
        className={className}
      />
    )
  }
  // custom agent with file check icon
  if (selectedAgentObj && typeof selectedAgentObj === 'object' && agentType === 'customSubAgent') {
    return (
      <IconButtonSelector
        icon={CopilotIcon}
        selectedIcon={FileCheckIcon}
        aria-label={ariaLabel}
        selected={Boolean(selectedAgentObj)}
        disabled={disabled}
        variant={variant}
        className={className}
      />
    )
  }
  // 3rd-party agent with avatar
  if (selectedAgentObj && typeof selectedAgentObj === 'object' && 'avatar_url' in selectedAgentObj) {
    return (
      <Button
        aria-label={ariaLabel}
        disabled={disabled || isLoading}
        variant={variant}
        className={clsx(styles.avatarButton, className)}
      >
        <GitHubAvatar src={selectedAgentObj.avatar_url} size={18} square />
      </Button>
    )
  }
  // Fallback for any other case (e.g., topLevel agent without avatar_url - this should never happen)
  return (
    <IconButtonSelector
      icon={CopilotIcon}
      selectedIcon={FileCheckIcon}
      aria-label={ariaLabel}
      selected={Boolean(selectedAgentObj)}
      disabled={disabled}
      variant={variant}
      className={className}
    />
  )
}
