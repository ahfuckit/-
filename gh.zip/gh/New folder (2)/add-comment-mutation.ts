import {md2html} from '@github-ui/md2html'
import {commitMutation, graphql} from 'react-relay'
import type {Environment} from 'relay-runtime'

import type {
  AddCommentInput,
  addCommentMutation,
  addCommentMutation$rawResponse,
  CommentAuthorAssociation,
} from './__generated__/addCommentMutation.graphql'

type optimisticInput = {
  repositoryId: string
  authorAssociation: CommentAuthorAssociation
  commentAuthor: {
    id: string
    login: string
    name?: string | null
    avatarUrl: string
  }
}

type AddCommentIssueRepository = Extract<
  NonNullable<NonNullable<addCommentMutation$rawResponse['addComment']>['timelineEdge']>['node'],
  {__typename: 'IssueComment'}
>['repository']

type AddCommentIssue = Extract<
  NonNullable<NonNullable<addCommentMutation$rawResponse['addComment']>['timelineEdge']>['node'],
  {__typename: 'IssueComment'}
>['issue']

function getOptimisticResponse(
  optimisticInput: optimisticInput | undefined,
  withOptimisticResponse: boolean,
  body: string,
  subject: string,
  environment: Environment,
): addCommentMutation$rawResponse | undefined {
  if (!optimisticInput || !withOptimisticResponse) {
    return undefined
  }
  // Read data from Relay store if needed for optimistic response
  // You can access the store like this:
  const store = environment.getStore().getSource()
  const repositoryRecord = store.get(optimisticInput.repositoryId)
  const issueRecord = store.get(subject)

  if (!repositoryRecord || !issueRecord) {
    return undefined
  }

  const repository = repositoryRecord as AddCommentIssueRepository
  const issue = issueRecord as AddCommentIssue
  const ownerRef = repository.owner as unknown as {__ref: string} | undefined
  const authorRef = issue.author as unknown as {__ref: string} | undefined

  const ownerRecord = ownerRef ? store.get(ownerRef.__ref) : undefined
  const authorRecord = authorRef ? store.get(authorRef.__ref) : undefined
  if (!ownerRecord || !authorRecord) {
    return undefined
  }
  const owner = ownerRecord as typeof repository.owner
  const author = authorRecord as typeof issue.author
  if (!owner || !author) {
    return undefined
  }

  return withOptimisticResponse && optimisticInput
    ? {
        addComment: {
          timelineEdge: {
            node: {
              __typename: 'IssueComment',
              __isComment: 'IssueComment',
              __isNode: 'IssueComment',
              __isReactable: 'IssueComment',
              id: `temp-comment-${Date.now()}`, // Temporary ID for optimistic update
              body: body ? body : '',
              bodyHTML: md2html(body),
              bodyVersion: '1', // Initial version, will be updated on server
              createdAt: new Date().toISOString(),
              lastEditedAt: null,
              viewerCanReadUserContentEdits: true,
              lastUserContentEdit: null,
              // Add other required fields with default/null values
              author: {
                __typename: 'User',
                id: optimisticInput.commentAuthor.id,
                avatarUrl: optimisticInput.commentAuthor.avatarUrl,
                login: optimisticInput.commentAuthor.login,
                name: optimisticInput.commentAuthor.name,
              },
              authorAssociation: optimisticInput.authorAssociation,
              authorToRepoOwnerSponsorship: null,
              createdViaEmail: false,
              viaApp: null,
              databaseId: null,
              isHidden: false,
              issue: {
                id: subject,
                databaseId: issue.databaseId,
                locked: issue.locked,
                number: issue.number,
                author: {
                  __typename: author.__typename,
                  id: author.id,
                  login: author.login,
                },
              },
              minimizedReason: null,
              pendingMinimizeReason: null,
              pendingBlock: null,
              pendingUnblock: null,
              reactionGroups: [],
              repository: {
                id: repository.id,
                databaseId: repository.databaseId,
                isPrivate: repository.isPrivate,
                name: repository.name,
                nameWithOwner: repository.nameWithOwner,
                slashCommandsEnabled: repository.slashCommandsEnabled,
                owner: {
                  __typename: owner.__typename,
                  id: owner.id,
                  login: owner.login,
                  url: owner.url,
                },
              },
              showSpammyBadge: false,
              url: '',
              viewerCanBlockFromOrg: false,
              viewerCanDelete: false,
              viewerCanMinimize: false,
              viewerCanUnminimize: false,
              viewerCanReport: false,
              viewerCanReportToMaintainer: false,
              viewerCanUnblockFromOrg: false,
              viewerCanUpdate: false,
              viewerDidAuthor: true,
              viewerCanPin: false,
              viewerCanUnpin: false,
              pinnedBy: null,
            },
          },
          subject: {
            __typename: 'Issue',
            id: subject,
          },
        },
      }
    : undefined
}

export function addCommentMutation({
  environment,
  input: {subject, body, connectionId},
  onError,
  onCompleted,
  withOptimisticResponse = false,
  optimisticInput,
}: {
  environment: Environment
  input: {
    subject: string
    body: string
    connectionId: string
  }
  onError?: (error?: Error) => void
  onCompleted?: () => void
  optimisticInput?: optimisticInput
  withOptimisticResponse?: boolean
}) {
  const inputHash: AddCommentInput = {
    subjectId: subject,
    body: body ? body : '',
  }

  return commitMutation<addCommentMutation>(environment, {
    // eslint-disable-next-line @github-ui/github-monorepo/restrict-relay-queries
    mutation: graphql`
      mutation addCommentMutation($connections: [ID!]!, $input: AddCommentInput!) @raw_response_type {
        addComment(input: $input) {
          timelineEdge @appendEdge(connections: $connections) {
            node {
              ...IssueCommentViewerCommentRow @dangerously_unaliased_fixme
              ...IssueComment_issueComment @dangerously_unaliased_fixme
            }
          }
          subject {
            id
          }
        }
      }
    `,
    optimisticResponse: getOptimisticResponse(optimisticInput, withOptimisticResponse, body, subject, environment),
    variables: {
      input: inputHash,
      connections: [connectionId],
    },
    onError: error => onError && onError(error),
    onCompleted: response => {
      if (!response.addComment) {
        onError?.()
      } else {
        onCompleted?.()
      }
    },
  })
}
