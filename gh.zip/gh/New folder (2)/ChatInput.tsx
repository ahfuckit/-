import type {SelectedAgent} from '@github-ui/agent-sessions/types/session'
import {useSpaceSelection} from '@github-ui/copilot-spaces/hooks/use-space-selection'
import {sendEvent} from '@github-ui/hydro-analytics'
import {testIdProps} from '@github-ui/test-id-props'
import type {CommandId} from '@github-ui/ui-commands'
import {CommandButton, CommandIconButton, ScopedCommands} from '@github-ui/ui-commands'
import {useNavigate} from '@github-ui/use-navigate'
import {useSyntheticChange} from '@github-ui/use-synthetic-change'
import type {AnchorSide} from '@primer/behaviors'
import {PaperAirplaneIcon, PlusIcon, RocketIcon, SquareFillIcon, TriangleDownIcon} from '@primer/octicons-react'
import {
  ActionList,
  ActionMenu,
  Button,
  IconButton,
  Label,
  Spinner,
  useResponsiveValue,
  useSafeTimeout,
} from '@primer/react'
import {clsx} from 'clsx'
import type {RefObject} from 'react'
import {memo, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState} from 'react'

import {useOverlayDirection} from '../contexts/OverlayDirectionContext'
import {useAddMentionReferences} from '../hooks/use-add-mention-references'
import {useAddUrlReferences} from '../hooks/use-add-url-references'
import {type AvailableCommand, useAvailableCommands} from '../hooks/use-available-commands'
import {isTaskCommand, useChatInput} from '../hooks/use-chat-input'
import {isIncompleteSlashCommand} from '../utils/chat-commands-helpers'
import {copilotChatTextAreaId} from '../utils/constants'
import {referencesAreEqual} from '../utils/copilot-chat-helpers'
import {
  type CopilotChatCommandType,
  type CopilotChatReference,
  type CopilotChatRepo,
  type ImageReference,
  type ModeSupport,
  ModeSupportName,
  type ThreadScopedFileReference,
} from '../utils/copilot-chat-types'
import {copilotFeatureFlags} from '../utils/copilot-feature-flags'
import {CopilotImageAttacher} from '../utils/copilot-image-attacher'
import {sendVisionErrorEvent} from '../utils/copilot-image-helpers'
import {copilotLocalStorage, type SavedMessageSource} from '../utils/copilot-local-storage'
import {CLIPBOARD_MIME_TYPE, CopilotTextAttacher} from '../utils/copilot-text-attacher'
import {useChatStateValues} from '../utils/CopilotChatContext'
import {useChatManager} from '../utils/CopilotChatManagerContext'
import {useIsCopilotSpacePath} from '../utils/custom-copilots-helpers'
import {useGetChatState} from '../utils/ObservableChatContext'
import {AttachmentMenu} from './AttachmentMenu'
import type {AttachmentMenuPanelType} from './AttachmentMenuPanelType'
import {ChatInputAutocomplete} from './autocomplete/ChatInputAutocomplete'
import styles from './ChatInput.module.css'
import {ChatInputPreview} from './ChatInputPreview'
import {ChatInputReferences} from './ChatInputReferences'
import {ChatReposPicker} from './ChatReposPicker'
import {FullScreenDragOverlay} from './FullScreenDragOverlay'
import {ModelPicker} from './ModelPicker'
import {COPILOT_CHAT_MENU_PORTAL_ROOT} from './PortalContainerUtils'
import {TaskChatInputToolbar} from './task-chat-input-toolbar/TaskChatInputToolbar'

/** When the user pastes text that is longer than this many characters, we will automatically convert it to a file. */
const PASTE_TEXT_AS_FILE_THRESHOLD = 1000

const LIMITED_KEYBINDING_COMMAND_IDS: CommandId[] = [
  'github:cancel',
  'copilot-chat:send-message',
  'copilot-chat:edit-last-message',
]

const START_TASK_BUTTON_TEXT = 'Start task'

export type ChatInputRef = {
  setText: React.Dispatch<React.SetStateAction<string>>
}

export interface ChatInputProps {
  className?: string
  disableAutoFocus?: boolean
  textAreaRef?: React.RefObject<HTMLTextAreaElement | null>
  chatInputRef?: React.RefObject<ChatInputRef | null>
  containerRef?: React.RefObject<HTMLFormElement | null>
  onSubmit?: (text: string, additionalReferences?: CopilotChatReference[]) => Promise<void>
  isStreaming?: boolean
  activeModeName?: string
  modes: [ModeSupport, ...ModeSupport[]]
  onClickMode?: (modeName: string) => void
  size?: 'small' | 'large'
  onSelectReference?: (reference: CopilotChatReference, event?: React.MouseEvent<HTMLAnchorElement>) => void
  onNewThreadSelected?: () => Promise<void>
  getReferenceVersion?: (reference: CopilotChatReference) => number | undefined
  /** Set of previously generated/referenced file names in this thread, to use as a reference for generating new file names. */
  existingFileNames?: Set<string>
  disabled?: boolean
  submitDisabled?: boolean
  figmaAuthUrl?: string
  extraToolbar?: React.ReactNode
  initialReference?: CopilotChatReference
  onRemoveReference?: (reference: CopilotChatReference) => void
  isNewConversation?: boolean
  onChatCommandChange?: (command: CopilotChatCommandType | null) => void
  /** Set to true when rendered in a Portal to handle height issues */
  isInPortal?: boolean
  shouldSubmitWithModifier?: boolean
  shouldClearTextOnCommandSubmit?: boolean
  shouldClearTextOnSubmit?: boolean
  slashCommandsEnabled?: boolean
  attachmentMenuSide?: AnchorSide
  storageKeySuffix?: string
  showStartTaskButton?: boolean
  customModelPicker?: (props: {selectedAgent?: SelectedAgent; iconOnly?: boolean}) => React.ReactNode
  initialText?: string
  /** Force icon-only mode in the toolbar, useful for container-based responsive behavior */
  forceIconOnly?: boolean
  /** Maximum height for the textarea input in pixels. Overrides the default MAX_HEIGHT. */
  maxTextareaHeight?: number
  /** Maximum character length for the prompt. When set, enforces the limit using the maxLength attribute. */
  maxPromptLength?: number
  /** Source of the saved message, used to differentiate messages from different experiences */
  source?: SavedMessageSource
  /**
   * Optional custom paste handler. When provided, replaces the default paste handling
   * entirely (including text-to-file conversion and URL reference replacement).
   */
  onPaste?: React.ClipboardEventHandler<HTMLTextAreaElement>
  /**
   * Optional drag event handlers to spread onto the form element for inline
   * drag-and-drop support (e.g. image drops scoped to the input area).
   */
  dropTargetProps?: {
    onDragEnter: React.DragEventHandler
    onDragOver: React.DragEventHandler
    onDragLeave: React.DragEventHandler
    onDrop: React.DragEventHandler
  }
  /**
   * Optional callback invoked whenever the textarea text changes.
   * Useful for parent components that need to observe the input text without controlling it.
   */
  onTextChange?: (text: string) => void
}

export const ChatInput = (props: ChatInputProps) => {
  const state = useChatStateValues(
    'defaultRecipient',
    'isWaitingOnAttachment',
    'attachmentProcessingType',
    'isWaitingOnCopilot',
    'messages',
    'mode',
    'model',
    'selectedThreadID',
    'skillOptions',
    'slashCommandLoading',
  )
  const {model} = state
  const getChatState = useGetChatState()
  const manager = useChatManager()
  const maxMessagesReached = manager.maxMessagesReached()
  const [pastedFile, setPastedFile] = useState<File | null>(null)
  const slashCommandLoading = state.slashCommandLoading.state === 'loading'
  const {safeSetTimeout} = useSafeTimeout()
  const {
    onSelectReference,
    containerRef,
    shouldClearTextOnCommandSubmit = true,
    shouldClearTextOnSubmit = true,
    slashCommandsEnabled = false,
    shouldSubmitWithModifier = false,
    extraToolbar,
  } = props
  const pastedFileNamePromise = useRef<Promise<string> | null>(null)
  const pastedFileName = useRef<string>('')
  const convertToFileShownLogged = useRef(false)
  const navigate = useNavigate()
  const {availableCommands, availableCommandKeys} = useAvailableCommands({enabled: slashCommandsEnabled})
  const commandModes = availableCommands.map(cmd => cmd.mode).filter((mode): mode is ModeSupport => mode !== undefined)
  const chatModes = copilotFeatureFlags.askModeDropdown && commandModes.length > 0 ? commandModes : props.modes

  const [activeMode, setActiveMode] = useState<ModeSupport>(() => {
    if (props.activeModeName) {
      const activeModeFromProps = chatModes.find(m => m.name === props.activeModeName)
      if (activeModeFromProps) return activeModeFromProps
    }
    const savedModeName = copilotLocalStorage.getActiveMode()
    if (savedModeName) {
      const savedMode = chatModes.find(m => m.name === savedModeName)
      if (savedMode) return savedMode
    }
    return chatModes[0]!
  })

  const onModeSelect = useCallback(
    (mode: ModeSupport, autoComplete?: boolean) => {
      props.onClickMode?.(mode.name)
      if (!props.activeModeName) {
        setActiveMode(mode)
      }
      copilotLocalStorage.setActiveMode(mode.name)
      sendEvent('dotcom_chat.activate', {
        target: 'MODE_SWITCH',
        mode: mode.name,
        autoComplete,
      })
    },
    [props],
  )

  // Use custom hook to manage space selection logic
  const {activeCopilotSpaceId} = useSpaceSelection()

  const currentMode = copilotFeatureFlags.askModeDropdown
    ? activeMode
    : chatModes.find(m => m.name === props.activeModeName) || chatModes[0]!

  const onClickMode = useCallback(
    (modeName: string) => {
      if (copilotFeatureFlags.askModeDropdown) {
        const mode = chatModes.find(m => m?.name === modeName)
        if (mode) {
          onModeSelect(mode)
        }
      }
    },
    [chatModes, onModeSelect],
  )

  const addedInitialReference = useRef<CopilotChatReference | undefined>(undefined)

  // Add initial reference to manager
  useEffect(() => {
    if (!props.initialReference) return
    if (referencesAreEqual(addedInitialReference.current, props.initialReference)) return
    manager.addReference(props.initialReference, 'page-file-reference')
    addedInitialReference.current = props.initialReference
  }, [props.initialReference, manager])

  // Update activeMode when activeModeName prop changes
  useEffect(() => {
    if (props.activeModeName) {
      const modeFromProps = chatModes.find(m => m.name === props.activeModeName)
      if (modeFromProps && modeFromProps !== activeMode) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setActiveMode(modeFromProps)
      }
    }
  }, [props.activeModeName, chatModes, activeMode])

  // Update activeMode when modes array changes to ensure we have the latest mode object
  useEffect(() => {
    const updatedMode = chatModes.find(m => m.name === activeMode.name)
    if (updatedMode && updatedMode !== activeMode) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setActiveMode(updatedMode)
    }
  }, [chatModes, activeMode])

  const clearPastedFile = useCallback(
    (logDismiss = false) => {
      pastedFileNamePromise.current = null
      pastedFileName.current = ''
      convertToFileShownLogged.current = false
      if (pastedFile) {
        setPastedFile(null)
        if (logDismiss) {
          sendEvent('dotcom_chat.activate', {target: 'CONVERT_TO_FILE_DISMISS', mode: state.mode})
        }
      }
    },
    [pastedFile, state.mode],
  )

  const {
    typingHasStarted,
    textAreaRef,
    textareaPreviewRef,
    textAreaPreviewContainerRef,
    text,
    setText,
    isAgentTaskSubmitInProgress,
    handleSubmit,
    handleSubmitToNewThread,
    handleScroll,
    handleChange,
    handleStop,
    handleFocus,
    command,
    setLastUsedRepo,
    // agent tasks
    selectedRepo,
    setSelectedRepo,
    selectedBranch,
    setSelectedBranch,
    selectedAgent,
    setSelectedAgent,
    initialRepoNWO,
  } = useChatInput({
    isLoading: state.isWaitingOnCopilot || state.isWaitingOnAttachment || slashCommandLoading,
    onSubmit: props.onSubmit,
    textAreaRef: props.textAreaRef,
    clearPastedFile,
    onChatCommandChange: props.onChatCommandChange,
    isInPortal: props.isInPortal,
    shouldClearTextOnCommandSubmit,
    shouldClearTextOnSubmit,
    availableCommands,
    activeModeName: currentMode?.name,
    storageKeySuffix: props.storageKeySuffix,
    initialText: props.initialText,
    maxTextareaHeight: props.maxTextareaHeight,
    source: props.source,
  })

  // Handle /task command auto-switch
  useEffect(() => {
    if (text.startsWith('/task ') && copilotFeatureFlags.askModeDropdown) {
      const taskCommand = availableCommands.find(cmd => cmd.key === 'task')
      if (taskCommand?.mode && taskCommand.mode !== activeMode) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        onModeSelect(taskCommand.mode, true)
        setText(text.slice(6)) // Remove '/task ' from the beginning
      }
    }
  }, [text, availableCommands, activeMode, setText, onModeSelect])

  // Notify parent when text changes
  const {onTextChange} = props
  useEffect(() => {
    onTextChange?.(text)
  }, [text, onTextChange])

  // Get custom model picker from the active slash command if available, or use the prop
  const activeCommand = useMemo(
    () => availableCommands.find(cmd => cmd.key === command || cmd.mode?.name === activeMode.name),
    [availableCommands, command, activeMode],
  )
  const customModelPicker = activeCommand?.customModelPicker ?? props.customModelPicker

  const disabled = props.disabled || isAgentTaskSubmitInProgress || maxMessagesReached

  useImperativeHandle(props.chatInputRef, () => ({setText}) satisfies ChatInputRef, [setText])

  const emitChange = useSyntheticChange({inputRef: textAreaRef, fallbackEventHandler: handleChange})
  const {replaceUrlWithReferenceMention} = useAddUrlReferences({
    figmaAuthUrl: props.figmaAuthUrl,
    textAreaRef,
    emitChange,
  })
  const {
    isLoading: mentionReferencesPending,
    addReferenceForMention,
    addReferencesForMentions,
  } = useAddMentionReferences()
  const isCopilotSpacePath = useIsCopilotSpacePath()
  const isCopilotSpacePage = activeCopilotSpaceId && isCopilotSpacePath
  const preferredOverlaySide = useOverlayDirection()

  // Check if the current text is an incomplete slash command (memoized to avoid duplicate computation)
  const isIncompleteCommand = useMemo(() => isIncompleteSlashCommand(text, command), [text, command])
  const isTask = isTaskCommand(activeMode?.name, command)

  const submitDisabled =
    slashCommandLoading ||
    mentionReferencesPending ||
    state.isWaitingOnAttachment ||
    !!props.submitDisabled ||
    (isTask && commandModes.includes(currentMode) && !selectedRepo && !selectedBranch) ||
    isAgentTaskSubmitInProgress ||
    isIncompleteCommand

  const textAreaEmpty = text.length === 0

  const stopResponse = useCallback(() => {
    sendEvent('dotcom_chat.activate', {target: 'CHAT_MESSAGE_STOP', mode: state.mode})
    void handleStop()
  }, [handleStop, state.mode])

  const sendMessage = useCallback(() => {
    if (submitDisabled) return
    const spaceIdString = activeCopilotSpaceId ? `${activeCopilotSpaceId.owner}/${activeCopilotSpaceId.id}` : ''
    sendEvent('dotcom_chat.activate', {
      target: 'CHAT_MESSAGE_SUBMIT',
      mode: state.mode,
      selectedThreadId: state.selectedThreadID,
      copilotSpace: spaceIdString,
      fromSpaceUI: isCopilotSpacePath,
      askModeDropdown: copilotFeatureFlags.askModeDropdown,
      activeMode: currentMode.name,
    })

    if (pastedFile) {
      clearPastedFile(false)
    }
    void handleSubmit()
  }, [
    submitDisabled,
    activeCopilotSpaceId,
    state.mode,
    state.selectedThreadID,
    isCopilotSpacePath,
    currentMode.name,
    pastedFile,
    handleSubmit,
    clearPastedFile,
  ])

  const sendMessageToNewThread = useCallback(() => {
    if (submitDisabled) return

    void handleSubmitToNewThread()
  }, [handleSubmitToNewThread, submitDisabled])

  const editLastMessage = useCallback(() => {
    const id = state.messages.findLast(m => m.role === 'user')?.id
    if (id) manager.startEditingMessage(id)
  }, [manager, state.messages])

  const placeholderText = (() => {
    if (state.isWaitingOnCopilot) return 'Copilot is responding…'
    if (state.defaultRecipient) return undefined
    if (maxMessagesReached) return 'Message limit reached. To continue chatting with Copilot, start a new conversation.'
    return currentMode.placeholder ?? 'Ask anything'
  })()

  if (state.defaultRecipient && text === '' && !typingHasStarted) {
    setText(`@${state.defaultRecipient} `)
  }

  const attachmentButtonRef = useRef<HTMLButtonElement>(null)

  const [attachmentMenuPanel, setAttachmentMenuPanel] = useState<AttachmentMenuPanelType | null>(null)
  const [lastAttachedRepo, setLastAttachedRepo] = useState<CopilotChatRepo | null>(null)
  const addAttachment = useCallback(() => {
    sendEvent('dotcom_chat.activate', {target: 'ATTACHMENT_MENU', mode: state.mode})
    setAttachmentMenuPanel(panel => (panel === 'attachment-types' ? null : 'attachment-types'))
  }, [state.mode, setAttachmentMenuPanel])

  const setDeepCodeSearch = useCallback(() => {
    sendEvent('dotcom_chat.activate', {target: 'DEEP_CODESEARCH', mode: state.mode})
    manager.dispatch({type: 'SET_DEEP_CODESEARCH', deepCodeSearch: !state.skillOptions?.deepCodeSearch})
  }, [manager, state.mode, state.skillOptions?.deepCodeSearch])

  // For now, we are focused on building out image support in immersive mode only, and only for supported models.
  const shouldShowImages = (state.mode === 'immersive' && !!model.capabilities?.supports?.vision) || false

  const handleFileAttachment = useCallback(
    async (files: Iterable<File>, uploadType: 'drag' | 'paste', namePromise?: Promise<string>, name?: string) => {
      const imageAttacher = new CopilotImageAttacher(getChatState(), manager)
      const textAttacher = new CopilotTextAttacher(manager, props.existingFileNames)
      const attachedFiles: Array<ThreadScopedFileReference | ImageReference> = []

      const hasImageFiles = [...files].some(file => file.type.startsWith('image/'))
      if (hasImageFiles && !model.capabilities?.supports?.vision) {
        manager.addAmbientError(
          `The ${model.displayName} model doesn't support answering questions about images. Select a different model and try again.`,
        )
        sendVisionErrorEvent('vision_not_supported_for_model', {
          modelId: model.id,
          uploadType,
        })
      }

      // Split the image files out of the other files so we can handle them separately.
      const [imageFiles, otherFiles] = CopilotImageAttacher.getAllowedFiles([...files], model)

      if (shouldShowImages) {
        const imageAttachments = await imageAttacher.addImageAttachments(imageFiles, uploadType)
        if (imageAttachments) attachedFiles.push(...imageAttachments)
      }

      const disallowedFileTypes = []
      for (const file of otherFiles) {
        if (await CopilotTextAttacher.isAttachable(file)) {
          const attachedFile = await textAttacher.addAttachment(file, namePromise, name)
          if (attachedFile) attachedFiles.push(attachedFile)
        } else disallowedFileTypes.push(file.type)
      }

      if (shouldShowImages && disallowedFileTypes.length > 0) {
        sendVisionErrorEvent('included_unsupported_file', {
          fileTypes: disallowedFileTypes.join(','),
          uploadType,
        })
      }
      return attachedFiles
    },
    [shouldShowImages, model, getChatState, manager, props.existingFileNames],
  )

  const handleConvertToFile = useCallback(async () => {
    if (!pastedFile) return
    const fileArray = [pastedFile]
    const attachments = await handleFileAttachment(
      fileArray,
      'paste',
      pastedFileNamePromise.current || undefined,
      pastedFileName.current,
    )
    if (attachments.length > 0 && attachments[0]?.type === 'thread-scoped-file') {
      const pastedText = await pastedFile.text()
      const newText = text.replaceAll(pastedText, `@${attachments[0].name}`)
      setText(newText)
      clearPastedFile(false)
      sendEvent('dotcom_chat.activate', {target: 'CONVERT_TO_FILE_CONVERT', mode: state.mode})
    }
  }, [pastedFile, handleFileAttachment, state.mode, text, setText, clearPastedFile])

  const handleConvertToFileDismiss = useCallback(() => {
    clearPastedFile(true)
  }, [clearPastedFile])

  // Log when the convert attachment is shown
  useEffect(() => {
    if (pastedFile && !state.isWaitingOnAttachment && !convertToFileShownLogged.current) {
      convertToFileShownLogged.current = true
      sendEvent('dotcom_chat.activate', {target: 'CONVERT_TO_FILE_TRIGGER', mode: state.mode})
    }
  }, [pastedFile, state.isWaitingOnAttachment, state.mode])

  const supportsReferenceAttachments = (currentMode.supportsReferenceAttachments ?? true) && command !== 'task'
  const supportedReferenceTypes = currentMode.supportedReferenceTypes

  const handlePaste: React.ClipboardEventHandler<HTMLTextAreaElement> = useCallback(
    event => {
      const clipboardData = event.clipboardData
      if (!clipboardData?.items) return

      const fileArray: File[] = []

      // Batch DOM reads by converting to array first
      const items = Array.from(clipboardData.items)

      for (const item of items) {
        if (item.kind === 'file') {
          const file = item.getAsFile()
          if (file) fileArray.push(file)
        } else if (
          item.kind === 'string' &&
          ['text', 'text/plain'].includes(item.type) // "text" for tests, "text/plain" for real clipboard
        ) {
          const pastedText = clipboardData.getData(item.type)

          if (
            pastedText.length > PASTE_TEXT_AS_FILE_THRESHOLD &&
            pastedText.length <= CopilotTextAttacher.getAttachmentSizeLimit()
          ) {
            // Run after the input value updates.
            safeSetTimeout(() => {
              convertToFileShownLogged.current = false

              const file = new File([pastedText], '', {type: CLIPBOARD_MIME_TYPE})
              const textAttacher = new CopilotTextAttacher(manager, props.existingFileNames)
              setPastedFile(file)
              const namePromise = textAttacher
                .generateFileName(pastedText, file.type)
                // eslint-disable-next-line github/no-then
                .then(name => (pastedFileName.current = name))
              pastedFileNamePromise.current = namePromise
            }, 0) // Use 0 instead of 1 for immediate scheduling
          } else if (supportsReferenceAttachments) {
            addReferencesForMentions(pastedText, supportedReferenceTypes)

            const insertionIndex = textAreaRef.current?.selectionStart ?? 0
            // After the paste completes, process the pasted text for URLs. Doing it this way (as opposed to preventing
            // the paste and setting the value synchronously) preserves the undo stack, allowing users to undo the
            // URL replacing if they want
            setTimeout(() =>
              replaceUrlWithReferenceMention(
                [insertionIndex, insertionIndex + pastedText.length],
                supportedReferenceTypes,
              ),
            )
          }
          return
        }
      }

      if (fileArray.length > 0) {
        event.preventDefault()
        void handleFileAttachment(fileArray, 'paste')
      }
    },
    [
      safeSetTimeout,
      manager,
      props.existingFileNames,
      supportsReferenceAttachments,
      supportedReferenceTypes,
      addReferencesForMentions,
      textAreaRef,
      replaceUrlWithReferenceMention,
      handleFileAttachment,
    ],
  )

  const handleFileDrop = useCallback(
    (files: FileList) => {
      void handleFileAttachment(files, 'drag')
    },
    [handleFileAttachment],
  )

  const onRepoAttach = useCallback(
    (repo: CopilotChatRepo | null) => {
      if (repo) {
        setLastUsedRepo(repo)
      }
      // Set last attached repo for multifile attach dialog, or clear out if null.
      setLastAttachedRepo(repo)
    },
    [setLastUsedRepo, setLastAttachedRepo],
  )

  const onCommandAutoComplete = useCallback(
    (commandKey: CopilotChatCommandType) => {
      const selectedCommand = availableCommands.find(cmd => cmd.key === commandKey)
      if (selectedCommand?.enabled?.() === false && selectedCommand.disabledAction) {
        selectedCommand.disabledAction(navigate)
        return
      }
      if (copilotFeatureFlags.askModeDropdown) {
        if (selectedCommand?.mode) {
          onModeSelect(selectedCommand.mode, true)

          // Clear the slash command text from the input
          const commandPattern = new RegExp(`^/${commandKey}\\s*`)
          if (commandPattern.test(text)) {
            setText(text.replace(commandPattern, ''))
          }
        } else if (activeMode.name !== ModeSupportName.Ask) {
          // Switch back to Ask mode if the selected command has no associated mode
          const askMode = chatModes.find(m => m.name === ModeSupportName.Ask)
          if (askMode) {
            onModeSelect(askMode, true)
          }
        }
      }
    },
    [availableCommands, navigate, activeMode.name, onModeSelect, text, setText, chatModes],
  )

  const stoppable = props.isStreaming || state.isWaitingOnCopilot
  const supportsAttachments = Boolean(currentMode.supportsAttachments) && command !== 'task'

  return (
    <div className={styles.container}>
      <ScopedCommands
        commands={useMemo(
          () => ({
            // avoid hijacking the escape key unless there is some streaming to cancel
            'github:cancel': stoppable ? stopResponse : undefined,
            // When shouldSubmitWithModifier is true, use Mod+Enter; otherwise use Enter
            'copilot-chat:send-message': shouldSubmitWithModifier ? undefined : sendMessage,
            'github:submit-form': sendMessage,
            'copilot-chat:send-message-new-conversation': sendMessageToNewThread,
            'copilot-chat:add-attachment': addAttachment,
            'copilot-chat:edit-last-message': textAreaEmpty ? editLastMessage : undefined,
            'copilot-chat:deep-codesearch': setDeepCodeSearch,
          }),
          [
            addAttachment,
            editLastMessage,
            sendMessage,
            sendMessageToNewThread,
            setDeepCodeSearch,
            shouldSubmitWithModifier,
            stopResponse,
            stoppable,
            textAreaEmpty,
          ],
        )}
      >
        <form
          className={clsx(
            styles.chatForm,
            {
              [styles.containerSmall]: props.size === 'small', // Only used by assistive now
              [styles.containerDisabled]: disabled,
            },
            props.className,
          )}
          ref={containerRef}
          {...testIdProps('copilot-chat-input-form')}
          {...props.dropTargetProps}
        >
          {supportsReferenceAttachments && (
            <ChatInputReferences
              className={styles.attachments}
              returnFocusRef={attachmentButtonRef}
              tokenSize={props.size === 'small' ? 'small' : 'medium'}
              isLoading={mentionReferencesPending}
              onSelectReference={onSelectReference}
              onRemoveReference={props.onRemoveReference}
              getReferenceVersion={props.getReferenceVersion}
              showConvertToFileText={!!pastedFile && !state.isWaitingOnAttachment}
              onConvertToFile={handleConvertToFile}
              onConvertToFileDismiss={handleConvertToFileDismiss}
              hideAttachmentsMenu={!!props.initialReference || currentMode.supportsAttachmentsMenu === false}
              referenceTypeFilter={supportedReferenceTypes}
            />
          )}

          <ScopedCommands.LimitKeybindingScope
            // The default bindings for these are 'escape' and 'enter', so we need to strictly limit scope to avoid
            // breaking all the menu and button functionalities that rely on those keys
            commandIds={LIMITED_KEYBINDING_COMMAND_IDS}
            className={clsx(styles.inputContainer, {
              [styles.inputContainerNewConversation]: props.isNewConversation, // Only used by assistive now
            })}
            ref={textAreaPreviewContainerRef}
          >
            <ChatInputAutocomplete
              onSelectReference={addReferenceForMention}
              onShowAgentsDialog={setAttachmentMenuPanel}
              onSelectCommand={onCommandAutoComplete}
              hideAutocomplete={!currentMode.supportsAutocompletion}
              availableCommands={availableCommands}
              availableModes={chatModes}
            >
              <textarea
                autoFocus={!props.disableAutoFocus}
                id={copilotChatTextAreaId}
                className={clsx(styles.input, {[styles.inputDisabled]: disabled})}
                autoComplete="off"
                autoCorrect="off"
                spellCheck="false"
                aria-label={currentMode.textAreaAriaLabel || placeholderText}
                aria-multiline="true"
                onPaste={props.onPaste ?? handlePaste}
                ref={textAreaRef}
                onScroll={handleScroll}
                onChange={handleChange}
                onFocus={handleFocus}
                placeholder={placeholderText}
                value={text}
                data-react-autofocus
                disabled={disabled}
                maxLength={props.maxPromptLength}
                {...testIdProps('copilot-chat-input-textarea')}
              />
            </ChatInputAutocomplete>
            <ChatInputPreview text={text} ref={textareaPreviewRef} availableCommandKeys={availableCommandKeys} />
          </ScopedCommands.LimitKeybindingScope>
          <ChatInputToolbar
            addAttachment={addAttachment}
            currentMode={currentMode}
            attachmentButtonRef={attachmentButtonRef}
            deepCodeSearch={state.skillOptions?.deepCodeSearch}
            modes={chatModes}
            onClickMode={onClickMode}
            stoppable={stoppable}
            submitDisabled={submitDisabled}
            isNewConversation={props.isNewConversation}
            onNewThreadSelected={props.onNewThreadSelected}
            supportsAttachments={supportsAttachments}
            disabled={disabled}
            shouldSubmitWithModifier={shouldSubmitWithModifier}
            extraToolbarByMode={{
              default: extraToolbar,
              task: extraToolbar ?? (
                <TaskChatInputToolbar
                  iconOnly={!props.isNewConversation || props.forceIconOnly}
                  selectedRepo={selectedRepo}
                  selectedBranch={selectedBranch}
                  selectedAgent={selectedAgent}
                  onRepoSelect={setSelectedRepo}
                  onBranchSelect={setSelectedBranch}
                  onAgentSelect={agent => setSelectedAgent(agent)}
                  agentSelectionEnabled={copilotFeatureFlags.sweAgentUseSubagents}
                  initialRepoNWO={initialRepoNWO}
                  textAreaRef={textAreaRef}
                />
              ),
            }}
            chatCommand={command}
            isAssistive={state.mode === 'assistive'}
            isCopilotSpace={!!activeCopilotSpaceId}
            isAgentTaskSubmitInProgress={isAgentTaskSubmitInProgress}
            isIncompleteCommand={isIncompleteCommand}
            customModelPicker={customModelPicker}
            selectedAgent={selectedAgent}
            showStartTaskButton={props.showStartTaskButton}
            availableCommands={availableCommands}
            navigate={navigate}
            forceIconOnly={props.forceIconOnly}
          />
        </form>
        {props.showStartTaskButton && (
          <SubmitButton
            disabled={submitDisabled}
            label={currentMode.submitLabel}
            isAgentTaskSubmitInProgress={isAgentTaskSubmitInProgress}
            isIncompleteCommand={isIncompleteCommand}
            showStartTaskButton={props.showStartTaskButton}
            shouldSubmitWithModifier={shouldSubmitWithModifier}
            className={clsx(styles.submitButtonOutsideForm)}
          />
        )}
      </ScopedCommands>
      <AttachmentMenu
        inputRef={textAreaRef}
        inputOnChange={handleChange}
        anchorRef={attachmentButtonRef}
        panel={attachmentMenuPanel}
        onPanelChange={setAttachmentMenuPanel}
        initialRepo={lastAttachedRepo}
        onRepoSelect={onRepoAttach}
        side={props.attachmentMenuSide ?? preferredOverlaySide}
      />

      {/*
        Do not add drag-and-drop handlers for ChatInput on a Copilot Space's edit page
        because they would interfere with the page's Spaces Resources attachment handlers.
      */}
      {supportsAttachments && !isCopilotSpacePage && (
        <FullScreenDragOverlay
          onFilesDrop={handleFileDrop}
          isUploading={state.isWaitingOnAttachment && state.attachmentProcessingType === 'file-upload'}
        />
      )}
    </div>
  )
}

// Toolbar

interface ChatInputToolbarProps {
  addAttachment: () => void
  attachmentButtonRef: RefObject<HTMLButtonElement | null>
  deepCodeSearch: boolean | undefined
  stoppable: boolean
  submitDisabled: boolean
  onNewThreadSelected?: () => Promise<void>
  extraToolbarByMode?: Record<string, React.ReactNode>
  currentMode: ModeSupport
  modes: ModeSupport[]
  isNewConversation?: boolean
  onClickMode?: (modeName: string) => void
  chatCommand: CopilotChatCommandType | null
  supportsAttachments: boolean
  disabled?: boolean
  isAssistive?: boolean
  isCopilotSpace?: boolean | null
  isAgentTaskSubmitInProgress?: boolean
  isIncompleteCommand: boolean
  customModelPicker?: (props: {selectedAgent?: SelectedAgent}) => React.ReactNode
  selectedAgent?: SelectedAgent
  showStartTaskButton?: boolean
  availableCommands: AvailableCommand[]
  navigate: ReturnType<typeof useNavigate>
  shouldSubmitWithModifier?: boolean
  /** Force icon-only mode in the toolbar, useful for container-based responsive behavior */
  forceIconOnly?: boolean
}

const extraToolbarByModeDefault = {default: null, task: null}

/** Maps overlay anchor side to tooltip direction */
const getTooltipDirection = (overlaySide: AnchorSide): 'n' | 's' => (overlaySide === 'outside-top' ? 'n' : 's')

const ChatInputToolbar = memo((props: ChatInputToolbarProps) => {
  const {
    chatCommand,
    extraToolbarByMode = extraToolbarByModeDefault,
    currentMode,
    supportsAttachments,
    submitDisabled,
    isAssistive,
    isCopilotSpace,
    isAgentTaskSubmitInProgress = false,
    isIncompleteCommand,
    showStartTaskButton,
    availableCommands,
    navigate,
    shouldSubmitWithModifier = false,
  } = props
  const preferredOverlaySide = useOverlayDirection()
  const tooltipDirection = getTooltipDirection(preferredOverlaySide)
  const commandSupportsModelPickerAndMcp =
    (chatCommand !== 'task' || copilotFeatureFlags.codingAgentModelSelection) &&
    chatCommand !== 'loop' &&
    chatCommand !== 'spark'

  const showModelPicker = !!(
    props.onNewThreadSelected &&
    currentMode.supportsModelSwitching &&
    commandSupportsModelPickerAndMcp
  )

  const isTask = isTaskCommand(currentMode.name, chatCommand)
  const attachmentButtonLabel = isCopilotSpace
    ? 'Add files'
    : copilotFeatureFlags.copilotChatRepositoryPicker
      ? 'Add files, and spaces'
      : 'Add repositories, files, and spaces'

  const {customModelPicker, selectedAgent, onNewThreadSelected, disabled, isNewConversation, forceIconOnly} = props
  const isNarrow = useResponsiveValue({narrow: true}, false) as boolean
  // Show icon only on narrow screens, after the conversation has started, or when forced by parent
  const showIconOnly = isNarrow || !isNewConversation || forceIconOnly

  return (
    <div
      className={clsx(styles.toolbar, {
        [styles.toolbarNoModes]: props.modes.length === 1,
      })}
    >
      {/* Modes */}
      {props.modes.length > 1 && (
        <div className={styles.mode}>
          <div className="d-flex">
            <ActionMenu>
              {showIconOnly ? (
                <ActionMenu.Anchor>
                  <IconButton
                    aria-label={currentMode.name}
                    className={styles.modeSelectButton}
                    variant="invisible"
                    icon={currentMode.icon}
                    tooltipDirection={tooltipDirection}
                  />
                </ActionMenu.Anchor>
              ) : (
                <ActionMenu.Button
                  className={styles.modeSelectButton}
                  leadingVisual={<currentMode.icon />}
                  variant="invisible"
                  trailingAction={TriangleDownIcon}
                >
                  {currentMode.name}
                </ActionMenu.Button>
              )}
              <ActionMenu.Overlay
                width="auto"
                side={preferredOverlaySide}
                position={isAssistive ? 'relative' : undefined}
                portalContainerName={isAssistive ? COPILOT_CHAT_MENU_PORTAL_ROOT : undefined}
              >
                <ActionList selectionVariant="single" role="menu" aria-label="Item">
                  {props.modes.map(mode => {
                    // Find the command associated with this mode
                    const modeCommand = availableCommands.find(cmd => cmd.mode?.name === mode.name)
                    // Check if command is disabled
                    let isCommandDisabled = false
                    if (modeCommand?.enabled) {
                      isCommandDisabled = modeCommand.enabled() === false
                    }

                    return (
                      <ActionList.Item
                        selected={currentMode.name === mode.name}
                        onSelect={() => {
                          if (isCommandDisabled && modeCommand?.disabledAction) {
                            modeCommand.disabledAction(navigate)
                          } else {
                            props.onClickMode?.(mode.name)
                          }
                        }}
                        key={mode.name}
                      >
                        <ActionList.LeadingVisual>{<mode.icon />}</ActionList.LeadingVisual>
                        {mode.name}
                        {isCommandDisabled && (
                          <ActionList.TrailingVisual>
                            <Label>Upgrade</Label>
                          </ActionList.TrailingVisual>
                        )}
                      </ActionList.Item>
                    )
                  })}
                </ActionList>
              </ActionMenu.Overlay>
            </ActionMenu>
          </div>
        </div>
      )}

      <div className={styles.extra}>
        {supportsAttachments && copilotFeatureFlags.copilotChatRepositoryPicker && !isCopilotSpace && (
          <ChatReposPicker showIconOnly={showIconOnly} tooltipDirection={tooltipDirection} />
        )}
        {supportsAttachments &&
          (copilotFeatureFlags.askModeDropdown ? (
            <IconButton
              // eslint-disable-next-line react-hooks/refs
              ref={props.attachmentButtonRef}
              icon={PlusIcon}
              className={styles.attachmentIconButton}
              aria-label={attachmentButtonLabel}
              tooltipDirection={tooltipDirection}
              // eslint-disable-next-line react-hooks/refs
              onClick={props.addAttachment}
              data-testid="attachment-menu-button"
            />
          ) : (
            <Button
              // eslint-disable-next-line react-hooks/refs
              ref={props.attachmentButtonRef}
              leadingVisual={PlusIcon}
              variant="invisible"
              aria-label={attachmentButtonLabel}
              className={styles.attachmentButton}
              // eslint-disable-next-line react-hooks/refs
              onClick={props.addAttachment}
              data-testid="attachment-menu-button"
            >
              <span
                className={clsx(styles.attachmentButtonText, {
                  'sr-only': isTask,
                })}
              >
                {attachmentButtonLabel}
              </span>
            </Button>
          ))}
        {copilotFeatureFlags.showDeepCodeSearchButton && (
          <CommandIconButton
            commandId="copilot-chat:deep-codesearch"
            icon={RocketIcon}
            variant="invisible"
            tooltipDirection={tooltipDirection}
            // eslint-disable-next-line react-hooks/refs
            className={clsx({
              // eslint-disable-next-line react-hooks/refs
              [styles.clicked]: props.deepCodeSearch,
            })}
          />
        )}
        {extraToolbarByMode[isTask ? 'task' : 'default']}
      </div>
      <div className={clsx(styles.actions, {[styles.actionsMultiple]: showModelPicker})}>
        {showModelPicker &&
          (customModelPicker ? (
            customModelPicker({selectedAgent})
          ) : (
            <ModelPicker onNewThreadSelected={onNewThreadSelected!} disabled={disabled} />
          ))}
        <div className={styles.toolbarButtons}>
          {
            // eslint-disable-next-line react-hooks/refs
            props.stoppable ? (
              <StopButton tooltipDirection={tooltipDirection} />
            ) : (
              <SubmitButton
                disabled={submitDisabled}
                label={currentMode.submitLabel}
                isAgentTaskSubmitInProgress={isAgentTaskSubmitInProgress}
                isIncompleteCommand={isIncompleteCommand}
                showStartTaskButton={showStartTaskButton}
                shouldSubmitWithModifier={shouldSubmitWithModifier}
                tooltipDirection={tooltipDirection}
                className={showStartTaskButton ? styles.submitButtonInForm : undefined}
              />
            )
          }
        </div>
      </div>
    </div>
  )
})
ChatInputToolbar.displayName = 'ChatInputToolbar'

function SubmitButton({
  disabled,
  label,
  isAgentTaskSubmitInProgress = false,
  isIncompleteCommand,
  showStartTaskButton,
  shouldSubmitWithModifier = false,
  tooltipDirection = 's',
  className,
}: {
  disabled?: boolean
  label?: string
  isAgentTaskSubmitInProgress?: boolean
  isIncompleteCommand: boolean
  showStartTaskButton?: boolean
  shouldSubmitWithModifier?: boolean
  tooltipDirection?: 'n' | 's'
  className?: string
}) {
  // Determine the appropriate aria-label based on why the button is disabled
  const getAriaLabel = () => {
    if (!disabled) {
      return label || 'Send now'
    }

    // Check if it's disabled because of an incomplete slash command
    if (isIncompleteCommand) {
      return 'Complete your slash command before sending'
    }

    return label || 'Sending a message is unavailable'
  }

  const buttonContent = isAgentTaskSubmitInProgress ? (
    <div className="d-flex flex-items-center height-full mx-2">
      <Spinner size="small" />
    </div>
  ) : showStartTaskButton && disabled ? (
    <Button size="medium" leadingVisual={PaperAirplaneIcon} inactive>
      {START_TASK_BUTTON_TEXT}
    </Button>
  ) : disabled ? (
    <IconButton
      variant="invisible"
      size="medium"
      icon={PaperAirplaneIcon}
      aria-label={getAriaLabel()}
      tooltipDirection={tooltipDirection}
      inactive
      aria-disabled
    />
  ) : showStartTaskButton ? (
    <CommandButton
      commandId={shouldSubmitWithModifier ? 'github:submit-form' : 'copilot-chat:send-message'}
      leadingVisual={PaperAirplaneIcon}
    >
      {START_TASK_BUTTON_TEXT}
    </CommandButton>
  ) : (
    <CommandIconButton
      commandId={shouldSubmitWithModifier ? 'github:submit-form' : 'copilot-chat:send-message'}
      variant="invisible"
      size="medium"
      icon={PaperAirplaneIcon}
      aria-label={getAriaLabel()}
      tooltipDirection={tooltipDirection}
    />
  )

  return className ? <div className={className}>{buttonContent}</div> : buttonContent
}

function StopButton({tooltipDirection}: {tooltipDirection: 'n' | 's'}) {
  return (
    <CommandIconButton
      {...testIdProps('copilot-chat-stop-button')}
      commandId="github:cancel"
      variant="invisible"
      size="medium"
      icon={SquareFillIcon}
      tooltipDirection={tooltipDirection}
      className={styles.CommandIconButton}
    />
  )
}
