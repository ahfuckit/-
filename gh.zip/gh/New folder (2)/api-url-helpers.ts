/**
 * Generates the API path for repository tasks endpoint
 * @param nwo - Repository name with owner (e.g., "github/github")
 * @returns API path for the repo tasks endpoint
 */
export function repoTasksApiPath(nwo: string): string {
  const [owner, repo] = nwo.split('/')
  return `/agents/repos/${owner}/${repo}/tasks`
}

/**
 * Generates the API path for creating a session for a specific task
 * @param nwo - Repository name with owner (e.g., "github/github")
 * @param taskId - The task ID
 * @returns API path for the task sessions endpoint
 */
export function repoTaskSessionsApiPath(nwo: string, taskId: string): string {
  const [owner, repo] = nwo.split('/')
  return `/agents/repos/${owner}/${repo}/tasks/${taskId}/sessions`
}

export type TasksQueryParams = {
  /** Optional user ID to filter tasks by creator */
  creatorId?: number
  /** Optional 1-based page number for paginated results. Only included when pagination is enabled (page is explicitly provided). */
  page?: number
  /** Optional boolean to filter archived tasks */
  archived?: boolean
  /** Optional boolean to include open and closed task counts in the response */
  includeCounts?: boolean
  /** Optional number of tasks per page */
  pageSize?: number
}

/**
 * Generates query parameters for tasks endpoints
 * @param params Query parameters
 * @returns Query string for tasks endpoint
 */
const generateTasksQueryParams = (params: TasksQueryParams): string => {
  const searchParams = new URLSearchParams()

  if (params.creatorId !== undefined) {
    searchParams.set('creator_id', String(params.creatorId))
  }
  if (params.page !== undefined) {
    searchParams.set('page_number', String(params.page))
  }
  if (params.archived !== undefined) {
    searchParams.set('archived', String(params.archived))
  }
  if (params.includeCounts !== undefined) {
    searchParams.set('include_counts', String(params.includeCounts))
  }
  if (params.pageSize !== undefined) {
    searchParams.set('page_size', String(params.pageSize))
  }

  const query = searchParams.toString()
  return query ? `?${query}` : ''
}

/**
 * Generates the API path for the repository tasks endpoint with query parameters
 * @param owner - Repository owner
 * @param repo - Repository name
 * @param params - Optional query parameters
 * @returns API path for the repo tasks endpoint with query string
 */
export function repoTasksApiPathWithParams(owner: string, repo: string, params?: TasksQueryParams): string {
  const basePath = `/agents/repos/${owner}/${repo}/tasks`
  const query = params ? generateTasksQueryParams(params) : ''
  return `${basePath}${query}`
}

/**
 * Generates the API path for the tasks endpoint with query parameters
 * @param params - Optional query parameters
 * @returns API path for the tasks endpoint with query string
 */
export function tasksApiPathWithParams(params?: TasksQueryParams): string {
  const basePath = `/agents/tasks`
  const query = params ? generateTasksQueryParams(params) : ''
  return query ? `${basePath}${query}` : basePath
}

/**
 * Generates the API path for task endpoint
 * @param owner - Repository owner
 * @param repo - Repository name
 * @param taskId - Task ID
 * @returns API path for the task endpoint
 */
export function taskApiPath(owner: string, repo: string, taskId: string): string {
  return `/agents/repos/${owner}/${repo}/tasks/${taskId}`
}

/**
 * Generates the API path for pull request sessions endpoint
 * @param pullId - Pull request ID
 * @returns API path for the pull sessions endpoint
 */
export function pullSessionsApiPath(pullId: number): string {
  return `/agents/sessions/resource/pull/${pullId}`
}

/**
 * Generates the API path for task inactive logs endpoint
 * @param owner - Repository owner
 * @param repo - Repository name
 * @param taskId - Task ID
 * @returns API path for the task inactive logs endpoint
 */
export function taskInactiveLogsApiPath(owner: string, repo: string, taskId: string): string {
  return `/agents/repos/${owner}/${repo}/tasks/${taskId}/inactive_logs`
}

/**
 * Generates the API path for pull request inactive logs endpoint
 * @param pullId - Pull request ID
 * @returns API path for the pull inactive logs endpoint
 */
export function pullInactiveLogsApiPath(pullId: number): string {
  return `/agents/sessions/resource/pull/${pullId}/inactive_logs`
}
