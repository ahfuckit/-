import {Truncate} from '@primer/react'
import {Text} from '@primer/styled-react'
import type {AuthorSettings} from '../contexts/AuthorSettingsContext'

import styles from './AuthorDisplayName.module.css'

/**
 * Renders the display name of an author. This happens when the author does not have a login.
 */
export function AuthorDisplayName({
  displayName,
  authorSettings,
}: {
  displayName: string
  authorSettings: AuthorSettings
}) {
  return (
    <Truncate title={displayName} className={styles.truncate} inline>
      <Text
        sx={{
          fontWeight: authorSettings.fontWeight,
          color: authorSettings.fontColor,
        }}
        className={styles.Text}
      >
        {displayName}
      </Text>
    </Truncate>
  )
}
