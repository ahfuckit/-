import {AvatarStack} from '@primer/react'
import {GitHubAvatar} from '@github-ui/github-avatar'
import {useGetHovercardAttributesForType} from '@github-ui/hovercards/use-get-hovercard-attributes-for-type'
import type {Author} from '../commit-attribution-types'
import {isBotOrApp} from '../utils'
import {useAuthorSettings} from '../contexts/AuthorSettingsContext'

type CommitAuthorStackProps = {
  authors: Author[]
  onBehalfOf?: Author
}

const maxAvatarCount = 5

interface AuthorAvatarItemProps extends React.HTMLAttributes<HTMLImageElement> {
  author: Author
  avatarSize: number | undefined
}

function AuthorAvatarItem({author, avatarSize, className, style, ...restProps}: AuthorAvatarItemProps) {
  const getHovercardAttributesForType = useGetHovercardAttributesForType()
  const hovercardAttrs = getHovercardAttributesForType('user', {login: author.login ?? ''})

  return (
    <GitHubAvatar
      data-testid="commit-stack-avatar"
      src={author.avatarUrl}
      alt={author.login ?? author.displayName}
      {...hovercardAttrs}
      square={isBotOrApp(author)}
      size={avatarSize}
      className={className}
      style={style}
      {...restProps}
    />
  )
}

interface OnBehalfOfAvatarProps extends React.HTMLAttributes<HTMLImageElement> {
  onBehalfOf: Author
  avatarSize: number | undefined
}

function OnBehalfOfAvatar({onBehalfOf, avatarSize, className, style, ...restProps}: OnBehalfOfAvatarProps) {
  const getHovercardAttributesForType = useGetHovercardAttributesForType()
  const hovercardAttrs = getHovercardAttributesForType('organization', {login: onBehalfOf.login ?? ''})

  return (
    <GitHubAvatar
      data-testid="commit-stack-avatar"
      src={onBehalfOf.avatarUrl}
      alt={onBehalfOf.login ?? onBehalfOf.displayName}
      {...hovercardAttrs}
      square
      size={avatarSize}
      className={className}
      style={style}
      {...restProps}
    />
  )
}

export function CommitAuthorStack({authors, onBehalfOf}: CommitAuthorStackProps) {
  const authorSettings = useAuthorSettings()

  return (
    <AvatarStack>
      {authors.slice(0, maxAvatarCount).map((author, index) => (
        // eslint-disable-next-line @eslint-react/no-array-index-key
        <AuthorAvatarItem key={`${author.login}_${index}`} author={author} avatarSize={authorSettings.avatarSize} />
      ))}
      {onBehalfOf && (
        <OnBehalfOfAvatar
          key={`${onBehalfOf.login}_on_behalf_of`}
          onBehalfOf={onBehalfOf}
          avatarSize={authorSettings.avatarSize}
        />
      )}
    </AvatarStack>
  )
}
