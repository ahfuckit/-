const Uri = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/)?[^\s]*$/i;
/**
 * Returns true if the value is a uri
 * @specification
 * @source ajv-formats
 */
export function IsUri(value) {
    return Uri.test(value);
}
