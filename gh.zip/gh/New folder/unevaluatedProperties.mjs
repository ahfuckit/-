// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { AccumulatedErrorContext } from './_context.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildUnevaluatedProperties(context, schema, value) {
    const keys = E.Call(E.Member('context', 'GetKeys'), []);
    const hasKey = E.Call(E.Member('keys', 'has'), ['key']);
    const addKey = E.Call(E.Member('context', 'AddKey'), ['key']);
    const isSchema = BuildSchema(context, schema.unevaluatedProperties, `value`);
    const isEvery = E.Every(E.Entries(value), E.Constant(0), ['[key, value]', '_'], E.Or(hasKey, E.And(isSchema, addKey)));
    return E.Call(E.ArrowFunction(['context'], E.Statements([
        E.ConstDeclaration('keys', keys),
        E.Return(isEvery)
    ])), ['context']);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckUnevaluatedProperties(context, schema, value) {
    const keys = context.GetKeys();
    return G.Every(G.Entries(value), 0, ([key, value]) => {
        return keys.has(key)
            || (CheckSchema(context, schema.unevaluatedProperties, value) && context.AddKey(key));
    });
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorUnevaluatedProperties(context, schemaPath, instancePath, schema, value) {
    const keys = context.GetKeys();
    const unevaluatedProperties = [];
    const isUnevaluatedProperties = G.EveryAll(G.Entries(value), 0, ([key, value]) => {
        const nextContext = new AccumulatedErrorContext(context.GetContext(), context.GetSchema());
        const isEvaluatedProperty = keys.has(key)
            || (ErrorSchema(nextContext, schemaPath, instancePath, schema.unevaluatedProperties, value) && context.AddKey(key));
        if (!isEvaluatedProperty)
            unevaluatedProperties.push(key);
        return isEvaluatedProperty;
    });
    return isUnevaluatedProperties || context.AddError({
        keyword: 'unevaluatedProperties',
        schemaPath,
        instancePath,
        params: { unevaluatedProperties }
    });
}
