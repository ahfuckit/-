'use strict';

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault")["default"];
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _require = require('./observeFragmentExperimental'),
  observeFragment = _require.observeFragment;
var _require2 = require('./RelayModernOperationDescriptor'),
  createOperationDescriptor = _require2.createOperationDescriptor;
function observeQuery(environment, gqlQuery, variables) {
  var operation = createOperationDescriptor(gqlQuery, variables);
  var rootFragmentRef = {
    __id: operation.fragment.dataID,
    __fragments: (0, _defineProperty2["default"])({}, operation.fragment.node.name, operation.request.variables),
    __fragmentOwner: operation.request
  };
  var fragmentNode = operation.request.node.fragment;
  return observeFragment(environment, fragmentNode, rootFragmentRef);
}
module.exports = {
  observeQuery: observeQuery
};