// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { EmitGuard as E, Guard as G } from '../../guard/index.mjs';
import { BuildRefine, CheckRefine, ErrorRefine } from './_refine.mjs';
import { BuildGuard, CheckGuard, ErrorGuard } from './_guard.mjs';
import { BuildAdditionalItems, CheckAdditionalItems, ErrorAdditionalItems } from './additionalItems.mjs';
import { BuildAdditionalProperties, CheckAdditionalProperties, ErrorAdditionalProperties } from './additionalProperties.mjs';
import { BuildAllOf, CheckAllOf, ErrorAllOf } from './allOf.mjs';
import { BuildAnyOf, CheckAnyOf, ErrorAnyOf } from './anyOf.mjs';
import { BuildBooleanSchema, CheckBooleanSchema, ErrorBooleanSchema } from './boolean.mjs';
import { BuildConst, CheckConst, ErrorConst } from './const.mjs';
import { BuildContains, CheckContains, ErrorContains } from './contains.mjs';
import { BuildDependencies, CheckDependencies, ErrorDependencies } from './dependencies.mjs';
import { BuildDependentRequired, CheckDependentRequired, ErrorDependentRequired } from './dependentRequired.mjs';
import { BuildDependentSchemas, CheckDependentSchemas, ErrorDependentSchemas } from './dependentSchemas.mjs';
import { BuildEnum, CheckEnum, ErrorEnum } from './enum.mjs';
import { BuildExclusiveMaximum, CheckExclusiveMaximum, ErrorExclusiveMaximum } from './exclusiveMaximum.mjs';
import { BuildExclusiveMinimum, CheckExclusiveMinimum, ErrorExclusiveMinimum } from './exclusiveMinimum.mjs';
import { BuildFormat, CheckFormat, ErrorFormat } from './format.mjs';
import { BuildIf, CheckIf, ErrorIf } from './if.mjs';
import { BuildItems, CheckItems, ErrorItems } from './items.mjs';
import { BuildMaxContains, CheckMaxContains, ErrorMaxContains } from './maxContains.mjs';
import { BuildMaximum, CheckMaximum, ErrorMaximum } from './maximum.mjs';
import { BuildMaxItems, CheckMaxItems, ErrorMaxItems } from './maxItems.mjs';
import { BuildMaxLength, CheckMaxLength, ErrorMaxLength } from './maxLength.mjs';
import { BuildMaxProperties, CheckMaxProperties, ErrorMaxProperties } from './maxProperties.mjs';
import { BuildMinContains, CheckMinContains, ErrorMinContains } from './minContains.mjs';
import { BuildMinimum, CheckMinimum, ErrorMinimum } from './minimum.mjs';
import { BuildMinItems, CheckMinItems, ErrorMinItems } from './minItems.mjs';
import { BuildMinLength, CheckMinLength, ErrorMinLength } from './minLength.mjs';
import { BuildMinProperties, CheckMinProperties, ErrorMinProperties } from './minProperties.mjs';
import { BuildMultipleOf, CheckMultipleOf, ErrorMultipleOf } from './multipleOf.mjs';
import { BuildNot, CheckNot, ErrorNot } from './not.mjs';
import { BuildOneOf, CheckOneOf, ErrorOneOf } from './oneOf.mjs';
import { BuildPattern, CheckPattern, ErrorPattern } from './pattern.mjs';
import { BuildPatternProperties, CheckPatternProperties, ErrorPatternProperties } from './patternProperties.mjs';
import { BuildPrefixItems, CheckPrefixItems, ErrorPrefixItems } from './prefixItems.mjs';
import { BuildProperties, CheckProperties, ErrorProperties } from './properties.mjs';
import { BuildPropertyNames, CheckPropertyNames, ErrorPropertyNames } from './propertyNames.mjs';
import { BuildRecursiveRef, CheckRecursiveRef, ErrorRecursiveRef } from './recursiveRef.mjs';
import { BuildRef, CheckRef, ErrorRef } from './ref.mjs';
import { BuildRequired, CheckRequired, ErrorRequired } from './required.mjs';
import { BuildType, CheckType, ErrorType } from './type.mjs';
import { BuildUnevaluatedItems, CheckUnevaluatedItems, ErrorUnevaluatedItems } from './unevaluatedItems.mjs';
import { BuildUnevaluatedProperties, CheckUnevaluatedProperties, ErrorUnevaluatedProperties } from './unevaluatedProperties.mjs';
import { BuildUniqueItems, CheckUniqueItems, ErrorUniqueItems } from './uniqueItems.mjs';
// ----------------------------------------------------------------
// HasTypeName
// ----------------------------------------------------------------
function HasTypeName(schema, typename) {
    return S.IsType(schema) &&
        (G.IsArray(schema.type) && schema.type.includes(typename) ||
            G.IsEqual(schema.type, typename));
}
// ----------------------------------------------------------------
// HasObject
// ----------------------------------------------------------------
function HasObjectType(schema) {
    return HasTypeName(schema, 'object');
}
function HasObjectKeywords(schema) {
    return S.IsSchemaObject(schema) && (S.IsAdditionalProperties(schema) ||
        S.IsDependencies(schema) ||
        S.IsDependentRequired(schema) ||
        S.IsDependentSchemas(schema) ||
        S.IsProperties(schema) ||
        S.IsPatternProperties(schema) ||
        S.IsPropertyNames(schema) ||
        S.IsMinProperties(schema) ||
        S.IsMaxProperties(schema) ||
        S.IsRequired(schema) ||
        S.IsUnevaluatedProperties(schema));
}
// ----------------------------------------------------------------
// HasArray
// ----------------------------------------------------------------
function HasArrayType(schema) {
    return HasTypeName(schema, 'array');
}
function HasArrayKeywords(schema) {
    return S.IsSchemaObject(schema) && (S.IsAdditionalItems(schema) ||
        S.IsItems(schema) ||
        S.IsContains(schema) ||
        S.IsMaxContains(schema) ||
        S.IsMaxItems(schema) ||
        S.IsMinContains(schema) ||
        S.IsMinItems(schema) ||
        S.IsPrefixItems(schema) ||
        S.IsUnevaluatedItems(schema) ||
        S.IsUniqueItems(schema));
}
// ----------------------------------------------------------------
// HasString
// ----------------------------------------------------------------
function HasStringType(schema) {
    return HasTypeName(schema, 'string');
}
function HasStringKeywords(schema) {
    return S.IsSchemaObject(schema) && (S.IsMinLength(schema) ||
        S.IsMaxLength(schema) ||
        S.IsFormat(schema) ||
        S.IsPattern(schema));
}
// ----------------------------------------------------------------
// HasNumber
// ----------------------------------------------------------------
function HasNumberType(schema) {
    return HasTypeName(schema, 'number') || HasTypeName(schema, 'bigint');
}
function HasNumberKeywords(schema) {
    return S.IsSchemaObject(schema) && (S.IsMinimum(schema) ||
        S.IsMaximum(schema) ||
        S.IsExclusiveMaximum(schema) ||
        S.IsExclusiveMinimum(schema) ||
        S.IsMultipleOf(schema));
}
// ----------------------------------------------------------------
// Build
// ----------------------------------------------------------------
export function BuildSchema(context, schema, value) {
    const conditions = [];
    if (S.IsBooleanSchema(schema))
        return BuildBooleanSchema(context, schema, value);
    if (S.IsType(schema))
        conditions.push(BuildType(context, schema, value));
    if (HasObjectKeywords(schema)) {
        const constraints = [];
        if (S.IsRequired(schema))
            constraints.push(BuildRequired(context, schema, value));
        if (S.IsAdditionalProperties(schema))
            constraints.push(BuildAdditionalProperties(context, schema, value));
        if (S.IsDependencies(schema))
            constraints.push(BuildDependencies(context, schema, value));
        if (S.IsDependentRequired(schema))
            constraints.push(BuildDependentRequired(context, schema, value));
        if (S.IsDependentSchemas(schema))
            constraints.push(BuildDependentSchemas(context, schema, value));
        if (S.IsPatternProperties(schema))
            constraints.push(BuildPatternProperties(context, schema, value));
        if (S.IsProperties(schema))
            constraints.push(BuildProperties(context, schema, value));
        if (S.IsPropertyNames(schema))
            constraints.push(BuildPropertyNames(context, schema, value));
        if (S.IsMinProperties(schema))
            constraints.push(BuildMinProperties(context, schema, value));
        if (S.IsMaxProperties(schema))
            constraints.push(BuildMaxProperties(context, schema, value));
        const reduced = E.ReduceAnd(constraints);
        const guarded = E.Or(E.Not(E.IsObjectNotArray(value)), reduced);
        conditions.push(HasObjectType(schema) ? reduced : guarded);
    }
    if (HasArrayKeywords(schema)) {
        const constraints = [];
        if (S.IsAdditionalItems(schema))
            constraints.push(BuildAdditionalItems(context, schema, value));
        if (S.IsContains(schema))
            constraints.push(BuildContains(context, schema, value));
        if (S.IsItems(schema))
            constraints.push(BuildItems(context, schema, value));
        if (S.IsMaxContains(schema))
            constraints.push(BuildMaxContains(context, schema, value));
        if (S.IsMaxItems(schema))
            constraints.push(BuildMaxItems(context, schema, value));
        if (S.IsMinContains(schema))
            constraints.push(BuildMinContains(context, schema, value));
        if (S.IsMinItems(schema))
            constraints.push(BuildMinItems(context, schema, value));
        if (S.IsPrefixItems(schema))
            constraints.push(BuildPrefixItems(context, schema, value));
        if (S.IsUniqueItems(schema))
            constraints.push(BuildUniqueItems(context, schema, value));
        const reduced = E.ReduceAnd(constraints);
        const guarded = E.Or(E.Not(E.IsArray(value)), reduced);
        conditions.push(HasArrayType(schema) ? reduced : guarded);
    }
    if (HasStringKeywords(schema)) {
        const constraints = [];
        if (S.IsFormat(schema))
            constraints.push(BuildFormat(context, schema, value));
        if (S.IsMaxLength(schema))
            constraints.push(BuildMaxLength(context, schema, value));
        if (S.IsMinLength(schema))
            constraints.push(BuildMinLength(context, schema, value));
        if (S.IsPattern(schema))
            constraints.push(BuildPattern(context, schema, value));
        const reduced = E.ReduceAnd(constraints);
        const guarded = E.Or(E.Not(E.IsString(value)), reduced);
        conditions.push(HasStringType(schema) ? reduced : guarded);
    }
    if (HasNumberKeywords(schema)) {
        const constraints = [];
        if (S.IsExclusiveMaximum(schema))
            constraints.push(BuildExclusiveMaximum(context, schema, value));
        if (S.IsExclusiveMinimum(schema))
            constraints.push(BuildExclusiveMinimum(context, schema, value));
        if (S.IsMaximum(schema))
            constraints.push(BuildMaximum(context, schema, value));
        if (S.IsMinimum(schema))
            constraints.push(BuildMinimum(context, schema, value));
        if (S.IsMultipleOf(schema))
            constraints.push(BuildMultipleOf(context, schema, value));
        const reduced = E.ReduceAnd(constraints);
        const guarded = E.Or(E.Not(E.Or(E.IsNumber(value), E.IsBigInt(value))), reduced);
        conditions.push(HasNumberType(schema) ? reduced : guarded);
    }
    if (S.IsRecursiveRef(schema))
        conditions.push(BuildRecursiveRef(context, schema, value));
    if (S.IsRef(schema))
        conditions.push(BuildRef(context, schema, value));
    if (S.IsGuard(schema))
        conditions.push(BuildGuard(context, schema, value));
    if (S.IsConst(schema))
        conditions.push(BuildConst(context, schema, value));
    if (S.IsEnum(schema))
        conditions.push(BuildEnum(context, schema, value));
    if (S.IsIf(schema))
        conditions.push(BuildIf(context, schema, value));
    if (S.IsNot(schema))
        conditions.push(BuildNot(context, schema, value));
    if (S.IsAllOf(schema))
        conditions.push(BuildAllOf(context, schema, value));
    if (S.IsAnyOf(schema))
        conditions.push(BuildAnyOf(context, schema, value));
    if (S.IsOneOf(schema))
        conditions.push(BuildOneOf(context, schema, value));
    if (S.IsUnevaluatedItems(schema))
        conditions.push(E.Or(E.Not(E.IsArray(value)), BuildUnevaluatedItems(context, schema, value)));
    if (S.IsUnevaluatedProperties(schema))
        conditions.push(E.Or(E.Not(E.IsObject(value)), BuildUnevaluatedProperties(context, schema, value)));
    if (S.IsRefine(schema))
        conditions.push(BuildRefine(context, schema, value));
    return E.ReduceAnd(conditions);
}
// ----------------------------------------------------------------
// Check
// ----------------------------------------------------------------
export function CheckSchema(context, schema, value) {
    return S.IsBooleanSchema(schema) ? CheckBooleanSchema(context, schema, value) : ((!S.IsType(schema) || CheckType(context, schema, value)) &&
        (!(G.IsObject(value) && !G.IsArray(value)) || ((!S.IsRequired(schema) || CheckRequired(context, schema, value)) &&
            (!S.IsAdditionalProperties(schema) || CheckAdditionalProperties(context, schema, value)) &&
            (!S.IsDependencies(schema) || CheckDependencies(context, schema, value)) &&
            (!S.IsDependentRequired(schema) || CheckDependentRequired(context, schema, value)) &&
            (!S.IsDependentSchemas(schema) || CheckDependentSchemas(context, schema, value)) &&
            (!S.IsPatternProperties(schema) || CheckPatternProperties(context, schema, value)) &&
            (!S.IsProperties(schema) || CheckProperties(context, schema, value)) &&
            (!S.IsPropertyNames(schema) || CheckPropertyNames(context, schema, value)) &&
            (!S.IsMinProperties(schema) || CheckMinProperties(context, schema, value)) &&
            (!S.IsMaxProperties(schema) || CheckMaxProperties(context, schema, value)))) &&
        (!G.IsArray(value) || ((!S.IsAdditionalItems(schema) || CheckAdditionalItems(context, schema, value)) &&
            (!S.IsContains(schema) || CheckContains(context, schema, value)) &&
            (!S.IsItems(schema) || CheckItems(context, schema, value)) &&
            (!S.IsMaxContains(schema) || CheckMaxContains(context, schema, value)) &&
            (!S.IsMaxItems(schema) || CheckMaxItems(context, schema, value)) &&
            (!S.IsMinContains(schema) || CheckMinContains(context, schema, value)) &&
            (!S.IsMinItems(schema) || CheckMinItems(context, schema, value)) &&
            (!S.IsPrefixItems(schema) || CheckPrefixItems(context, schema, value)) &&
            (!S.IsUniqueItems(schema) || CheckUniqueItems(context, schema, value)))) &&
        (!G.IsString(value) || ((!S.IsFormat(schema) || CheckFormat(context, schema, value)) &&
            (!S.IsMaxLength(schema) || CheckMaxLength(context, schema, value)) &&
            (!S.IsMinLength(schema) || CheckMinLength(context, schema, value)) &&
            (!S.IsPattern(schema) || CheckPattern(context, schema, value)))) &&
        (!(G.IsNumber(value) || G.IsBigInt(value)) || ((!S.IsExclusiveMaximum(schema) || CheckExclusiveMaximum(context, schema, value)) &&
            (!S.IsExclusiveMinimum(schema) || CheckExclusiveMinimum(context, schema, value)) &&
            (!S.IsMaximum(schema) || CheckMaximum(context, schema, value)) &&
            (!S.IsMinimum(schema) || CheckMinimum(context, schema, value)) &&
            (!S.IsMultipleOf(schema) || CheckMultipleOf(context, schema, value)))) &&
        (!S.IsRecursiveRef(schema) || CheckRecursiveRef(context, schema, value)) &&
        (!S.IsRef(schema) || CheckRef(context, schema, value)) &&
        (!S.IsGuard(schema) || CheckGuard(context, schema, value)) &&
        (!S.IsConst(schema) || CheckConst(context, schema, value)) &&
        (!S.IsEnum(schema) || CheckEnum(context, schema, value)) &&
        (!S.IsIf(schema) || CheckIf(context, schema, value)) &&
        (!S.IsNot(schema) || CheckNot(context, schema, value)) &&
        (!S.IsAllOf(schema) || CheckAllOf(context, schema, value)) &&
        (!S.IsAnyOf(schema) || CheckAnyOf(context, schema, value)) &&
        (!S.IsOneOf(schema) || CheckOneOf(context, schema, value)) &&
        (!S.IsUnevaluatedItems(schema) || (!G.IsArray(value) || CheckUnevaluatedItems(context, schema, value))) &&
        (!S.IsUnevaluatedProperties(schema) || (!G.IsObject(value) || CheckUnevaluatedProperties(context, schema, value))) &&
        (!S.IsRefine(schema) || CheckRefine(context, schema, value)));
}
// ----------------------------------------------------------------
// Error
// ----------------------------------------------------------------
export function ErrorSchema(context, schemaPath, instancePath, schema, value) {
    return (S.IsBooleanSchema(schema)) ? ErrorBooleanSchema(context, schemaPath, instancePath, schema, value) : (!!(+(!S.IsType(schema) || ErrorType(context, schemaPath, instancePath, schema, value)) &
        +(!(G.IsObject(value) && !G.IsArray(value)) || !!(+(!S.IsRequired(schema) || ErrorRequired(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsAdditionalProperties(schema) || ErrorAdditionalProperties(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsDependencies(schema) || ErrorDependencies(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsDependentRequired(schema) || ErrorDependentRequired(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsDependentSchemas(schema) || ErrorDependentSchemas(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsPatternProperties(schema) || ErrorPatternProperties(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsProperties(schema) || ErrorProperties(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsPropertyNames(schema) || ErrorPropertyNames(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMinProperties(schema) || ErrorMinProperties(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMaxProperties(schema) || ErrorMaxProperties(context, schemaPath, instancePath, schema, value)))) &
        +(!G.IsArray(value) || !!(+(!S.IsAdditionalItems(schema) || ErrorAdditionalItems(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsContains(schema) || ErrorContains(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsItems(schema) || ErrorItems(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMaxContains(schema) || ErrorMaxContains(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMaxItems(schema) || ErrorMaxItems(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMinContains(schema) || ErrorMinContains(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMinItems(schema) || ErrorMinItems(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsPrefixItems(schema) || ErrorPrefixItems(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsUniqueItems(schema) || ErrorUniqueItems(context, schemaPath, instancePath, schema, value)))) &
        +(!G.IsString(value) || !!(+(!S.IsFormat(schema) || ErrorFormat(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMaxLength(schema) || ErrorMaxLength(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMinLength(schema) || ErrorMinLength(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsPattern(schema) || ErrorPattern(context, schemaPath, instancePath, schema, value)))) &
        +(!(G.IsNumber(value) || G.IsBigInt(value)) || !!(+(!S.IsExclusiveMaximum(schema) || ErrorExclusiveMaximum(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsExclusiveMinimum(schema) || ErrorExclusiveMinimum(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMaximum(schema) || ErrorMaximum(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMinimum(schema) || ErrorMinimum(context, schemaPath, instancePath, schema, value)) &
            +(!S.IsMultipleOf(schema) || ErrorMultipleOf(context, schemaPath, instancePath, schema, value)))) &
        +(!S.IsRecursiveRef(schema) || ErrorRecursiveRef(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsRef(schema) || ErrorRef(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsGuard(schema) || ErrorGuard(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsConst(schema) || ErrorConst(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsEnum(schema) || ErrorEnum(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsIf(schema) || ErrorIf(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsNot(schema) || ErrorNot(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsAllOf(schema) || ErrorAllOf(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsAnyOf(schema) || ErrorAnyOf(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsOneOf(schema) || ErrorOneOf(context, schemaPath, instancePath, schema, value)) &
        +(!S.IsUnevaluatedItems(schema) || (!G.IsArray(value) || ErrorUnevaluatedItems(context, schemaPath, instancePath, schema, value))) &
        +(!S.IsUnevaluatedProperties(schema) || (!G.IsObject(value) || ErrorUnevaluatedProperties(context, schemaPath, instancePath, schema, value)))) &&
        (!S.IsRefine(schema) || ErrorRefine(context, schemaPath, instancePath, schema, value)));
}
