// deno-fmt-ignore-file
import { EmitGuard as E, Guard as G } from '../../guard/index.mjs';
import { AccumulatedErrorContext } from './_context.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
import { Reducer } from './_reducer.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
function BuildAllOfStandard(context, schema, value) {
    return Reducer(context, schema.allOf, value, E.IsEqual(E.Member('results', 'length'), E.Constant(schema.allOf.length)));
}
function BuildAllOfFast(context, schema, value) {
    return E.ReduceAnd(schema.allOf.map((schema) => BuildSchema(context, schema, value)));
}
export function BuildAllOf(context, schema, value) {
    return context.UseUnevaluated()
        ? BuildAllOfStandard(context, schema, value)
        : BuildAllOfFast(context, schema, value);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckAllOf(context, schema, value) {
    const results = schema.allOf.reduce((result, schema) => {
        const nextContext = context.Clone();
        return CheckSchema(nextContext, schema, value) ? [...result, nextContext] : result;
    }, []);
    return G.IsEqual(results.length, schema.allOf.length) && context.Merge(results);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorAllOf(context, schemaPath, instancePath, schema, value) {
    const failedContexts = [];
    const results = schema.allOf.reduce((result, schema, index) => {
        const nextSchemaPath = `${schemaPath}/allOf/${index}`;
        const nextContext = new AccumulatedErrorContext(context.GetContext(), context.GetSchema());
        const isSchema = ErrorSchema(nextContext, nextSchemaPath, instancePath, schema, value);
        if (!isSchema)
            failedContexts.push(nextContext);
        return isSchema ? [...result, nextContext] : result;
    }, []);
    const isAllOf = G.IsEqual(results.length, schema.allOf.length) && context.Merge(results);
    if (!isAllOf)
        failedContexts.forEach(failed => failed.GetErrors().forEach(error => context.AddError(error)));
    return isAllOf;
}
