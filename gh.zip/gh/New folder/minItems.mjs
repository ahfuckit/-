// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildMinItems(context, schema, value) {
    return E.IsGreaterEqualThan(E.Member(value, 'length'), E.Constant(schema.minItems));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckMinItems(context, schema, value) {
    return G.IsGreaterEqualThan(value.length, schema.minItems);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorMinItems(context, schemaPath, instancePath, schema, value) {
    return CheckMinItems(context, schema, value) || context.AddError({
        keyword: 'minItems',
        schemaPath,
        instancePath,
        params: { limit: schema.minItems }
    });
}
