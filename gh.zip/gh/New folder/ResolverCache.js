'use strict';

var _require = require('../util/RelayConcreteNode'),
  RELAY_LIVE_RESOLVER = _require.RELAY_LIVE_RESOLVER;
var invariant = require('invariant');
var NoopResolverCache = /*#__PURE__*/function () {
  function NoopResolverCache() {}
  var _proto = NoopResolverCache.prototype;
  _proto.readFromCacheOrEvaluate = function readFromCacheOrEvaluate(recordID, field, variables, evaluate, getDataForResolverFragment) {
    !(field.kind !== RELAY_LIVE_RESOLVER) ? process.env.NODE_ENV !== "production" ? invariant(false, 'This store does not support Live Resolvers') : invariant(false) : void 0;
    var _evaluate = evaluate(),
      resolverResult = _evaluate.resolverResult,
      snapshot = _evaluate.snapshot,
      error = _evaluate.error;
    return [resolverResult, undefined, error, snapshot, undefined, undefined];
  };
  _proto.invalidateDataIDs = function invalidateDataIDs(updatedDataIDs) {};
  _proto.ensureClientRecord = function ensureClientRecord(id, typeName) {
    !false ? process.env.NODE_ENV !== "production" ? invariant(false, 'Client Edges to Client Objects are not supported in this version of Relay Store') : invariant(false) : void 0;
  };
  _proto.notifyUpdatedSubscribers = function notifyUpdatedSubscribers(updatedDataIDs) {};
  return NoopResolverCache;
}();
module.exports = {
  NoopResolverCache: NoopResolverCache
};