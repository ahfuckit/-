// deno-fmt-ignore-file
import * as V from './_externals.mjs';
import { EmitGuard as E, Guard as G } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildConst(context, schema, value) {
    return G.IsValueLike(schema.const)
        ? E.IsEqual(value, E.Constant(schema.const))
        : E.IsDeepEqual(value, V.CreateExternalVariable(schema.const));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckConst(context, schema, value) {
    return G.IsValueLike(schema.const)
        ? G.IsEqual(value, schema.const)
        : G.IsDeepEqual(value, schema.const);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function ErrorConst(context, schemaPath, instancePath, schema, value) {
    return CheckConst(context, schema, value) || context.AddError({
        keyword: 'const',
        schemaPath,
        instancePath,
        params: { allowedValue: schema.const },
    });
}
