// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// ItemsSized
// ------------------------------------------------------------------
function BuildItemsSized(context, schema, value) {
    return E.ReduceAnd(schema.items.map((schema, index) => {
        const isLength = E.IsLessEqualThan(E.Member(value, 'length'), E.Constant(index));
        const isSchema = BuildSchema(context, schema, `${value}[${index}]`);
        const addIndex = context.AddIndex(E.Constant(index));
        const guarded = context.UseUnevaluated() ? E.And(isSchema, addIndex) : isSchema;
        return E.Or(isLength, guarded);
    }));
}
function CheckItemsSized(context, schema, value) {
    return G.Every(schema.items, 0, (schema, index) => {
        return G.IsLessEqualThan(value.length, index)
            || (CheckSchema(context, schema, value[index]) && context.AddIndex(index));
    });
}
function ErrorItemsSized(context, schemaPath, instancePath, schema, value) {
    return G.EveryAll(schema.items, 0, (schema, index) => {
        const nextSchemaPath = `${schemaPath}/items/${index}`;
        const nextInstancePath = `${instancePath}/${index}`;
        return G.IsLessEqualThan(value.length, index)
            || (ErrorSchema(context, nextSchemaPath, nextInstancePath, schema, value[index]) && context.AddIndex(index));
    });
}
// ------------------------------------------------------------------
// ItemsUnsized
// ------------------------------------------------------------------
function BuildItemsUnsized(context, schema, value) {
    const offset = S.IsPrefixItems(schema) ? schema.prefixItems.length : 0;
    const isSchema = BuildSchema(context, schema.items, 'element');
    const addIndex = context.AddIndex('index');
    const guarded = context.UseUnevaluated() ? E.And(isSchema, addIndex) : isSchema;
    return E.Every(value, E.Constant(offset), ['element', 'index'], guarded);
}
function CheckItemsUnsized(context, schema, value) {
    const offset = S.IsPrefixItems(schema) ? schema.prefixItems.length : 0;
    return G.Every(value, offset, (element, index) => {
        return CheckSchema(context, schema.items, element)
            && context.AddIndex(index);
    });
}
function ErrorItemsUnsized(context, schemaPath, instancePath, schema, value) {
    const offset = S.IsPrefixItems(schema) ? schema.prefixItems.length : 0;
    return G.EveryAll(value, offset, (element, index) => {
        const nextSchemaPath = `${schemaPath}/items`;
        const nextInstancePath = `${instancePath}/${index}`;
        return ErrorSchema(context, nextSchemaPath, nextInstancePath, schema.items, element)
            && context.AddIndex(index);
    });
}
// ------------------------------------------------------------------
// Items
// ------------------------------------------------------------------
export function BuildItems(context, schema, value) {
    return S.IsItemsSized(schema) ? BuildItemsSized(context, schema, value) : BuildItemsUnsized(context, schema, value);
}
export function CheckItems(context, schema, value) {
    return S.IsItemsSized(schema) ? CheckItemsSized(context, schema, value) : CheckItemsUnsized(context, schema, value);
}
export function ErrorItems(context, schemaPath, instancePath, schema, value) {
    return S.IsItemsSized(schema) ? ErrorItemsSized(context, schemaPath, instancePath, schema, value) : ErrorItemsUnsized(context, schemaPath, instancePath, schema, value);
}
