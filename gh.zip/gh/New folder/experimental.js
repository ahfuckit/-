'use strict';

var resolverDataInjector = require('./store/live-resolvers/resolverDataInjector');
var _require = require('./store/observeFragmentExperimental'),
  observeFragment = _require.observeFragment;
var _require2 = require('./store/observeQueryExperimental'),
  observeQuery = _require2.observeQuery;
var _require3 = require('./store/waitForFragmentExperimental'),
  waitForFragmentData = _require3.waitForFragmentData;
function isValueResult(input) {
  return input.ok === true;
}
function isErrorResult(input) {
  return input.ok === false;
}
module.exports = {
  resolverDataInjector: resolverDataInjector,
  isValueResult: isValueResult,
  isErrorResult: isErrorResult,
  observeQuery: observeQuery,
  observeFragment: observeFragment,
  waitForFragmentData: waitForFragmentData
};