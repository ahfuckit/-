// deno-fmt-ignore-file
import { EmitGuard as E, Guard as G } from '../../guard/index.mjs';
import { AccumulatedErrorContext } from './_context.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildPropertyNames(context, schema, value) {
    return E.Call(E.Member(E.Keys(value), 'every'), [E.ArrowFunction(['key'], BuildSchema(context, schema.propertyNames, 'key'))]);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckPropertyNames(context, schema, value) {
    return G.Every(G.Keys(value), 0, (key) => CheckSchema(context, schema.propertyNames, key));
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorPropertyNames(context, schemaPath, instancePath, schema, value) {
    const propertyNames = [];
    const isPropertyNames = G.EveryAll(G.Keys(value), 0, (key) => {
        const nextInstancePath = `${instancePath}/${key}`;
        const nextSchemaPath = `${schemaPath}/propertyNames`;
        const nextContext = new AccumulatedErrorContext(context.GetContext(), context.GetSchema());
        const isPropertyName = ErrorSchema(nextContext, nextSchemaPath, nextInstancePath, schema.propertyNames, key);
        if (!isPropertyName)
            propertyNames.push(key);
        return isPropertyName;
    });
    return isPropertyNames || context.AddError({
        keyword: 'propertyNames',
        schemaPath,
        instancePath,
        params: { propertyNames }
    });
}
