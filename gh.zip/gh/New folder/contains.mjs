// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { EmitGuard as E, Guard as G } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Invalid
// ------------------------------------------------------------------
function IsValid(schema) {
    return !(S.IsMinContains(schema) && G.IsEqual(schema.minContains, 0));
}
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildContains(context, schema, value) {
    if (!IsValid(schema))
        return E.Constant(true);
    const isLength = E.Not(E.IsEqual(E.Member(value, 'length'), E.Constant(0)));
    const isSome = E.Call(E.Member(value, 'some'), [E.ArrowFunction(['value'], BuildSchema(context, schema.contains, 'value'))]);
    return E.And(isLength, isSome);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckContains(context, schema, value) {
    if (!IsValid(schema))
        return true;
    return !G.IsEqual(value.length, 0) &&
        value.some((value) => CheckSchema(context, schema.contains, value));
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorContains(context, schemaPath, instancePath, schema, value) {
    return CheckContains(context, schema, value) || context.AddError({
        keyword: 'contains',
        schemaPath,
        instancePath,
        params: { minContains: 1 },
    });
}
