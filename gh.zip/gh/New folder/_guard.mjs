// deno-fmt-ignore-file
import * as V from './_externals.mjs';
import { EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildGuard(context, schema, value) {
    return E.Call(E.Member(E.Member(V.CreateExternalVariable(schema), '~guard'), 'check'), [value]);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckGuard(context, schema, value) {
    return schema['~guard'].check(value);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorGuard(context, schemaPath, instancePath, schema, value) {
    return schema['~guard'].check(value) || context.AddError({
        keyword: '~guard',
        schemaPath,
        instancePath,
        params: { errors: schema['~guard'].errors(value) },
    });
}
