// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildMaximum(context, schema, value) {
    return E.IsLessEqualThan(value, E.Constant(schema.maximum));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckMaximum(context, schema, value) {
    return G.IsLessEqualThan(value, schema.maximum);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorMaximum(context, schemaPath, instancePath, schema, value) {
    return CheckMaximum(context, schema, value) || context.AddError({
        keyword: 'maximum',
        schemaPath,
        instancePath,
        params: { comparison: '<=', limit: schema.maximum }
    });
}
