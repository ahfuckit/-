// deno-fmt-ignore-file
import { EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema } from './schema.mjs';
import { Reducer } from './_reducer.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
function BuildNotUnevaluated(context, schema, value) {
    return Reducer(context, [schema.not], value, E.Not(E.IsEqual(E.Member('results', 'length'), E.Constant(1))));
}
function BuildNotFast(context, schema, value) {
    return E.Not(BuildSchema(context, schema.not, value));
}
export function BuildNot(context, schema, value) {
    return context.UseUnevaluated() ? BuildNotUnevaluated(context, schema, value) : BuildNotFast(context, schema, value);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckNot(context, schema, value) {
    const condition = context.Clone();
    const isSchema = !CheckSchema(condition, schema.not, value);
    const isNot = isSchema && context.Merge([condition]);
    return isNot;
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorNot(context, schemaPath, instancePath, schema, value) {
    return CheckNot(context, schema, value) || context.AddError({
        keyword: 'not',
        schemaPath,
        instancePath,
        params: {},
    });
}
