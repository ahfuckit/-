// deno-fmt-ignore-file
import * as V from './_externals.mjs';
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildPattern(context, schema, value) {
    const regexp = V.CreateExternalVariable(G.IsString(schema.pattern) ? new RegExp(schema.pattern) : schema.pattern);
    return E.Call(E.Member(regexp, 'test'), [value]);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckPattern(context, schema, value) {
    const regexp = G.IsString(schema.pattern) ? new RegExp(schema.pattern) : schema.pattern;
    return regexp.test(value);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorPattern(context, schemaPath, instancePath, schema, value) {
    return CheckPattern(context, schema, value) || context.AddError({
        keyword: 'pattern',
        schemaPath,
        instancePath,
        params: { pattern: schema.pattern }
    });
}
