// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildExclusiveMaximum(context, schema, value) {
    return E.IsLessThan(value, E.Constant(schema.exclusiveMaximum));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckExclusiveMaximum(context, schema, value) {
    return G.IsLessThan(value, schema.exclusiveMaximum);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorExclusiveMaximum(context, schemaPath, instancePath, schema, value) {
    return CheckExclusiveMaximum(context, schema, value) || context.AddError({
        keyword: 'exclusiveMaximum',
        schemaPath,
        instancePath,
        params: { comparison: '<', limit: schema.exclusiveMaximum }
    });
}
