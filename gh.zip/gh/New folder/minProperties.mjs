// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildMinProperties(context, schema, value) {
    return E.IsGreaterEqualThan(E.Member(E.Keys(value), 'length'), E.Constant(schema.minProperties));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckMinProperties(context, schema, value) {
    return G.IsGreaterEqualThan(G.Keys(value).length, schema.minProperties);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorMinProperties(context, schemaPath, instancePath, schema, value) {
    return CheckMinProperties(context, schema, value) || context.AddError({
        keyword: 'minProperties',
        schemaPath,
        instancePath,
        params: { limit: schema.minProperties },
    });
}
