// deno-fmt-ignore-file
import { EmitGuard as E } from '../../guard/index.mjs';
import { Format } from '../../format/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildFormat(context, schema, value) {
    return E.Call(E.Member('Format', 'Test'), [E.Constant(schema.format), value]);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckFormat(context, schema, value) {
    return Format.Test(schema.format, value);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorFormat(context, schemaPath, instancePath, schema, value) {
    return CheckFormat(context, schema, value) || context.AddError({
        keyword: 'format',
        schemaPath,
        instancePath,
        params: { format: schema.format },
    });
}
