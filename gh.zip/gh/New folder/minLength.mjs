// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildMinLength(context, schema, value) {
    return E.IsGreaterEqualThan(E.StringGraphemeCount(value), E.Constant(schema.minLength));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckMinLength(context, schema, value) {
    return G.IsGreaterEqualThan(G.StringGraphemeCount(value), schema.minLength);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorMinLength(context, schemaPath, instancePath, schema, value) {
    return CheckMinLength(context, schema, value) || context.AddError({
        keyword: 'minLength',
        schemaPath,
        instancePath,
        params: { limit: schema.minLength }
    });
}
