// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { AccumulatedErrorContext } from './_context.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildUnevaluatedItems(context, schema, value) {
    const indices = E.Call(E.Member('context', 'GetIndices'), []);
    const hasIndex = E.Call(E.Member('indices', 'has'), ['index']);
    const isSchema = BuildSchema(context, schema.unevaluatedItems, 'value');
    const addIndex = E.Call(E.Member('context', 'AddIndex'), ['index']);
    const isEvery = E.Every(value, E.Constant(0), ['value', 'index'], E.And(E.Or(hasIndex, isSchema), addIndex));
    return E.Call(E.ArrowFunction(['context'], E.Statements([
        E.ConstDeclaration('indices', indices),
        E.Return(isEvery)
    ])), ['context']);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckUnevaluatedItems(context, schema, value) {
    const indices = context.GetIndices();
    return G.Every(value, 0, (value, index) => {
        return (indices.has(index) || CheckSchema(context, schema.unevaluatedItems, value))
            && context.AddIndex(index);
    });
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorUnevaluatedItems(context, schemaPath, instancePath, schema, value) {
    const indices = context.GetIndices();
    const unevaluatedItems = [];
    const isUnevaluatedItems = G.EveryAll(value, 0, (value, index) => {
        const nextContext = new AccumulatedErrorContext(context.GetContext(), context.GetSchema());
        const isEvaluatedItem = (indices.has(index) || ErrorSchema(nextContext, schemaPath, instancePath, schema.unevaluatedItems, value))
            && context.AddIndex(index);
        if (!isEvaluatedItem)
            unevaluatedItems.push(index);
        return isEvaluatedItem;
    });
    return isUnevaluatedItems || context.AddError({
        keyword: 'unevaluatedItems',
        schemaPath,
        instancePath,
        params: { unevaluatedItems }
    });
}
