'use strict';

var React = require('react');
var _require = require('relay-runtime'),
  createRelayLoggingContext = _require.__internal.createRelayLoggingContext;
module.exports = createRelayLoggingContext(React);