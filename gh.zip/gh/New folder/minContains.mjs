// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Valid
// ------------------------------------------------------------------
function IsValid(schema) {
    return S.IsContains(schema);
}
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildMinContains(context, schema, value) {
    if (!IsValid(schema))
        return E.Constant(true);
    const count = E.Call(E.Member(value, 'reduce'), [E.ArrowFunction(['result', 'value'], E.Ternary(BuildSchema(context, schema.contains, 'value'), E.PrefixIncrement('result'), 'result')), E.Constant(0)]);
    return E.IsGreaterEqualThan(count, E.Constant(schema.minContains));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckMinContains(context, schema, value) {
    if (!IsValid(schema))
        return true;
    const count = value.reduce((result, value) => CheckSchema(context, schema.contains, value) ? ++result : result, 0);
    return G.IsGreaterEqualThan(count, schema.minContains);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorMinContains(context, schemaPath, instancePath, schema, value) {
    return CheckMinContains(context, schema, value) || context.AddError({
        keyword: 'contains',
        schemaPath,
        instancePath,
        params: { minContains: schema.minContains }
    });
}
