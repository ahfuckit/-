// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { EmitGuard as E } from '../../guard/index.mjs';
import { AccumulatedErrorContext } from './_context.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildIf(context, schema, value) {
    const thenSchema = S.IsThen(schema) ? schema.then : true;
    const elseSchema = S.IsElse(schema) ? schema.else : true;
    return E.Ternary(BuildSchema(context, schema.if, value), BuildSchema(context, thenSchema, value), BuildSchema(context, elseSchema, value));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckIf(context, schema, value) {
    const thenSchema = S.IsThen(schema) ? schema.then : true;
    const elseSchema = S.IsElse(schema) ? schema.else : true;
    return CheckSchema(context, schema.if, value)
        ? CheckSchema(context, thenSchema, value)
        : CheckSchema(context, elseSchema, value);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorIf(context, schemaPath, instancePath, schema, value) {
    const thenSchema = S.IsThen(schema) ? schema.then : true;
    const elseSchema = S.IsElse(schema) ? schema.else : true;
    const trueContext = new AccumulatedErrorContext(context.GetContext(), context.GetSchema());
    const isIf = ErrorSchema(trueContext, `${schemaPath}/if`, instancePath, schema.if, value)
        ? ErrorSchema(trueContext, `${schemaPath}/then`, instancePath, thenSchema, value) || context.AddError({
            keyword: 'if',
            schemaPath,
            instancePath,
            params: { failingKeyword: 'then' },
        })
        : ErrorSchema(context, `${schemaPath}/else`, instancePath, elseSchema, value) || context.AddError({
            keyword: 'if',
            schemaPath,
            instancePath,
            params: { failingKeyword: 'else' },
        });
    if (isIf)
        context.Merge([trueContext]);
    return isIf;
}
