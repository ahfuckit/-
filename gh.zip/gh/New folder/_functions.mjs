// deno-fmt-ignore-file
import { Hashing } from '../../system/hashing/index.mjs';
import { EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema } from './schema.mjs';
const functions = new Map();
// ------------------------------------------------------------------
// CreateCallExpression
// ------------------------------------------------------------------
function CreateCallExpression(context, schema, hash, value) {
    return context.UseUnevaluated()
        ? E.Call(`check_${hash}`, ['context', value])
        : E.Call(`check_${hash}`, [value]);
}
// ------------------------------------------------------------------
// CreateFunctionExpression
// ------------------------------------------------------------------
function CreateFunctionExpression(context, schema, hash) {
    const expression = BuildSchema(context, schema, 'value');
    return context.UseUnevaluated()
        ? E.ConstDeclaration(`check_${hash}`, E.ArrowFunction(['context', 'value'], expression))
        : E.ConstDeclaration(`check_${hash}`, E.ArrowFunction(['value'], expression));
}
// ------------------------------------------------------------------
// ResetFunctions
// ------------------------------------------------------------------
export function ResetFunctions() {
    functions.clear();
}
// ------------------------------------------------------------------
// GetFunctions
// ------------------------------------------------------------------
export function GetFunctions() {
    return [...functions.values()];
}
// ------------------------------------------------------------------
// CreateFunction
// ------------------------------------------------------------------
export function CreateFunction(context, schema, value) {
    const hash = Hashing.Hash(schema);
    const call = CreateCallExpression(context, schema, hash, value);
    if (functions.has(hash))
        return call;
    functions.set(hash, '');
    functions.set(hash, CreateFunctionExpression(context, schema, hash));
    return call;
}
