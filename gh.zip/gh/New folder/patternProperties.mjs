// deno-fmt-ignore-file
import * as V from './_externals.mjs';
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildPatternProperties(context, schema, value) {
    return E.ReduceAnd(G.Entries(schema.patternProperties).map(([pattern, schema]) => {
        const regexp = V.CreateExternalVariable(new RegExp(pattern));
        const notKey = E.Not(E.Call(E.Member(regexp, 'test'), ['key']));
        const isSchema = BuildSchema(context, schema, 'value');
        const addKey = context.AddKey('key');
        const guarded = context.UseUnevaluated() ? E.Or(notKey, E.And(isSchema, addKey)) : E.Or(notKey, isSchema);
        return E.Every(E.Entries(value), E.Constant(0), ['[key, value]', '_'], guarded);
    }));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckPatternProperties(context, schema, value) {
    return G.Every(G.Entries(schema.patternProperties), 0, ([pattern, schema]) => {
        const regexp = new RegExp(pattern);
        return G.Every(G.Entries(value), 0, ([key, value]) => {
            return !regexp.test(key) || CheckSchema(context, schema, value) && context.AddKey(key);
        });
    });
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorPatternProperties(context, schemaPath, instancePath, schema, value) {
    return G.EveryAll(G.Entries(schema.patternProperties), 0, ([pattern, schema]) => {
        const nextSchemaPath = `${schemaPath}/patternProperties/${pattern}`;
        const regexp = new RegExp(pattern);
        return G.EveryAll(G.Entries(value), 0, ([key, value]) => {
            const nextInstancePath = `${instancePath}/${key}`;
            const notKey = !regexp.test(key);
            return notKey || ErrorSchema(context, nextSchemaPath, nextInstancePath, schema, value) && context.AddKey(key);
        });
    });
}
