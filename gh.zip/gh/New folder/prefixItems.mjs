// deno-fmt-ignore-file
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildPrefixItems(context, schema, value) {
    return E.ReduceAnd(schema.prefixItems.map((schema, index) => {
        const isLength = E.IsLessEqualThan(E.Member(value, 'length'), E.Constant(index));
        const isSchema = BuildSchema(context, schema, `${value}[${index}]`);
        const addIndex = context.AddIndex(E.Constant(index));
        const guarded = context.UseUnevaluated() ? E.And(isSchema, addIndex) : isSchema;
        return E.Or(isLength, guarded);
    }));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckPrefixItems(context, schema, value) {
    return G.IsEqual(value.length, 0) || G.Every(schema.prefixItems, 0, (schema, index) => {
        return G.IsLessEqualThan(value.length, index)
            || (CheckSchema(context, schema, value[index]) && context.AddIndex(index));
    });
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorPrefixItems(context, schemaPath, instancePath, schema, value) {
    return G.IsEqual(value.length, 0) || G.EveryAll(schema.prefixItems, 0, (schema, index) => {
        const nextSchemaPath = `${schemaPath}/prefixItems/${index}`;
        const nextInstancePath = `${instancePath}/${index}`;
        return G.IsLessEqualThan(value.length, index)
            || (ErrorSchema(context, nextSchemaPath, nextInstancePath, schema, value[index]) && context.AddIndex(index));
    });
}
