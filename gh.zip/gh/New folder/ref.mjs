// deno-fmt-ignore-file
import { Guard } from '../../guard/index.mjs';
import { Pointer } from '../pointer/index.mjs';
import * as S from '../types/index.mjs';
// ------------------------------------------------------------------
// MatchId
// ------------------------------------------------------------------
function MatchId(value, base, ref) {
    if (value.$id === ref.hash)
        return value;
    const absoluteId = new URL(value.$id, base.href);
    const absoluteRef = new URL(ref.href, base.href);
    if (Guard.IsEqual(absoluteId.pathname, absoluteRef.pathname)) {
        return ref.hash.startsWith('#') ? MatchHash(value, base, ref) : value;
    }
    return undefined;
}
// ------------------------------------------------------------------
// MatchAnchor
// ------------------------------------------------------------------
function MatchAnchor(value, base, ref) {
    const absoluteAnchor = new URL(`#${value.$anchor}`, base.href);
    const absoluteRef = new URL(ref.href, base.href);
    if (Guard.IsEqual(absoluteAnchor.href, absoluteRef.href))
        return value;
    return undefined;
}
// ------------------------------------------------------------------
// MatchHash
// ------------------------------------------------------------------
function MatchHash(value, base, ref) {
    if (ref.href.endsWith('#'))
        return value;
    return ref.hash.startsWith('#')
        ? Pointer.Get(value, decodeURIComponent(ref.hash.slice(1)))
        : undefined;
}
// ------------------------------------------------------------------
// Match
// ------------------------------------------------------------------
function Match(value, base, ref) {
    if (S.IsId(value)) {
        const result = MatchId(value, base, ref);
        if (!Guard.IsUndefined(result))
            return result;
    }
    if (S.IsAnchor(value)) {
        const result = MatchAnchor(value, base, ref);
        if (!Guard.IsUndefined(result))
            return result;
    }
    return MatchHash(value, base, ref);
}
// ------------------------------------------------------------------
// FromArray
// ------------------------------------------------------------------
function FromArray(value, base, ref) {
    for (const item of value) {
        const result = FromValue(item, base, ref);
        if (!Guard.IsUndefined(result))
            return result;
    }
    return undefined;
}
// ------------------------------------------------------------------
// FromObject
// ------------------------------------------------------------------
function FromObject(value, base, ref) {
    for (const key of Guard.Keys(value)) {
        const result = FromValue(value[key], base, ref);
        if (!Guard.IsUndefined(result))
            return result;
    }
    return undefined;
}
// ------------------------------------------------------------------
// FromValue
// ------------------------------------------------------------------
function FromValue(value, base, ref) {
    const newbase = S.IsSchemaObject(value) && S.IsId(value) ? new URL(value.$id, ref.href) : base;
    if (S.IsSchemaObject(value)) {
        const result = Match(value, newbase, ref);
        if (!Guard.IsUndefined(result))
            return result;
    }
    if (Guard.IsArray(value))
        return FromArray(value, newbase, ref);
    if (Guard.IsObject(value))
        return FromObject(value, newbase, ref);
    return undefined;
}
// ------------------------------------------------------------------
// Ref
// ------------------------------------------------------------------
export function Ref(schema, ref) {
    const base = new URL('', 'http://domain.com');
    return FromValue(schema, base, new URL(ref, 'http://domain.com'));
}
