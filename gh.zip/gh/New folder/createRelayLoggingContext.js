'use strict';

var invariant = require('invariant');
var relayLoggingContext;
var firstReact;
function createRelayLoggingContext(react) {
  if (!relayLoggingContext) {
    relayLoggingContext = react.createContext(null);
    if (process.env.NODE_ENV !== "production") {
      relayLoggingContext.displayName = 'RelayLoggingContext';
    }
    firstReact = react;
  }
  !(react === firstReact) ? process.env.NODE_ENV !== "production" ? invariant(false, '[createRelayLoggingContext]: You are passing a different instance of React', react.version) : invariant(false) : void 0;
  return relayLoggingContext;
}
module.exports = createRelayLoggingContext;