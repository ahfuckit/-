// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema, ErrorSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Valid
// ------------------------------------------------------------------
function IsValid(schema) {
    return S.IsItems(schema) && G.IsArray(schema.items);
}
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildAdditionalItems(context, schema, value) {
    if (!IsValid(schema))
        return E.Constant(true);
    const isSchema = BuildSchema(context, schema.additionalItems, 'element');
    const isLength = E.IsLessThan('index', E.Constant(schema.items.length));
    const addIndex = context.AddIndex('index');
    const guarded = context.UseUnevaluated() ? E.Or(isLength, E.And(isSchema, addIndex)) : E.Or(isLength, isSchema);
    return E.Call(E.Member(value, 'every'), [E.ArrowFunction(['element', 'index'], guarded)]);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckAdditionalItems(context, schema, value) {
    if (!IsValid(schema))
        return true;
    const isAdditionalItems = value.every((element, index) => {
        return G.IsLessThan(index, schema.items.length)
            || (CheckSchema(context, schema.additionalItems, element) && context.AddIndex(index));
    });
    return isAdditionalItems;
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorAdditionalItems(context, schemaPath, instancePath, schema, value) {
    if (!IsValid(schema))
        return true;
    const isAdditionalItems = value.every((element, index) => {
        const nextSchemaPath = `${schemaPath}/additionalItems`;
        const nextInstancePath = `${instancePath}/${index}`;
        return G.IsLessThan(index, schema.items.length) ||
            (ErrorSchema(context, nextSchemaPath, nextInstancePath, schema.additionalItems, element) && context.AddIndex(index));
    });
    return isAdditionalItems;
}
