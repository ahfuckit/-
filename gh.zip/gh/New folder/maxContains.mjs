// deno-fmt-ignore-file
import * as S from '../types/index.mjs';
import { Guard as G, EmitGuard as E } from '../../guard/index.mjs';
import { BuildSchema, CheckSchema } from './schema.mjs';
// ------------------------------------------------------------------
// Valid
// ------------------------------------------------------------------
function IsValid(schema) {
    return S.IsContains(schema);
}
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildMaxContains(context, schema, value) {
    if (!IsValid(schema))
        return E.Constant(true);
    const count = E.Call(E.Member(value, 'reduce'), [E.ArrowFunction(['result', 'value'], E.Ternary(BuildSchema(context, schema.contains, 'value'), E.PrefixIncrement('result'), 'result')), E.Constant(0)]);
    return E.IsLessEqualThan(count, E.Constant(schema.maxContains));
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckMaxContains(context, schema, value) {
    if (!IsValid(schema))
        return true;
    const count = value.reduce((result, value) => CheckSchema(context, schema.contains, value) ? ++result : result, 0);
    return G.IsLessEqualThan(count, schema.maxContains);
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorMaxContains(context, schemaPath, instancePath, schema, value) {
    const minContains = S.IsMinContains(schema) ? schema.minContains : 1;
    return CheckMaxContains(context, schema, value) || context.AddError({
        keyword: 'contains',
        schemaPath,
        instancePath,
        params: { minContains, maxContains: schema.maxContains },
    });
}
