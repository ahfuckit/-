// deno-fmt-ignore-file
import * as F from './_functions.mjs';
import * as S from '../types/index.mjs';
import { CheckSchema, ErrorSchema } from './schema.mjs';
import { Resolver } from '../resolver/index.mjs';
// ------------------------------------------------------------------
// Resolve
// ------------------------------------------------------------------
function Resolve(context, schema) {
    // note: it is safe to coerce to XSchema here as it wouldn't be possible
    // to enter a ref resolution if the root schema was boolean.
    const schemaRoot = context.GetSchema();
    const dereferenced = Resolver.RecursiveRef(schemaRoot, schema);
    return S.IsSchema(dereferenced) ? dereferenced : false;
}
// ------------------------------------------------------------------
// Build
// ------------------------------------------------------------------
export function BuildRecursiveRef(context, schema, value) {
    const target = Resolve(context, schema);
    return F.CreateFunction(context, target, value);
}
// ------------------------------------------------------------------
// Check
// ------------------------------------------------------------------
export function CheckRecursiveRef(context, schema, value) {
    const target = Resolve(context, schema);
    return (S.IsSchema(target) && CheckSchema(context, target, value));
}
// ------------------------------------------------------------------
// Error
// ------------------------------------------------------------------
export function ErrorRecursiveRef(context, schemaPath, instancePath, schema, value) {
    const target = Resolve(context, schema);
    return (S.IsSchema(target) && ErrorSchema(context, '#', instancePath, target, value));
}
