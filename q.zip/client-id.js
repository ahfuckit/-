let fallbackClientId;
function generateClientId() {
    return `${Math.round(Math.random() * (Math.pow(2, 31) - 1))}.${Math.round(Date.now() / 1000)}`;
}
function setClientIdCookie(clientId) {
    const value = `GH1.1.${clientId}`;
    const now = Date.now();
    const expires = new Date(now + 1 * 365 * 86400 * 1000).toUTCString();
    let { domain } = document;
    if (domain.endsWith('.github.com')) {
        domain = 'github.com';
    }
    document.cookie = `_octo=${value}; expires=${expires}; path=/; domain=${domain}; secure; samesite=lax`;
}
function getClientIdFromCookie() {
    let clientId;
    const cookie = document.cookie;
    const matches = cookie.match(/_octo=([^;]+)/g);
    if (!matches) {
        return;
    }
    let latestVersion = [0, 0];
    for (const match of matches) {
        const [, value] = match.split('=');
        const [, version, ...clientIdPortions] = value.split('.');
        const semanticVersion = version.split('-').map(Number);
        if (semanticVersion > latestVersion) {
            latestVersion = semanticVersion;
            clientId = clientIdPortions.join('.');
        }
    }
    return clientId;
}
export function getOrCreateClientId() {
    try {
        const existingId = getClientIdFromCookie();
        if (existingId) {
            return existingId;
        }
        const clientId = generateClientId();
        setClientIdCookie(clientId);
        return clientId;
    }
    catch (_) {
        if (!fallbackClientId) {
            fallbackClientId = generateClientId();
        }
        return fallbackClientId;
    }
}
