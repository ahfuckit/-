import {ssrSafeDocument, IS_SERVER} from '@github-ui/ssr-utils'
import {loaded} from '@github-ui/document-ready'
import {bundler} from '@github-ui/runtime-environment'
import {isFeatureEnabled} from '@github-ui/feature-flags'
import {isLoggedIn} from '@github-ui/client-env'
import {throttle} from '@github/mini-throttle'
import {CUSTOM_METRIC_REGISTRY, type CustomMetricKey} from './registry'

// eslint-disable-next-line no-barrel-files/no-barrel-files
export type {CustomMetricKey}

let stats: PlatformBrowserStat[] = []
const chunkSize = 64 * 1024

export function sendCustomMetric({
  name,
  value,
  tags,
}: {
  name: CustomMetricKey
  value: number
  tags?: PlatformBrowserCustomMetricTags
}): void {
  const customMetric = CUSTOM_METRIC_REGISTRY[name]
  sendStats({
    customMetric: {
      ...customMetric,
      value,
      tags,
    },
    ui: bundler === 'vite-tss' ? true : false,
  })
}

export function sendStats(stat: PlatformBrowserStat, flushImmediately = false, samplingProbability = 0.5): void {
  if (IS_SERVER || isFeatureEnabled('browser_stats_disabled') === true) {
    return
  }
  if (samplingProbability < 0 || samplingProbability > 1) {
    throw new RangeError('Sampling probability must be between 0 and 1')
  }

  if (stat.timestamp === undefined) stat.timestamp = Date.now()
  stat.loggedIn = isLoggedIn()
  stat.staff = isStaff()
  stat.bundler = bundler
  stat.ui = bundler === 'vite-tss' ? true : false
  if (Math.random() < samplingProbability) {
    stats.push(stat)
  }

  if (flushImmediately) {
    flushStats()
  } else {
    throttledScheduleSendStats()
  }
}

let queued: number | null = null

const throttledScheduleSendStats = throttle(async function scheduleSendStats() {
  await loaded
  if (queued == null) {
    queued = window.requestIdleCallback(flushStats)
  }
}, 5000)

function flushStats() {
  queued = null
  if (!stats.length) {
    return
  }

  const url = ssrSafeDocument?.head?.querySelector<HTMLMetaElement>('meta[name="browser-stats-url"]')?.content
  if (!url) {
    return
  }

  const batches = getBatches(stats)

  for (const batch of batches) {
    safeSend(url, `{"stats": [${batch.join(',')}], "target": "${getUITarget()}"}`)
  }

  stats = []
}

// getBatches breaks up the list of stats into smaller batches
// that are less than 64kb in size. This is to avoid hitting the
// size limit of the beacon API.
function getBatches(items: PlatformBrowserStat[]): string[][] {
  const batches: string[][] = []
  const itemStrings = items.map(item => JSON.stringify(item))

  while (itemStrings.length > 0) {
    batches.push(makeBatch(itemStrings))
  }

  return batches
}

// makeBatch walks the items and collects batches of items that are within
// the 64kb limit. If an item is too big to fit in a batch, it is sent alone.
function makeBatch(itemStrings: string[]): string[] {
  const firstItem = itemStrings.shift()!
  const batch: string[] = [firstItem]
  let size = firstItem.length

  while (itemStrings.length > 0 && size <= chunkSize) {
    const nextItemSize = itemStrings[0]!.length

    if (size + nextItemSize <= chunkSize) {
      const itemString = itemStrings.shift()!
      batch.push(itemString)
      size += nextItemSize
    } else {
      break
    }
  }

  return batch
}

function safeSend(url: string, data: string) {
  try {
    if (navigator.sendBeacon) {
      navigator.sendBeacon(url, data)
    }
  } catch {
    // Silently ignore errors: https://github.com/github/github/issues/178088#issuecomment-829936461
  }
}

export function isStaff(): boolean {
  return !!ssrSafeDocument?.head?.querySelector<HTMLMetaElement>('meta[name="user-staff"]')?.content
}

function getUITarget() {
  return ssrSafeDocument?.head?.querySelector<HTMLMetaElement>('meta[name="ui-target"]')?.content || 'full'
}

// Flush stats before users navigate away from the page
ssrSafeDocument?.addEventListener('pagehide', flushStats)
ssrSafeDocument?.addEventListener('visibilitychange', flushStats)
"use strict";
(globalThis.webpackChunk_github_ui_github_ui = globalThis.webpackChunk_github_ui_github_ui || []).push([[10172], {
    6923: (t, e, i) => {
        i.d(e, {
            KJ: () => r,
            X3: () => s,
            g5: () => a
        });
        var n = i(56038);
        let s = void 0 === n.XC
          , r = !s;
        function a() {
            return !!s || !n.XC || !!(n.XC.querySelector('react-app[data-ssr="true"]') || n.XC.querySelector('react-partial[data-ssr="true"][partial-name="repos-overview"]'))
        }
    }
    ,
    13195: (t, e, i) => {
        i.d(e, {
            t: () => o
        });
        var n = i(87363)
          , s = i(21403)
          , r = i(97797);
        function a(t) {
            let e = t.getAttribute("data-required-value")
              , i = t.getAttribute("data-required-value-prefix");
            if (t.value === e)
                t.setCustomValidity("");
            else {
                let n = e;
                i && (n = i + n),
                t.setCustomValidity(n)
            }
        }
        (0,
        n.eC)("[data-required-value]", function(t) {
            a(t.currentTarget)
        }),
        (0,
        r.on)("change", "[data-required-value]", function(t) {
            let e = t.currentTarget;
            a(e),
            o(e.form)
        }),
        (0,
        n.eC)("[data-required-trimmed]", function(t) {
            let e = t.currentTarget;
            "" === e.value.trim() ? e.setCustomValidity(e.getAttribute("data-required-trimmed")) : e.setCustomValidity("")
        }),
        (0,
        r.on)("change", "[data-required-trimmed]", function(t) {
            let e = t.currentTarget;
            "" === e.value.trim() ? e.setCustomValidity(e.getAttribute("data-required-trimmed")) : e.setCustomValidity(""),
            o(e.form)
        }),
        (0,
        n.uE)("input[pattern],input[required],textarea[required],input[data-required-change],textarea[data-required-change],input[data-required-value],textarea[data-required-value]", t => {
            let e = t.checkValidity();
            function i() {
                let i = t.checkValidity();
                i !== e && t.form && o(t.form),
                e = i
            }
            t.addEventListener("input", i),
            t.addEventListener("blur", function e() {
                t.removeEventListener("input", i),
                t.removeEventListener("blur", e)
            })
        }
        );
        let l = new WeakMap;
        function o(t) {
            let e = t.checkValidity();
            for (let i of t.querySelectorAll("button[data-disable-invalid]"))
                i.disabled = !e
        }
        (0,
        s.lB)("button[data-disable-invalid]", {
            constructor: HTMLButtonElement,
            initialize(t) {
                let e = t.form;
                e && (l.get(e) || (e.addEventListener("change", () => o(e)),
                l.set(e, !0)),
                t.disabled = !e.checkValidity())
            }
        }),
        (0,
        s.lB)("input[data-required-change], textarea[data-required-change]", function(t) {
            let e = "radio" === t.type && t.form ? t.form.elements.namedItem(t.name).value : null;
            function i(i) {
                let n = t.form;
                if (i && "radio" === t.type && n && e)
                    for (let i of n.elements.namedItem(t.name))
                        i instanceof HTMLInputElement && i.setCustomValidity(t.value === e ? "unchanged" : "");
                else
                    t.setCustomValidity(t.value === (e || t.defaultValue) ? "unchanged" : "")
            }
            t.addEventListener("input", i),
            t.addEventListener("change", i),
            i(),
            t.form && o(t.form)
        }),
        document.addEventListener("reset", function(t) {
            if (t.target instanceof HTMLFormElement) {
                let e = t.target;
                setTimeout( () => o(e))
            }
        })
    }
    ,
    13523: (t, e, i) => {
        i.d(e, {
            $r: () => a,
            M1: () => l,
            li: () => s,
            pS: () => u,
            wE: () => o
        });
        var n = i(71315);
        let s = "X-Fetch-Nonce"
          , r = new Set;
        function a(t) {
            r.add(t)
        }
        function l() {
            return r.values().next().value || ""
        }
        function o(t) {
            let e = {};
            return void 0 !== t && (e["X-Fetch-Nonce-To-Validate"] = t),
            void 0 === t ? e[s] = l() : r.has(t) ? e[s] = t : e[s] = Array.from(r).join(","),
            e
        }
        function u() {
            let t = n.XC?.head?.querySelector('meta[name="fetch-nonce"]')?.content || "";
            t && a(t)
        }
    }
    ,
    26053: (t, e, i) => {
        i(84947),
        i(20761),
        i(74057),
        i(91707),
        i(62044),
        i(90204);
        var n = i(94147);
        i(78143),
        i(27552),
        i(72705),
        i(81028),
        i(44911),
        i(92284);
        var s = i(51987)
          , r = i(71315);
        r.cg && (r.cg.IncludeFragmentElement.prototype.fetch = function(t) {
            let e = this.getAttribute("data-nonce") || "";
            return (0,
            s.tV)(t.headers, e),
            window.fetch(t)
        }
        ),
        i(72180);
        var a = i(31635)
          , l = i(39595);
        let o = class GitCloneHelpElement extends HTMLElement {
            updateURL(t) {
                let e = t.currentTarget
                  , i = e.getAttribute("data-url") || "";
                if (this.helpField.value = i,
                e.matches(".js-git-protocol-clone-url"))
                    for (let t of this.helpTexts)
                        t.textContent = i;
                for (let t of this.cloneURLButtons)
                    t.classList.remove("selected");
                e.classList.add("selected")
            }
        }
        ;
        (0,
        a.Cg)([l.aC], o.prototype, "helpField", void 0),
        (0,
        a.Cg)([l.zV], o.prototype, "helpTexts", void 0),
        (0,
        a.Cg)([l.zV], o.prototype, "cloneURLButtons", void 0),
        o = (0,
        a.Cg)([l.p_], o);
        var u = i(35750)
          , d = i(18150)
          , h = i(85242)
          , c = i(50467)
          , m = new WeakMap
          , p = new WeakMap
          , f = new WeakMap
          , g = new WeakMap;
        let v = class MarkedTextElement extends HTMLElement {
            get query() {
                return this.ownerInput ? this.ownerInput.value : this.getAttribute("query") || ""
            }
            set query(t) {
                this.setAttribute("query", t)
            }
            get ownerInput() {
                let t = this.ownerDocument.getElementById(this.getAttribute("data-owner-input") || "");
                return t instanceof HTMLInputElement ? t : null
            }
            connectedCallback() {
                this.handleEvent(),
                this.ownerInput?.addEventListener("input", this),
                (0,
                h._)(this, f, new MutationObserver( () => this.handleEvent()))
            }
            handleEvent() {
                (0,
                u._)(this, g) && cancelAnimationFrame((0,
                u._)(this, g)),
                (0,
                h._)(this, g, requestAnimationFrame( () => this.mark()))
            }
            disconnectedCallback() {
                this.ownerInput?.removeEventListener("input", this),
                (0,
                u._)(this, f).disconnect()
            }
            mark() {
                let t = this.textContent || ""
                  , e = this.query;
                if (t === (0,
                u._)(this, m) && e === (0,
                u._)(this, p))
                    return;
                (0,
                h._)(this, m, t),
                (0,
                h._)(this, p, e),
                (0,
                u._)(this, f).disconnect();
                let i = 0
                  , n = document.createDocumentFragment();
                for (let s of (this.positions || function(t, e) {
                    let i = []
                      , n = 0;
                    for (let s = 0; s < t.length; s++) {
                        let r = t[s]
                          , a = e.indexOf(r, n);
                        if (-1 === a)
                            break;
                        n = a + 1,
                        i.push(a)
                    }
                    return i
                }
                )(e, t)) {
                    if (Number(s) !== s || s < i || s > t.length)
                        continue;
                    "" !== t.slice(i, s) && n.appendChild(document.createTextNode(t.slice(i, s))),
                    i = s + 1;
                    let e = document.createElement("mark");
                    e.textContent = t[s],
                    n.appendChild(e)
                }
                n.appendChild(document.createTextNode(t.slice(i))),
                this.replaceChildren(n),
                (0,
                u._)(this, f).observe(this, {
                    attributes: !0,
                    childList: !0,
                    subtree: !0
                })
            }
            constructor(...t) {
                super(...t),
                (0,
                d._)(this, m, {
                    writable: !0,
                    value: ""
                }),
                (0,
                d._)(this, p, {
                    writable: !0,
                    value: ""
                }),
                (0,
                d._)(this, f, {
                    writable: !0,
                    value: void 0
                }),
                (0,
                d._)(this, g, {
                    writable: !0,
                    value: void 0
                }),
                (0,
                c._)(this, "positions", void 0)
            }
        }
        ;
        (0,
        c._)(v, "observedAttributes", ["query", "data-owner-input"]),
        window.customElements.get("marked-text") || (window.MarkedTextElement = v,
        window.customElements.define("marked-text", v));
        var b = i(13195);
        let w = class PasswordStrengthElement extends HTMLElement {
            connectedCallback() {
                this.addEventListener("input", E)
            }
            disconnectedCallback() {
                this.removeEventListener("input", E)
            }
        }
        ;
        function E(t) {
            var e, i;
            let n, s = t.currentTarget;
            if (!(s instanceof w))
                return;
            let r = t.target;
            if (!(r instanceof HTMLInputElement))
                return;
            let a = r.form;
            if (!(a instanceof HTMLFormElement))
                return;
            let l = (e = r.value,
            i = {
                minimumCharacterCount: Number(s.getAttribute("minimum-character-count")),
                passphraseLength: Number(s.getAttribute("passphrase-length"))
            },
            (n = {
                valid: !1,
                hasMinimumCharacterCount: e.length >= i.minimumCharacterCount,
                hasMinimumPassphraseLength: 0 !== i.passphraseLength && e.length >= i.passphraseLength,
                hasLowerCase: /[a-z]/.test(e),
                hasNumber: /\d/.test(e)
            }).valid = n.hasMinimumPassphraseLength || n.hasMinimumCharacterCount && n.hasLowerCase && n.hasNumber,
            n);
            if (l.valid) {
                r.setCustomValidity("");
                let t = s.querySelector("dl.form-group");
                t && (t.classList.remove("errored"),
                t.classList.add("successed"))
            } else
                "true" !== s.getAttribute("skip-custom-validity") && r.setCustomValidity(s.getAttribute("invalid-message") || "Invalid");
            (function(t, e) {
                let i = t.querySelector("[data-more-than-n-chars]")
                  , n = t.querySelector("[data-min-chars]")
                  , s = t.querySelector("[data-number-requirement]")
                  , r = t.querySelector("[data-letter-requirement]")
                  , a = t.getAttribute("error-class")?.split(" ").filter(t => t.length > 0) || []
                  , l = t.getAttribute("pass-class")?.split(" ").filter(t => t.length > 0) || [];
                for (let t of [i, n, s, r])
                    t?.classList.remove(...a, ...l);
                if (e.hasMinimumPassphraseLength && i)
                    i.classList.add(...l);
                else if (e.valid)
                    n.classList.add(...l),
                    s.classList.add(...l),
                    r.classList.add(...l);
                else {
                    let t = e.hasMinimumCharacterCount ? l : a
                      , o = e.hasNumber ? l : a
                      , u = e.hasLowerCase ? l : a;
                    i?.classList.add(...a),
                    n.classList.add(...t),
                    s.classList.add(...o),
                    r.classList.add(...u)
                }
            }
            )(s, l),
            (0,
            b.t)(a)
        }
        window.customElements.get("password-strength") || (window.PasswordStrengthElement = w,
        window.customElements.define("password-strength", w)),
        i(92454);
        let y = class PollIncludeFragmentElement extends n.T {
            async fetch(t, e) {
                let i = await super.fetch(t)
                  , n = e || this.intervalMilliseconds;
                (!n || isNaN(n)) && (n = 1e3);
                let s = isNaN(this.backoffMultiplier) ? 1.5 : this.backoffMultiplier;
                return 202 === i.status ? (await new Promise(t => {
                    this.pollingTimeout = setTimeout(t, n)
                }
                ),
                this.fetch(t, n * s)) : i
            }
            refetch() {
                return this.cancelPolling(),
                super.refetch()
            }
            connectedCallback() {
                super.connectedCallback(),
                this.retryButton && this.retryButton.addEventListener("click", () => {
                    this.refetch()
                }
                )
            }
            disconnectedCallback() {
                this.cancelPolling()
            }
            cancelPolling() {
                this.pollingTimeout && clearTimeout(this.pollingTimeout)
            }
            constructor(...t) {
                super(...t),
                (0,
                c._)(this, "intervalMilliseconds", 1e3),
                (0,
                c._)(this, "backoffMultiplier", 1.5),
                (0,
                c._)(this, "pollingTimeout", null)
            }
        }
        ;
        (0,
        a.Cg)([l.aC], y.prototype, "retryButton", void 0),
        (0,
        a.Cg)([l.CF], y.prototype, "intervalMilliseconds", void 0),
        (0,
        a.Cg)([l.CF], y.prototype, "backoffMultiplier", void 0),
        y = (0,
        a.Cg)([l.p_], y);
        var C = i(35908);
        let _ = t => void 0 === t || /\n/.test(t)
          , x = ["position:absolute;", "overflow:auto;", "word-wrap:break-word;", "top:0px;", "left:-9999px;"]
          , L = ["box-sizing", "font-family", "font-size", "font-style", "font-variant", "font-weight", "height", "letter-spacing", "line-height", "max-height", "min-height", "padding-bottom", "padding-left", "padding-right", "padding-top", "border-bottom", "border-left", "border-right", "border-top", "text-decoration", "text-indent", "text-transform", "width", "word-spacing"]
          , k = new WeakMap
          , M = new WeakMap
          , A = class SlashCommandExpander {
            destroy() {
                this.input.removeEventListener("paste", this.onpaste),
                this.input.removeEventListener("input", this.oninput),
                this.input.removeEventListener("keydown", this.onkeydown),
                this.input.removeEventListener("blur", this.onblur)
            }
            activate(t, e) {
                this.input === document.activeElement && this.setMenu(t, e)
            }
            deactivate() {
                let t = this.menu
                  , e = this.combobox;
                return !!t && !!e && (this.createLink?.removeEventListener("hotkey-fire", this.onCreateCommandLinkKeyDown),
                this.menu = null,
                this.createLink = null,
                this.combobox = null,
                t.removeEventListener("combobox-commit", this.oncommit),
                t.removeEventListener("mousedown", this.onmousedown),
                e.destroy(),
                t.remove(),
                !0)
            }
            setMenu(t, e) {
                this.deactivate(),
                this.menu = e,
                this.createLink = e.querySelector(".js-slash-command-menu-create-link"),
                e.id || (e.id = `text-expander-${Math.floor(1e5 * Math.random()).toString()}`),
                this.expander.append(e);
                let i = e.querySelector(".js-command-list-container")
                  , n = {
                    tabInsertsSuggestions: !1
                };
                i ? this.combobox = new C.A(this.input,i,n) : this.combobox = new C.A(this.input,e,n);
                let {top: s, left: r} = function(t, e=t.selectionEnd) {
                    let {mirror: i, marker: n} = function(t, e) {
                        let i, n, s = t.nodeName.toLowerCase();
                        if ("textarea" !== s && "input" !== s)
                            throw Error("expected textField to a textarea or input");
                        let r = k.get(t);
                        if (r && r.parentElement === t.parentElement)
                            r.textContent = "";
                        else {
                            r = document.createElement("div"),
                            k.set(t, r);
                            let e = window.getComputedStyle(t)
                              , i = x.slice(0);
                            "textarea" === s ? i.push("white-space:pre-wrap;") : i.push("white-space:nowrap;");
                            for (let t = 0, n = L.length; t < n; t++) {
                                let n = L[t];
                                i.push(`${n}:${e.getPropertyValue(n)};`)
                            }
                            r.style.cssText = i.join(" ")
                        }
                        let a = document.createElement("span");
                        if (a.style.cssText = "position: absolute;",
                        a.textContent = "\xa0",
                        "number" == typeof e) {
                            let s = t.value.substring(0, e);
                            s && (i = document.createTextNode(s)),
                            (s = t.value.substring(e)) && (n = document.createTextNode(s))
                        } else {
                            let e = t.value;
                            e && (i = document.createTextNode(e))
                        }
                        if (i && r.appendChild(i),
                        r.appendChild(a),
                        n && r.appendChild(n),
                        !r.parentElement) {
                            if (!t.parentElement)
                                throw Error("textField must have a parentElement to mirror");
                            t.parentElement.insertBefore(r, t)
                        }
                        return r.scrollTop = t.scrollTop,
                        r.scrollLeft = t.scrollLeft,
                        {
                            mirror: r,
                            marker: a
                        }
                    }(t, e)
                      , s = i.getBoundingClientRect()
                      , r = n.getBoundingClientRect();
                    return setTimeout( () => {
                        i.remove()
                    }
                    , 5e3),
                    {
                        top: r.top - s.top,
                        left: r.left - s.left
                    }
                }(this.input, t.position)
                  , a = parseInt(window.getComputedStyle(this.input).fontSize);
                e.style.top = `${s + a}px`,
                e.style.left = `${r}px`,
                this.combobox.start(),
                e.addEventListener("combobox-commit", this.oncommit),
                e.addEventListener("mousedown", this.onmousedown),
                this.createLink?.addEventListener("hotkey-fire", this.onCreateCommandLinkKeyDown),
                this.combobox.navigate(1)
            }
            setValue(t) {
                if (null == t)
                    return;
                let e = this.match;
                if (!e)
                    return;
                let {cursor: i, value: n} = this.replaceCursorMark(t);
                n = n?.length === 0 ? n : `${n} `;
                let s = e.position - e.key.length
                  , r = e.position + e.text.length;
                this.input.focus();
                let a = !1;
                try {
                    this.input.setSelectionRange(s, r),
                    a = document.execCommand("insertText", !1, n)
                } catch {
                    a = !1
                }
                if (!a) {
                    let t = this.input.value.substring(0, e.position - e.key.length)
                      , i = this.input.value.substring(e.position + e.text.length);
                    this.input.value = t + n + i
                }
                this.deactivate(),
                i = s + (i || n.length),
                this.input.selectionStart = i,
                this.input.selectionEnd = i
            }
            replaceCursorMark(t) {
                let e = /%cursor%/gm
                  , i = e.exec(t);
                return i ? {
                    cursor: i.index,
                    value: t.replace(e, "")
                } : {
                    cursor: null,
                    value: t
                }
            }
            async onCommit({target: t}) {
                if (!(t instanceof HTMLElement) || !this.combobox)
                    return;
                let e = this.match;
                if (!e)
                    return;
                let n = {
                    item: t,
                    key: e.key,
                    value: null
                }
                  , s = new CustomEvent("text-expander-value",{
                    cancelable: !0,
                    detail: n
                })
                  , r = !this.expander.dispatchEvent(s)
                  , {onValue: a} = await i.e(25430).then(i.bind(i, 25430));
                await a(this.expander, e.key, t),
                !r && n.value && this.setValue(n.value)
            }
            onBlur() {
                if (this.interactingWithMenu) {
                    this.interactingWithMenu = !1;
                    return
                }
                this.deactivate()
            }
            onPaste() {
                this.justPasted = !0
            }
            async delay(t) {
                return new Promise(e => setTimeout(e, t))
            }
            async onInput() {
                if (this.justPasted) {
                    this.justPasted = !1;
                    return
                }
                let t = this.findMatch();
                if (t) {
                    if (this.match = t,
                    await this.delay(this.appropriateDelay()),
                    this.match !== t)
                        return;
                    let e = await this.notifyProviders(t);
                    if (!this.match)
                        return;
                    e ? this.activate(t, e) : this.deactivate()
                } else
                    this.match = null,
                    this.deactivate()
            }
            appropriateDelay() {
                return 250
            }
            findMatch() {
                let t = this.input.selectionEnd
                  , e = this.input.value;
                for (let i of this.expander.getKeys()) {
                    let n = function(t, e, i) {
                        let n = t.lastIndexOf(e, i - 1);
                        if (-1 === n || t.lastIndexOf(" ", i - 1) > n || t.lastIndexOf(`
`, i - 1) > n)
                            return;
                        let s = t[n - 1];
                        if (!s || `
` === s)
                            return {
                                word: t.substring(n + e.length, i),
                                position: n + e.length,
                                beginningOfLine: _(s)
                            }
                    }(e, i, t);
                    if (n)
                        return {
                            text: n.word,
                            key: i,
                            position: n.position,
                            beginningOfLine: n.beginningOfLine
                        }
                }
            }
            async notifyProviders(t) {
                let e = []
                  , n = t => e.push(t)
                  , s = new CustomEvent("text-expander-change",{
                    cancelable: !0,
                    detail: {
                        provide: n,
                        text: t.text,
                        key: t.key
                    }
                });
                if (!this.expander.dispatchEvent(s))
                    return;
                let {onChange: r} = await i.e(25430).then(i.bind(i, 25430));
                return r(this.expander, t.key, n, t.text),
                (await Promise.all(e)).filter(t => t.matched).map(t => t.fragment)[0]
            }
            onMousedown() {
                this.interactingWithMenu = !0
            }
            onKeydown(t) {
                if ("Tab" === t.key && this.createLink) {
                    t.stopImmediatePropagation(),
                    t.preventDefault();
                    let e = this.combobox;
                    this.combobox = null,
                    this.createLink.focus(),
                    this.combobox = e;
                    return
                }
                "Escape" === t.key && this.deactivate() && (t.stopImmediatePropagation(),
                t.preventDefault())
            }
            onCreateCommandLinkKeyDown(t) {
                t.stopImmediatePropagation(),
                t.preventDefault(),
                this.input?.focus()
            }
            constructor(t, e) {
                (0,
                c._)(this, "expander", void 0),
                (0,
                c._)(this, "input", void 0),
                (0,
                c._)(this, "menu", void 0),
                (0,
                c._)(this, "createLink", void 0),
                (0,
                c._)(this, "oninput", void 0),
                (0,
                c._)(this, "onkeydown", void 0),
                (0,
                c._)(this, "onpaste", void 0),
                (0,
                c._)(this, "oncommit", void 0),
                (0,
                c._)(this, "onblur", void 0),
                (0,
                c._)(this, "onmousedown", void 0),
                (0,
                c._)(this, "combobox", void 0),
                (0,
                c._)(this, "match", void 0),
                (0,
                c._)(this, "justPasted", void 0),
                (0,
                c._)(this, "interactingWithMenu", void 0),
                this.expander = t,
                this.input = e,
                this.combobox = null,
                this.menu = null,
                this.createLink = null,
                this.match = null,
                this.justPasted = !1,
                this.oninput = this.onInput.bind(this),
                this.onpaste = this.onPaste.bind(this),
                this.onkeydown = this.onKeydown.bind(this),
                this.oncommit = this.onCommit.bind(this),
                this.onmousedown = this.onMousedown.bind(this),
                this.onblur = this.onBlur.bind(this),
                this.onCreateCommandLinkKeyDown = this.onCreateCommandLinkKeyDown.bind(this),
                this.interactingWithMenu = !1,
                e.addEventListener("paste", this.onpaste),
                e.addEventListener("input", this.oninput),
                e.addEventListener("keydown", this.onkeydown),
                e.addEventListener("blur", this.onblur)
            }
        }
          , T = class SlashCommandExpanderElement extends HTMLElement {
            getKeys() {
                let t = this.getAttribute("keys");
                return t ? t.split(" ") : []
            }
            connectedCallback() {
                let t = this.querySelector('input[type="text"], textarea');
                if (!(t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement))
                    return;
                let e = new A(this,t);
                M.set(this, e)
            }
            reconnect() {
                if (null !== this.querySelector(".js-slash-command-menu:not(.d-none)"))
                    return;
                let t = M.get(this);
                t && (t.destroy(),
                M.delete(this)),
                this.connectedCallback()
            }
            disconnectedCallback() {
                let t = M.get(this);
                t && (t.destroy(),
                M.delete(this))
            }
            setValue(t) {
                let e = M.get(this);
                e && e.setValue(t)
            }
            setMenu(t, e=!1) {
                let i = M.get(this);
                !i || i.match && (e && (i.interactingWithMenu = !0),
                i.setMenu(i.match, t))
            }
            closeMenu() {
                let t = M.get(this);
                t && t.setValue("")
            }
            isLoading() {
                let t = this.getElementsByClassName("js-slash-command-expander-loading")[0];
                if (t) {
                    let e = t.cloneNode(!0);
                    e.classList.remove("d-none"),
                    this.setMenu(e)
                }
            }
            showError() {
                let t = this.getElementsByClassName("js-slash-command-expander-error")[0];
                if (t) {
                    let e = t.cloneNode(!0);
                    e.classList.remove("d-none"),
                    this.setMenu(e)
                }
            }
        }
        ;
        window.customElements.get("slash-command-expander") || (window.SlashCommandExpanderElement = T,
        window.customElements.define("slash-command-expander", T));
        let S = class TextSuggesterElement extends HTMLElement {
            acceptSuggestion() {
                this.suggestion?.textContent && (this.input.value = this.suggestion.textContent,
                this.input.dispatchEvent(new Event("input")),
                this.suggestionContainer && (this.suggestionContainer.hidden = !0),
                this.input.focus())
            }
        }
        ;
        (0,
        a.Cg)([l.aC], S.prototype, "input", void 0),
        (0,
        a.Cg)([l.aC], S.prototype, "suggestionContainer", void 0),
        (0,
        a.Cg)([l.aC], S.prototype, "suggestion", void 0),
        S = (0,
        a.Cg)([l.p_], S);
        var q = new WeakMap
          , I = new WeakMap
          , N = new WeakMap
          , V = new WeakMap
          , z = new WeakMap
          , F = new WeakMap;
        let H = class VirtualFilterInputElement extends HTMLElement {
            static get observedAttributes() {
                return ["src", "loading", "data-property", "aria-owns"]
            }
            get filtered() {
                if ((0,
                u._)(this, F))
                    return (0,
                    u._)(this, F);
                if (this.hasAttribute("aria-owns")) {
                    let t = this.ownerDocument.getElementById(this.getAttribute("aria-owns") || "");
                    t && (t instanceof Set || t && "object" == typeof t && "size"in t && "add"in t && "delete"in t && "clear"in t) && (0,
                    h._)(this, F, t)
                }
                return (0,
                h._)(this, F, (0,
                u._)(this, F) || new Set)
            }
            set filtered(t) {
                (0,
                h._)(this, F, t)
            }
            get input() {
                return this.querySelector("input, textarea")
            }
            get src() {
                return this.getAttribute("src") || ""
            }
            set src(t) {
                this.setAttribute("src", t)
            }
            get loading() {
                return "lazy" === this.getAttribute("loading") ? "lazy" : "eager"
            }
            set loading(t) {
                this.setAttribute("loading", t)
            }
            get accept() {
                return this.getAttribute("accept") || ""
            }
            set accept(t) {
                this.setAttribute("accept", t)
            }
            get property() {
                return this.getAttribute("data-property") || ""
            }
            set property(t) {
                this.setAttribute("data-property", t)
            }
            reset() {
                this.filtered.clear(),
                (0,
                h._)(this, z, new Set)
            }
            clear() {
                this.input && (this.input.value = "",
                this.input.dispatchEvent(new Event("input")))
            }
            attributeChangedCallback(t, e, i) {
                let n = this.isConnected && this.src
                  , s = "eager" === this.loading
                  , r = e !== i;
                ("src" === t || "data-property" === t) && r && ((0,
                h._)(this, N, null),
                (0,
                u._)(this, V) && clearTimeout((0,
                u._)(this, V))),
                n && s && ("src" === t || "loading" === t || "accept" === t || "data-property" === t) && r ? (cancelAnimationFrame((0,
                u._)(this, I)),
                (0,
                h._)(this, I, requestAnimationFrame( () => this.load()))) : "aria-owns" === t && (0,
                h._)(this, F, null)
            }
            connectedCallback() {
                this.src && "eager" === this.loading && (cancelAnimationFrame((0,
                u._)(this, I)),
                (0,
                h._)(this, I, requestAnimationFrame( () => this.load())));
                let t = this.input;
                if (!t)
                    return;
                let e = this.getAttribute("aria-owns");
                null !== e && this.attributeChangedCallback("aria-owns", "", e),
                t.setAttribute("autocomplete", "off"),
                t.setAttribute("spellcheck", "false"),
                this.src && "lazy" === this.loading && (document.activeElement === t ? this.load() : t.addEventListener("focus", () => {
                    this.load()
                }
                , {
                    once: !0
                })),
                t.addEventListener("input", this)
            }
            disconnectedCallback() {
                this.input?.removeEventListener("input", this)
            }
            handleEvent(t) {
                "input" === t.type && ((0,
                u._)(this, V) && clearTimeout((0,
                u._)(this, V)),
                (0,
                h._)(this, V, window.setTimeout( () => this.filterItems(), (this.input?.value?.length,
                300))))
            }
            async load() {
                (0,
                u._)(this, q)?.abort(),
                (0,
                h._)(this, q, new AbortController);
                let {signal: t} = (0,
                u._)(this, q);
                if (!this.src)
                    throw Error("missing src");
                if (await new Promise(t => setTimeout(t, 0)),
                !t.aborted) {
                    this.dispatchEvent(new Event("loadstart"));
                    try {
                        let e = await this.fetch(this.request(), {
                            signal: t,
                            headers: {
                                ...(0,
                                s.kt)()
                            }
                        });
                        if (location.origin + this.src !== e.url)
                            return;
                        if (!e.ok)
                            throw Error(`Failed to load resource: the server responded with a status of ${e.status}`);
                        (0,
                        h._)(this, z, new Set((await e.json())[this.property])),
                        (0,
                        h._)(this, N, null),
                        this.dispatchEvent(new Event("loadend"))
                    } catch (e) {
                        if (t.aborted)
                            return void this.dispatchEvent(new Event("loadend"));
                        throw (async () => {
                            this.dispatchEvent(new Event("error")),
                            this.dispatchEvent(new Event("loadend"))
                        }
                        )(),
                        e
                    }
                    this.filtered.clear(),
                    this.filterItems()
                }
            }
            request() {
                return new Request(this.src,{
                    method: "GET",
                    credentials: "same-origin",
                    headers: {
                        Accept: this.accept || "application/json"
                    }
                })
            }
            fetch(t, e) {
                return fetch(t, e)
            }
            filterItems() {
                let t, e = this.input?.value.trim() ?? "", i = (0,
                u._)(this, N);
                if ((0,
                h._)(this, N, e),
                e !== i) {
                    for (let n of (this.dispatchEvent(new CustomEvent("virtual-filter-input-filter")),
                    i && e.includes(i) ? t = this.filtered : (t = (0,
                    u._)(this, z),
                    this.filtered.clear()),
                    t))
                        this.filter(n, e) ? this.filtered.add(n) : this.filtered.delete(n);
                    this.dispatchEvent(new CustomEvent("virtual-filter-input-filtered"))
                }
            }
            constructor(...t) {
                super(...t),
                (0,
                d._)(this, q, {
                    writable: !0,
                    value: void 0
                }),
                (0,
                d._)(this, I, {
                    writable: !0,
                    value: 0
                }),
                (0,
                d._)(this, N, {
                    writable: !0,
                    value: null
                }),
                (0,
                d._)(this, V, {
                    writable: !0,
                    value: void 0
                }),
                (0,
                d._)(this, z, {
                    writable: !0,
                    value: new Set
                }),
                (0,
                d._)(this, F, {
                    writable: !0,
                    value: null
                }),
                (0,
                c._)(this, "filter", (t, e) => String(t).includes(e))
            }
        }
        ;
        window.customElements.get("virtual-filter-input") || (window.VirtualFilterInputElement = H,
        window.customElements.define("virtual-filter-input", H));
        let W = new IntersectionObserver(t => {
            for (let e of t)
                e.isIntersecting && e.target instanceof K && "eager" === e.target.updating && e.target.update()
        }
        );
        var B = new WeakMap
          , P = new WeakMap
          , R = new WeakMap
          , j = new WeakMap
          , D = new WeakMap
          , O = new WeakMap
          , X = new WeakMap;
        let K = class VirtualListElement extends HTMLElement {
            static get observedAttributes() {
                return ["data-updating", "aria-activedescendant"]
            }
            get updating() {
                return "lazy" === this.getAttribute("data-updating") ? "lazy" : "eager"
            }
            set updating(t) {
                this.setAttribute("data-updating", t)
            }
            get size() {
                return (0,
                u._)(this, P).size
            }
            get range() {
                let t = this.getBoundingClientRect().height
                  , {scrollTop: e} = this
                  , i = `${e}-${t}`;
                if ((0,
                u._)(this, D).has(i))
                    return (0,
                    u._)(this, D).get(i);
                let n = 0
                  , s = 0
                  , r = 0
                  , a = 0
                  , l = (0,
                u._)(this, R);
                for (let i of (0,
                u._)(this, P)) {
                    let o = l.get(i) || (0,
                    u._)(this, j);
                    if (r + o < e)
                        r += o,
                        n += 1,
                        s += 1;
                    else if (a - o < t)
                        a += o,
                        s += 1;
                    else if (a >= t)
                        break
                }
                return [n, s]
            }
            get list() {
                let t = this.querySelector("ul, ol, tbody");
                if (!t)
                    throw Error("virtual-list must have a container element inside: any of <ul>, <ol>, <tbody>");
                return t
            }
            attributeChangedCallback(t, e, i) {
                if (e === i || !this.isConnected)
                    return;
                let n = "data-updating" === t && "eager" === i
                  , s = "data-sorted" === t && this.hasAttribute("data-sorted");
                if ((n || s) && this.update(),
                "aria-activedescendant" === t) {
                    let t = this.getIndexByElementId(i);
                    this.dispatchEvent(new ActiveDescendantChangedEvent(t,i)),
                    "eager" === this.updating && this.update()
                }
            }
            connectedCallback() {
                this.addEventListener("scroll", () => this.update()),
                this.updateSync = this.updateSync.bind(this),
                W.observe(this)
            }
            update() {
                (0,
                u._)(this, X) && cancelAnimationFrame((0,
                u._)(this, X)),
                !(0,
                u._)(this, B) && this.hasAttribute("data-sorted") ? (0,
                h._)(this, X, requestAnimationFrame( () => {
                    this.dispatchEvent(new CustomEvent("virtual-list-sort",{
                        cancelable: !0
                    })) && this.sort()
                }
                )) : (0,
                h._)(this, X, requestAnimationFrame(this.updateSync))
            }
            renderItem(t) {
                let e = {
                    item: t,
                    fragment: document.createDocumentFragment()
                };
                return this.dispatchEvent(new CustomEvent("virtual-list-render-item",{
                    detail: e
                })),
                e.fragment.children[0]
            }
            recalculateHeights(t) {
                let e = this.list;
                if (!e)
                    return;
                let i = this.renderItem(t);
                if (!i)
                    return;
                e.append(i);
                let n = e.children[0].getBoundingClientRect().height;
                e.replaceChildren(),
                n && ((0,
                h._)(this, j, n),
                (0,
                u._)(this, R).set(t, n))
            }
            getIndexByElementId(t) {
                if (!t)
                    return -1;
                let e = 0;
                for (let[,i] of (0,
                u._)(this, O)) {
                    if (i.id === t || i.querySelector(`#${t}`))
                        return e;
                    e++
                }
                return -1
            }
            updateSync() {
                let t = this.list
                  , [e,i] = this.range;
                if (i < e || !this.dispatchEvent(new CustomEvent("virtual-list-update",{
                    cancelable: !0
                })))
                    return;
                let n = new Map
                  , s = (0,
                u._)(this, O)
                  , r = -1
                  , a = !0
                  , l = 0
                  , o = 0
                  , d = 0;
                for (let t of (0,
                u._)(this, P)) {
                    if (-1 !== r || Number.isFinite((0,
                    u._)(this, j)) && 0 !== (0,
                    u._)(this, j) || this.recalculateHeights(t),
                    r += 1,
                    d = (0,
                    u._)(this, R).get(t) || (0,
                    u._)(this, j),
                    r < e) {
                        l += d,
                        o = l;
                        continue
                    }
                    if (r > i) {
                        a = !1;
                        break
                    }
                    let h = null;
                    if (s.has(t))
                        h = s.get(t);
                    else {
                        if (!(h = this.renderItem(t)))
                            continue;
                        h.querySelector("[aria-setsize]")?.setAttribute("aria-setsize", (0,
                        u._)(this, P).size.toString()),
                        h.querySelector("[aria-posinset]")?.setAttribute("aria-posinset", (r + 1).toString()),
                        s.set(t, h)
                    }
                    h.querySelector("[tabindex]")?.setAttribute("data-scrolltop", o.toString()),
                    o += d,
                    n.set(t, h)
                }
                t.replaceChildren(...n.values()),
                t.style.paddingTop = `${l}px`;
                let h = this.size * (0,
                u._)(this, j);
                t.style.height = `${h || 0}px`;
                let c = !1
                  , m = this.getBoundingClientRect().bottom;
                for (let[t,e] of n) {
                    let {height: i, bottom: n} = e.getBoundingClientRect();
                    c = c || n >= m,
                    (0,
                    u._)(this, R).set(t, i)
                }
                if (!a && this.size > n.size && !c)
                    return (0,
                    u._)(this, D).delete(`${this.scrollTop}-${this.getBoundingClientRect().height}`),
                    this.update();
                this.dispatchEvent(new RenderedEvent(s)),
                this.dispatchEvent(new CustomEvent("virtual-list-updated"))
            }
            resetRenderCache() {
                (0,
                h._)(this, O, new Map)
            }
            has(t) {
                return (0,
                u._)(this, P).has(t)
            }
            add(t) {
                return (0,
                u._)(this, P).add(t),
                (0,
                h._)(this, B, !1),
                Number.isFinite((0,
                u._)(this, j)) || this.recalculateHeights(t),
                this.resetRenderCache(),
                this.dispatchEvent(new Event("virtual-list-data-updated")),
                "eager" === this.updating && this.update(),
                this
            }
            delete(t) {
                let e = (0,
                u._)(this, P).delete(t);
                return (0,
                h._)(this, B, !1),
                (0,
                u._)(this, R).delete(t),
                this.resetRenderCache(),
                this.dispatchEvent(new Event("virtual-list-data-updated")),
                "eager" === this.updating && this.update(),
                e
            }
            clear() {
                (0,
                u._)(this, P).clear(),
                (0,
                u._)(this, R).clear(),
                (0,
                h._)(this, j, 1 / 0),
                (0,
                h._)(this, B, !0),
                this.resetRenderCache(),
                this.dispatchEvent(new Event("virtual-list-data-updated")),
                "eager" === this.updating && this.update()
            }
            forEach(t, e) {
                for (let i of this)
                    t.call(e, i, i, this)
            }
            entries() {
                return (0,
                u._)(this, P).entries()
            }
            values() {
                return (0,
                u._)(this, P).values()
            }
            keys() {
                return (0,
                u._)(this, P).keys()
            }
            [Symbol.iterator]() {
                return (0,
                u._)(this, P)[Symbol.iterator]()
            }
            sort(t) {
                return (0,
                h._)(this, P, new Set(Array.from(this).sort(t))),
                (0,
                h._)(this, B, !0),
                this.dispatchEvent(new Event("virtual-list-data-updated")),
                "eager" === this.updating && this.update(),
                this
            }
            constructor(...t) {
                super(...t),
                (0,
                d._)(this, B, {
                    writable: !0,
                    value: !1
                }),
                (0,
                d._)(this, P, {
                    writable: !0,
                    value: new Set
                }),
                (0,
                d._)(this, R, {
                    writable: !0,
                    value: new Map
                }),
                (0,
                d._)(this, j, {
                    writable: !0,
                    value: 1 / 0
                }),
                (0,
                d._)(this, D, {
                    writable: !0,
                    value: new Map
                }),
                (0,
                d._)(this, O, {
                    writable: !0,
                    value: new Map
                }),
                (0,
                d._)(this, X, {
                    writable: !0,
                    value: 0
                }),
                (0,
                c._)(this, Symbol.toStringTag, "VirtualListElement")
            }
        }
        ;
        let ActiveDescendantChangedEvent = class ActiveDescendantChangedEvent extends Event {
            constructor(t, e) {
                super("virtual-list-activedescendant-changed"),
                (0,
                c._)(this, "index", void 0),
                (0,
                c._)(this, "id", void 0),
                this.index = t,
                this.id = e
            }
        }
        ;
        let RenderedEvent = class RenderedEvent extends Event {
            constructor(t) {
                super("virtual-list-rendered"),
                (0,
                c._)(this, "rowsCache", void 0),
                this.rowsCache = t
            }
        }
        ;
        window.customElements.get("virtual-list") || (window.VirtualListElement = K,
        window.customElements.define("virtual-list", K))
    }
    ,
    51987: (t, e, i) => {
        i.d(e, {
            jC: () => l,
            kt: () => r,
            tV: () => a
        });
        var n = i(87057)
          , s = i(13523);
        function r(t) {
            let e = {
                "X-Requested-With": "XMLHttpRequest",
                ...(0,
                s.wE)(t)
            };
            return {
                ...e,
                [n.S]: (0,
                n.O)()
            }
        }
        function a(t, e) {
            for (let[i,n] of Object.entries(r(e)))
                t.set(i, n)
        }
        function l(t) {
            return {
                "X-GitHub-App-Type": t
            }
        }
    }
    ,
    56038: (t, e, i) => {
        i.d(e, {
            Kn: () => a,
            XC: () => s,
            cg: () => r,
            fV: () => l
        });
        let n = "undefined" != typeof FORCE_SERVER_ENV && FORCE_SERVER_ENV
          , s = "undefined" == typeof document || n ? void 0 : document
          , r = "undefined" == typeof window || n ? void 0 : window
          , a = "undefined" == typeof history || n ? void 0 : history
          , l = "undefined" == typeof location || n ? {
            get pathname() {
                return (void 0) ?? ""
            },
            get origin() {
                return (void 0) ?? ""
            },
            get search() {
                return (void 0) ?? ""
            },
            get hash() {
                return (void 0) ?? ""
            },
            get href() {
                return (void 0) ?? ""
            }
        } : location
    }
    ,
    71315: (t, e, i) => {
        i.d(e, {
            KJ: () => n.KJ,
            Kn: () => s.Kn,
            X3: () => n.X3,
            XC: () => s.XC,
            cg: () => s.cg,
            fV: () => s.fV,
            g5: () => n.g5
        });
        var n = i(6923)
          , s = i(56038)
    }
    ,
    72180: (t, e, i) => {
        i.d(e, {
            A: () => h
        });
        var n = i(91385);
        let s = (t, e, i) => {
            if (!(0,
            n.qA)(t, e))
                return -1 / 0;
            let s = (0,
            n.fN)(t, e);
            return s < i ? -1 / 0 : s
        }
          , r = (t, e, i) => {
            t.textContent = "";
            let s = 0;
            for (let r of (0,
            n.Xq)(e, i)) {
                "" !== i.slice(s, r) && t.appendChild(document.createTextNode(i.slice(s, r))),
                s = r + 1;
                let e = document.createElement("mark");
                e.textContent = i[r],
                t.appendChild(e)
            }
            t.appendChild(document.createTextNode(i.slice(s)))
        }
          , a = new WeakMap
          , l = new WeakMap
          , o = new WeakMap
          , u = t => {
            if (!o.has(t) && t instanceof HTMLElement) {
                let e = (t.getAttribute("data-value") || t.textContent || "").trim();
                return o.set(t, e),
                e
            }
            return o.get(t) || ""
        }
          , d = class FuzzyListElement extends HTMLElement {
            connectedCallback() {
                let t = this.querySelector("ul");
                if (!t)
                    return;
                let e = new Set(t.querySelectorAll("li"))
                  , i = this.querySelector("input");
                i instanceof HTMLInputElement && i.addEventListener("input", () => {
                    this.value = i.value
                }
                );
                let s = new MutationObserver(t => {
                    let i = !1;
                    for (let s of t)
                        if ("childList" === s.type && s.addedNodes.length) {
                            for (let t of s.addedNodes)
                                if (t instanceof HTMLLIElement && !e.has(t)) {
                                    let s = u(t);
                                    i = i || (0,
                                    n.qA)(this.value, s),
                                    e.add(t)
                                }
                        }
                    i && this.sort()
                }
                );
                s.observe(t, {
                    childList: !0
                });
                let r = {
                    handler: s,
                    items: e,
                    lazyItems: new Map,
                    timer: null
                };
                l.set(this, r)
            }
            disconnectedCallback() {
                let t = l.get(this);
                t && (t.handler.disconnect(),
                l.delete(this))
            }
            addLazyItems(t, e) {
                let i = l.get(this);
                if (!i)
                    return;
                let {lazyItems: s} = i
                  , {value: r} = this
                  , a = !1;
                for (let i of t)
                    s.set(i, e),
                    a = a || !!r && (0,
                    n.qA)(r, i);
                a && this.sort()
            }
            sort() {
                let t = a.get(this);
                t && (t.aborted = !0);
                let e = {
                    aborted: !1
                };
                a.set(this, e);
                let {minScore: i, markSelector: n, maxMatches: d, value: h} = this
                  , c = l.get(this);
                if (!c || !this.dispatchEvent(new CustomEvent("fuzzy-list-will-sort",{
                    cancelable: !0,
                    detail: h
                })))
                    return;
                let {items: m, lazyItems: p} = c
                  , f = this.hasAttribute("mark-selector")
                  , g = this.querySelector("ul");
                if (!g)
                    return;
                let v = [];
                if (h) {
                    for (let t of m) {
                        let e = s(h, u(t), i);
                        e !== -1 / 0 && v.push({
                            item: t,
                            score: e
                        })
                    }
                    for (let[t,e] of p) {
                        let n = s(h, t, i);
                        n !== -1 / 0 && v.push({
                            text: t,
                            render: e,
                            score: n
                        })
                    }
                    v.sort( (t, e) => e.score - t.score).splice(d)
                } else {
                    let t = v.length;
                    for (let e of m) {
                        if (t >= d)
                            break;
                        v.push({
                            item: e,
                            score: 1
                        }),
                        t += 1
                    }
                    for (let[e,i] of p) {
                        if (t >= d)
                            break;
                        v.push({
                            text: e,
                            render: i,
                            score: 1
                        }),
                        t += 1
                    }
                }
                requestAnimationFrame( () => {
                    if (e.aborted)
                        return;
                    let t = g.querySelector('input[type="radio"]:checked');
                    g.textContent = "";
                    let i = 0
                      , s = () => {
                        if (e.aborted)
                            return;
                        let a = Math.min(v.length, i + 100)
                          , l = document.createDocumentFragment();
                        for (let t = i; t < a; t += 1) {
                            let e = v[t]
                              , i = null;
                            if ("render"in e && "text"in e) {
                                let {render: t, text: n} = e;
                                i = t(n),
                                m.add(i),
                                o.set(i, n),
                                p.delete(n)
                            } else
                                "item"in e && (i = e.item);
                            i instanceof HTMLElement && (f && r(n && i.querySelector(n) || i, f ? h : "", u(i)),
                            l.appendChild(i))
                        }
                        i = a;
                        let d = !1;
                        if (t instanceof HTMLInputElement)
                            for (let e of l.querySelectorAll('input[type="radio"]:checked'))
                                e instanceof HTMLInputElement && e.value !== t.value && (e.checked = !1,
                                d = !0);
                        if (this.getAttribute("data-tab-only-first")) {
                            let t = this.querySelectorAll("button.js-emoji-button");
                            for (let e of t)
                                e.setAttribute("tabindex", "-1");
                            t.item(0)?.setAttribute("tabindex", "0")
                        } else
                            for (let t of l.querySelectorAll('button[tabindex="-1"]'))
                                t.setAttribute("tabindex", "0");
                        if (g.appendChild(l),
                        t && d && t.dispatchEvent(new Event("change",{
                            bubbles: !0
                        })),
                        a < v.length)
                            requestAnimationFrame(s);
                        else {
                            g.hidden = 0 === v.length;
                            let t = this.querySelector("[data-fuzzy-list-show-on-empty]");
                            t && (t.hidden = v.length > 0),
                            this.dispatchEvent(new CustomEvent("fuzzy-list-sorted",{
                                detail: v.length
                            }))
                        }
                    }
                    ;
                    s()
                }
                )
            }
            get value() {
                return this.getAttribute("value") || ""
            }
            set value(t) {
                this.setAttribute("value", t)
            }
            get markSelector() {
                return this.getAttribute("mark-selector") || ""
            }
            set markSelector(t) {
                t ? this.setAttribute("mark-selector", t) : this.removeAttribute("mark-selector")
            }
            get minScore() {
                return Number(this.getAttribute("min-score") || 0)
            }
            set minScore(t) {
                Number.isNaN(t) || this.setAttribute("min-score", String(t))
            }
            get maxMatches() {
                return Number(this.getAttribute("max-matches") || 1 / 0)
            }
            set maxMatches(t) {
                Number.isNaN(t) || this.setAttribute("max-matches", String(t))
            }
            get ariaLiveElement() {
                let t = this.getAttribute("data-aria-live-element");
                if (!t)
                    return;
                let e = document.getElementById(t);
                if (e)
                    return e
            }
            static get observedAttributes() {
                return ["value", "mark-selector", "min-score", "max-matches"]
            }
            attributeChangedCallback(t, e, i) {
                if (e === i)
                    return;
                let n = l.get(this);
                n && (n.timer && window.clearTimeout(n.timer),
                n.timer = window.setTimeout( () => this.sort(), 100))
            }
        }
          , h = d;
        window.customElements.get("fuzzy-list") || (window.FuzzyListElement = d,
        window.customElements.define("fuzzy-list", d))
    }
    ,
    87057: (t, e, i) => {
        i.d(e, {
            O: () => a,
            S: () => r
        });
        var n = i(71315);
        let s = n.cg?.document?.head?.querySelector('meta[name="release"]')?.content || ""
          , r = "X-GitHub-Client-Version";
        function a() {
            return s
        }
    }
    ,
    87363: (t, e, i) => {
        i.d(e, {
            Ff: () => o,
            eC: () => u,
            uE: () => l
        });
        var n = i(6986);
        let s = !1
          , r = new n.A;
        function a(t) {
            let e = t.target;
            if (e instanceof HTMLElement && e.nodeType !== Node.DOCUMENT_NODE)
                for (let t of r.matches(e))
                    t.data.call(null, e)
        }
        function l(t, e) {
            s || (s = !0,
            document.addEventListener("focus", a, !0)),
            r.add(t, e),
            document.activeElement instanceof HTMLElement && document.activeElement.matches(t) && e(document.activeElement)
        }
        function o(t, e, i) {
            function n(e) {
                let s = e.currentTarget;
                s && (s.removeEventListener(t, i),
                s.removeEventListener("blur", n))
            }
            l(e, function(e) {
                e.addEventListener(t, i),
                e.addEventListener("blur", n)
            })
        }
        function u(t, e) {
            function i(t) {
                let {currentTarget: n} = t;
                n && (n.removeEventListener("input", e),
                n.removeEventListener("blur", i))
            }
            l(t, function(t) {
                t.addEventListener("input", e),
                t.addEventListener("blur", i)
            })
        }
    }
    ,
    92454: (t, e, i) => {
        function n() {
            return /Windows/.test(navigator.userAgent) ? "windows" : /Macintosh/.test(navigator.userAgent) ? "mac" : null
        }
        i.d(e, {
            u: () => n
        }),
        (0,
        i(21403).lB)(".js-remove-unless-platform", function(t) {
            let e, i;
            e = (t.getAttribute("data-platforms") || "").split(","),
            (i = n()) && e.includes(i) || t.remove()
        })
    }
}, t => {
    t.O(0, [97068, 43784, 4712, 81028, 74911, 91853, 78143, 87434], () => t(t.s = 26053)),
    t.O()
}
]);
//# sourceMappingURL=github-elements-546b7173799f.js.map
